@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title QuantDeck Workstation Launcher

cd /d "%~dp0"

:: ---------------------------------------------------------------
:: 1. Free Port 8765 if a stale process is holding it
:: ---------------------------------------------------------------
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8765 ^| findstr LISTENING 2^>nul') do (
    if not "%%a"=="" (
        taskkill /F /PID %%a >nul 2>&1
    )
)

:: ---------------------------------------------------------------
:: 2. Locate or Automatically Install Python 3.12
:: ---------------------------------------------------------------
set "PY_EXE="

if exist "%~dp0runtime\python.exe" (
    set "PY_EXE=%~dp0runtime\python.exe"
    goto :check_deps
)

if exist "%~dp0.venv\Scripts\python.exe" (
    set "PY_EXE=%~dp0.venv\Scripts\python.exe"
    goto :check_deps
)

if exist "C:\ProgramData\miniconda3\python.exe" (
    set "PY_EXE=C:\ProgramData\miniconda3\python.exe"
    goto :check_deps
)

if exist "%USERPROFILE%\miniconda3\python.exe" (
    set "PY_EXE=%USERPROFILE%\miniconda3\python.exe"
    goto :check_deps
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "C:\Program Files\Python312\python.exe"
    "C:\Program Files\Python311\python.exe"
) do (
    if exist %%P (
        set "PY_EXE=%%~P"
        goto :setup_venv
    )
)

where python >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        for /f "delims=" %%i in ('where python') do (
            set "PY_EXE=%%i"
            goto :setup_venv
        )
    )
)

echo ===============================================================
echo   QuantDeck First-Time Setup: Installing Official Python 3.12
echo ===============================================================

where winget >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "C:\Program Files\Python312\python.exe"
) do (
    if exist %%P (
        set "PY_EXE=%%~P"
        goto :setup_venv
    )
)

echo [*] Downloading official Python 3.12.8 installer from python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile '$env:TEMP\python_qd_setup.exe'"
if exist "%TEMP%\python_qd_setup.exe" (
    echo [*] Installing Python 3.12.8...
    "%TEMP%\python_qd_setup.exe" /passive InstallAllUsers=0 PrependPath=1 Include_test=0 Include_pip=1
    del /q "%TEMP%\python_qd_setup.exe" >nul 2>&1
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "C:\Program Files\Python312\python.exe"
) do (
    if exist %%P (
        set "PY_EXE=%%~P"
        goto :setup_venv
    )
)

echo [!] Automatic Python installation could not complete.
echo     Please install Python 3.12 from https://www.python.org/downloads/ and run this file again.
pause
exit /b 1

:: ---------------------------------------------------------------
:: 3. Create Local .venv if using standalone Python
:: ---------------------------------------------------------------
:setup_venv
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo [*] Creating isolated Python environment (.venv)...
    "%PY_EXE%" -m venv "%~dp0.venv"
    if exist "%~dp0.venv\Scripts\python.exe" (
        set "PY_EXE=%~dp0.venv\Scripts\python.exe"
    )
)

:: ---------------------------------------------------------------
:: 4. Verify & Auto-Install Required Packages (First Run Only)
:: ---------------------------------------------------------------
:check_deps
"%PY_EXE%" -c "import fastapi, uvicorn, pandas, numpy, yfinance" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ===============================================================
    echo   First-Time Setup: Installing QuantDeck Libraries...
    echo   ^(This only happens once on the first launch^)
    echo ===============================================================
    "%PY_EXE%" -m pip install --upgrade pip
    "%PY_EXE%" -m pip install -r "%~dp0requirements.txt"
)

:: ---------------------------------------------------------------
:: 5. Launch QuantDeck in Windowless Mode (pythonw.exe) & Close CMD
:: ---------------------------------------------------------------
set "QD_WINDOWLESS=1"
set "PYW_EXE=!PY_EXE:python.exe=pythonw.exe!"

if exist "!PYW_EXE!" (
    start "" "!PYW_EXE!" "%~dp0run.py"
) else (
    start "" /B "!PY_EXE!" "%~dp0run.py" >nul 2>&1
)

exit /b 0
