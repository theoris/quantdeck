@echo off
setlocal
chcp 65001 >nul
echo ======================================================================
echo QuantDeck Standalone - Database Sync Utility (Windows)
echo Copies updated .db and .json files from source folders into data_db/
echo ======================================================================

cd /d "%~dp0\.."

if exist "C:\ProgramData\miniconda3\python.exe" (
    "C:\ProgramData\miniconda3\python.exe" utils\sync_db.py %*
) else (
    python utils\sync_db.py %*
)

echo.
pause

