#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR"

echo "======================================================================"
echo "QuantDeck Standalone - Database Sync Utility (macOS / Linux)"
echo "Copies updated .db and .json files from source folders into data_db/"
echo "======================================================================"

if command -v python3 >/dev/null 2>&1; then
    python3 utils/sync_db.py "$@"
else
    python utils/sync_db.py "$@"
fi

