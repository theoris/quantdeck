"""
QuantDeck Custom Strategy Specification & Template
Save this file as `.py` inside `chart/custom_strategies/` (e.g. `my_breakout.py`)
QuantDeck will auto-discover and load it into the strategy catalog dynamically.
"""

from typing import Dict, Any, List
import pandas as pd
import numpy as np
from backend.strategies.base import BaseStrategy


class CustomStrategyTemplate(BaseStrategy):
    name = "Custom Strategy Template"
    description = "แม่แบบสร้างกลยุทธ์สำหรับ QuantDeck รองรับ Dynamic Lot Sizing และ Indicator Overlays"
    version = "1.0.0"
    author = "Trader"

    @classmethod
    def get_param_defs(cls) -> List[Dict[str, Any]]:
        """
        กำหนด Parameter Schema เพื่อให้ QuantDeck UI สร้างกล่องปรับตัวเลขบนหน้าจอโดยอัตโนมัติ
        types: 'number' | 'text' | 'select'
        """
        return [
            {
                "key": "lookback_period",
                "label": "Lookback Period",
                "type": "number",
                "default": 20,
                "min": 2,
                "max": 300,
                "step": 1
            },
            {
                "key": "atr_mult",
                "label": "ATR Target Multiplier",
                "type": "number",
                "default": 2.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1
            }
        ]

    @classmethod
    def get_default_params(cls) -> Dict[str, Any]:
        """ค่า Default ของ Parameters ทั้งหมด"""
        return {
            "lookback_period": 20,
            "atr_mult": 2.0
        }

    def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        คำนวณสัญญาณการเทรดแบบ Vectorized (ปราศจาก Lookahead Bias)
        
        Args:
            df: DataFrame แท่งเทียนมาตรฐาน ประกอบด้วย ['time', 'open', 'high', 'low', 'close', 'volume']
            
        Returns:
            Dict ประกอบด้วย:
            - 'signals': pd.Series (1 = BUY, -1 = SELL, 0 = ไม่มีสัญญาณ)
            - 'sl': pd.Series (ระดับราคา Stop Loss)
            - 'tp': pd.Series (ระดับราคา Take Profit)
            - 'sizes': (Optional) pd.Series กำหนดขนาด Lot ของแต่ละไม้แบบ Dynamic (เช่น 0.05, 0.1, 0.2)
            - 'overlays': (Optional) ข้อมูลเส้นกราฟที่จะพล็อตบน Lightweight Charts
        """
        n = len(df)
        signals = pd.Series(0, index=df.index, dtype=int)
        sl = pd.Series(0.0, index=df.index, dtype=float)
        tp = pd.Series(0.0, index=df.index, dtype=float)
        sizes = pd.Series(0.0, index=df.index, dtype=float)

        period = int(self.params.get("lookback_period", 20))
        mult = float(self.params.get("atr_mult", 2.0))

        if n < period + 5:
            return {"signals": signals, "sl": sl, "tp": tp, "sizes": sizes, "overlays": {}}

        # --- 1. ตัวอย่างคำนวณ Technical Indicators แบบ Vectorized ---
        high = df['high']
        low = df['low']
        close = df['close']

        # Donchian High / Low
        highest_high = high.rolling(window=period).max().shift(1)
        lowest_low = low.rolling(window=period).min().shift(1)

        # ATR
        tr = pd.concat([
            high - low,
            (high - close.shift(1)).abs(),
            (low - close.shift(1)).abs()
        ], axis=1).max(axis=1)
        atr = tr.rolling(window=14, min_periods=1).mean()

        # --- 2. กำหนดเงื่อนไข Entry Signals ---
        buy_cond = close > highest_high
        sell_cond = close < lowest_low

        signals[buy_cond] = 1
        signals[sell_cond] = -1

        # --- 3. กำหนด SL / TP ---
        sl[buy_cond] = close[buy_cond] - (atr[buy_cond] * mult)
        tp[buy_cond] = close[buy_cond] + (atr[buy_cond] * mult * 1.5)

        sl[sell_cond] = close[sell_cond] + (atr[sell_cond] * mult)
        tp[sell_cond] = close[sell_cond] - (atr[sell_cond] * mult * 1.5)

        # --- 4. (ทางเลือก) Dynamic Lot Sizing ตามสูตรของกลยุทธ์ ---
        # ตัวอย่าง: สามารถกำหนด Lot แตกต่างกันได้ในแต่ละไม้ เช่น 0.1 หรือ 0.2
        sizes[buy_cond] = 0.1
        sizes[sell_cond] = 0.1

        # --- 5. เตรียมเส้น Overlays แสดงบน Lightweight Charts ---
        times = df['time'].tolist()
        hh_line = [{"time": t, "value": round(float(v), 4)} for t, v in zip(times, highest_high) if not np.isnan(v)]
        ll_line = [{"time": t, "value": round(float(v), 4)} for t, v in zip(times, lowest_low) if not np.isnan(v)]

        return {
            "signals": signals,
            "sl": sl,
            "tp": tp,
            "sizes": sizes,
            "overlays": {
                f"Donchian High ({period})": {
                    "color": "#00E676",
                    "lineWidth": 1,
                    "pane": "main",
                    "data": hh_line
                },
                f"Donchian Low ({period})": {
                    "color": "#FF5252",
                    "lineWidth": 1,
                    "pane": "main",
                    "data": ll_line
                }
            }
        }

