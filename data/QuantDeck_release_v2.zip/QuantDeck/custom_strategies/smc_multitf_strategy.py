"""
QuantDeck Custom Strategy: SMC Multi-Timeframe Strategy
Save this file as `.py` inside `chart/custom_strategies/` (e.g. `smc_multitf_strategy.py`)
QuantDeck will auto-discover and load it into the strategy catalog dynamically.
"""

from typing import Dict, Any, List
import pandas as pd
import numpy as np
from backend.strategies.base import BaseStrategy


class SMCMultiTFStrategy(BaseStrategy):
    name = "SMC Multi-TF Strategy"
    description = (
        "Smart Money Concepts (BOS/CHoCH, Order Blocks, FVG, Liquidity Sweep) "
        "with Auto Pip Detection, HTF Multiplier Bias, and Zero Lookahead Bias."
    )
    version = "1.2.0"
    author = "QuantDeck Developer"

    @classmethod
    def get_param_defs(cls) -> List[Dict[str, Any]]:
        """
        Parameter Schema for QuantDeck UI.
        Supported types: 'number' | 'text' | 'select'
        """
        return [
            {
                "key": "swing_length_ltf",
                "label": "LTF Swing Length (Bars)",
                "type": "number",
                "default": 5,
                "min": 2,
                "max": 30,
                "step": 1
            },
            {
                "key": "htf_multiplier",
                "label": "HTF Timeframe Multiplier (e.g. 4 = M15->H1, H1->H4)",
                "type": "number",
                "default": 4,
                "min": 2,
                "max": 12,
                "step": 1
            },
            {
                "key": "min_rr",
                "label": "Risk:Reward Ratio (RR)",
                "type": "number",
                "default": 2.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1
            },
            {
                "key": "atr_period",
                "label": "ATR Period",
                "type": "number",
                "default": 14,
                "min": 5,
                "max": 50,
                "step": 1
            },
            {
                "key": "atr_sl_multiplier",
                "label": "ATR SL Multiplier",
                "type": "number",
                "default": 1.5,
                "min": 0.5,
                "max": 5.0,
                "step": 0.1
            },
            {
                "key": "max_sl_pips",
                "label": "Max SL Cap in Pips (0 = Use ATR Only)",
                "type": "number",
                "default": 0.0,
                "min": 0.0,
                "max": 1000.0,
                "step": 5.0
            },
            {
                "key": "lot_size",
                "label": "Lot Size (Min 0.01)",
                "type": "number",
                "default": 0.01,
                "min": 0.01,
                "max": 100.0,
                "step": 0.01
            },
            {
                "key": "use_ob",
                "label": "Use Order Block (1 = On, 0 = Off)",
                "type": "number",
                "default": 1,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "use_fvg",
                "label": "Use Fair Value Gap (1 = On, 0 = Off)",
                "type": "number",
                "default": 1,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "require_choch",
                "label": "Require BOS/CHoCH Structure (1 = On, 0 = Off)",
                "type": "number",
                "default": 1,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "require_sweep",
                "label": "Require Liquidity Sweep (1 = On, 0 = Off)",
                "type": "number",
                "default": 0,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "sweep_lookback",
                "label": "Sweep Lookback Window (Bars)",
                "type": "number",
                "default": 20,
                "min": 5,
                "max": 100,
                "step": 1
            },
            {
                "key": "sweep_wick_only",
                "label": "Sweep Type (1 = Wick Rejection, 0 = Break & Close)",
                "type": "number",
                "default": 1,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "use_session_filter",
                "label": "Use London/NY Session Filter (1 = On, 0 = Off)",
                "type": "number",
                "default": 0,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "london_start_hour",
                "label": "London Start Hour (Server Time)",
                "type": "number",
                "default": 14,
                "min": 0,
                "max": 23,
                "step": 1
            },
            {
                "key": "london_end_hour",
                "label": "London End Hour (Server Time)",
                "type": "number",
                "default": 23,
                "min": 0,
                "max": 23,
                "step": 1
            },
            {
                "key": "ny_start_hour",
                "label": "NY Start Hour (Server Time)",
                "type": "number",
                "default": 19,
                "min": 0,
                "max": 23,
                "step": 1
            },
            {
                "key": "ny_end_hour",
                "label": "NY End Hour (Server Time)",
                "type": "number",
                "default": 2,
                "min": 0,
                "max": 23,
                "step": 1
            }
        ]

    @classmethod
    def get_default_params(cls) -> Dict[str, Any]:
        """Default parameter dictionary."""
        return {
            "swing_length_ltf": 5,
            "htf_multiplier": 4,
            "min_rr": 2.0,
            "atr_period": 14,
            "atr_sl_multiplier": 1.5,
            "max_sl_pips": 0.0,
            "lot_size": 0.01,
            "use_ob": 1,
            "use_fvg": 1,
            "require_choch": 1,
            "require_sweep": 0,
            "sweep_lookback": 20,
            "sweep_wick_only": 1,
            "use_session_filter": 0,
            "london_start_hour": 14,
            "london_end_hour": 23,
            "ny_start_hour": 19,
            "ny_end_hour": 2
        }

    # -------------------------------------------------------------------------
    # Internal Helper Methods
    # -------------------------------------------------------------------------
    def _detect_pip_value(self, df: pd.DataFrame) -> float:
        """
        Auto-detects pip value from symbol metadata or price scale.
        - XAUUSD / Gold: 0.1
        - JPY Forex pairs: 0.01
        - Standard Forex pairs (EURUSD, GBPUSD, etc.): 0.0001
        - Indices / BTC: 1.0
        """
        symbol = ""
        if "symbol" in df.columns and len(df) > 0:
            symbol = str(df["symbol"].iloc[0]).upper()
        elif hasattr(df, "attrs") and "symbol" in df.attrs:
            symbol = str(df.attrs["symbol"]).upper()
        elif "symbol" in self.params:
            symbol = str(self.params["symbol"]).upper()

        if symbol:
            if any(k in symbol for k in ["XAU", "GOLD"]):
                return 0.1
            if "JPY" in symbol:
                return 0.01
            if any(k in symbol for k in ["XAG", "SILVER"]):
                return 0.01
            if any(k in symbol for k in ["BTC", "ETH", "US30", "NAS", "SPX", "DAX", "GER"]):
                return 1.0
            return 0.0001

        # Fallback: infer from median price level if symbol string is not present
        median_price = float(df["close"].median()) if len(df) > 0 else 1.0
        if median_price > 10000:
            return 1.0      # BTC, US30, NAS100
        elif median_price > 500:
            return 0.1      # XAUUSD (Gold)
        elif median_price > 20:
            return 0.01     # USDJPY, EURJPY, XAGUSD
        else:
            return 0.0001   # Standard Forex (EURUSD, GBPUSD, etc.)

    def _detect_confirmed_swings(self, df: pd.DataFrame, length: int):
        """
        Detects Swing Highs and Swing Lows without Lookahead Bias.
        A swing pivot at bar (i - length) is confirmed at bar (i).
        """
        window = 2 * length + 1
        roll_max = df["high"].rolling(window=window).max()
        roll_min = df["low"].rolling(window=window).min()

        pivot_high = df["high"].shift(length)
        pivot_low = df["low"].shift(length)

        is_sh = (pivot_high == roll_max) & roll_max.notna()
        is_sl = (pivot_low == roll_min) & roll_min.notna()

        sh_price = np.where(is_sh, pivot_high, np.nan)
        sl_price = np.where(is_sl, pivot_low, np.nan)

        return is_sh.to_numpy(), sh_price, is_sl.to_numpy(), sl_price

    def _compute_structure_and_ob(
        self,
        opens: np.ndarray,
        highs: np.ndarray,
        lows: np.ndarray,
        closes: np.ndarray,
        is_sh: np.ndarray,
        sh_price: np.ndarray,
        is_sl: np.ndarray,
        sl_price: np.ndarray,
        ob_lookback: int = 15
    ):
        """
        Computes Market Structure (BOS, CHoCH, Trend) and Order Blocks (OB).
        """
        n = len(closes)
        bos = np.zeros(n, dtype=int)
        choch = np.zeros(n, dtype=int)
        trend = np.zeros(n, dtype=int)

        ob_bull_mid = np.full(n, np.nan)
        ob_bear_mid = np.full(n, np.nan)

        last_sh = np.nan
        last_sl = np.nan
        curr_trend = 0

        for i in range(n):
            if is_sh[i]:
                last_sh = sh_price[i]
            if is_sl[i]:
                last_sl = sl_price[i]

            # Bullish Break (Close above confirmed Swing High)
            if not np.isnan(last_sh) and closes[i] > last_sh:
                if curr_trend == -1:
                    choch[i] = 1
                else:
                    bos[i] = 1
                curr_trend = 1
                last_sh = np.nan

                start_idx = max(0, i - ob_lookback)
                for j in range(i - 1, start_idx - 1, -1):
                    if closes[j] < opens[j]:
                        ob_bull_mid[i] = 0.5 * (opens[j] + closes[j])
                        break
                if np.isnan(ob_bull_mid[i]):
                    ob_bull_mid[i] = lows[i]

            # Bearish Break (Close below confirmed Swing Low)
            elif not np.isnan(last_sl) and closes[i] < last_sl:
                if curr_trend == 1:
                    choch[i] = -1
                else:
                    bos[i] = -1
                curr_trend = -1
                last_sl = np.nan

                start_idx = max(0, i - ob_lookback)
                for j in range(i - 1, start_idx - 1, -1):
                    if closes[j] > opens[j]:
                        ob_bear_mid[i] = 0.5 * (opens[j] + closes[j])
                        break
                if np.isnan(ob_bear_mid[i]):
                    ob_bear_mid[i] = highs[i]

            trend[i] = curr_trend

        return bos, choch, trend, ob_bull_mid, ob_bear_mid

    def _get_session_mask(self, df: pd.DataFrame) -> np.ndarray:
        """Evaluates London and New York trading session hours."""
        if int(self.params.get("use_session_filter", 0)) == 0:
            return np.ones(len(df), dtype=bool)

        try:
            if "time" in df.columns:
                time_col = df["time"]
                if np.issubdtype(time_col.dtype, np.number):
                    unit = "ms" if time_col.iloc[-1] > 1e11 else "s"
                    dt_series = pd.to_datetime(time_col, unit=unit)
                else:
                    dt_series = pd.to_datetime(time_col)
                hours = dt_series.dt.hour.to_numpy()
            elif isinstance(df.index, pd.DatetimeIndex):
                hours = df.index.hour.to_numpy()
            else:
                return np.ones(len(df), dtype=bool)
        except Exception:
            return np.ones(len(df), dtype=bool)

        l_start = int(self.params.get("london_start_hour", 14))
        l_end = int(self.params.get("london_end_hour", 23))
        ny_start = int(self.params.get("ny_start_hour", 19))
        ny_end = int(self.params.get("ny_end_hour", 2))

        if l_start <= l_end:
            in_london = (hours >= l_start) & (hours <= l_end)
        else:
            in_london = (hours >= l_start) | (hours <= l_end)

        if ny_start <= ny_end:
            in_ny = (hours >= ny_start) & (hours <= ny_end)
        else:
            in_ny = (hours >= ny_start) | (hours <= ny_end)

        return in_london | in_ny

    @staticmethod
    def _build_overlay_data(times: list, values: np.ndarray) -> List[Dict[str, Any]]:
        """Formats overlay series into JSON-safe list for Lightweight Charts."""
        return [
            {"time": t, "value": round(float(v), 5)}
            for t, v in zip(times, values)
            if pd.notna(v) and np.isfinite(v)
        ]

    # -------------------------------------------------------------------------
    # Main Signal Generation
    # -------------------------------------------------------------------------
    def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Generates vectorized trading signals without lookahead bias.
        Automatically evaluates all historical bars and any new incoming bars.
        """
        n = len(df)
        signals = pd.Series(0, index=df.index, dtype=int)
        sl = pd.Series(0.0, index=df.index, dtype=float)
        tp = pd.Series(0.0, index=df.index, dtype=float)
        sizes = pd.Series(0.0, index=df.index, dtype=float)

        swing_ltf = int(self.params.get("swing_length_ltf", 5))
        htf_mult = int(self.params.get("htf_multiplier", 4))
        swing_htf = max(swing_ltf * htf_mult, swing_ltf + 5)

        min_rr = float(self.params.get("min_rr", 2.0))
        atr_period = int(self.params.get("atr_period", 14))
        atr_mult = float(self.params.get("atr_sl_multiplier", 1.5))
        max_sl_pips = float(self.params.get("max_sl_pips", 0.0))

        # Minimum lot size enforced at 0.01 for XAUUSD & Forex
        lot_size = round(max(0.01, float(self.params.get("lot_size", 0.01))), 2)

        use_ob = bool(int(self.params.get("use_ob", 1)))
        use_fvg = bool(int(self.params.get("use_fvg", 1)))
        require_choch = bool(int(self.params.get("require_choch", 1)))
        require_sweep = bool(int(self.params.get("require_sweep", 0)))
        sweep_lookback = int(self.params.get("sweep_lookback", 20))
        sweep_wick_only = bool(int(self.params.get("sweep_wick_only", 1)))

        min_bars = max(swing_htf * 2 + 2, atr_period + 5, 25)
        if n < min_bars:
            return {"signals": signals, "sl": sl, "tp": tp, "sizes": sizes, "overlays": {}}

        # Auto-detect pip value based on symbol or price scale
        pip_value = self._detect_pip_value(df)

        high = df["high"]
        low = df["low"]
        close = df["close"]
        opens = df["open"].to_numpy(dtype=float)
        highs = high.to_numpy(dtype=float)
        lows = low.to_numpy(dtype=float)
        closes = close.to_numpy(dtype=float)

        # --- 1. Vectorized ATR Calculation ---
        tr = pd.concat([
            high - low,
            (high - close.shift(1)).abs(),
            (low - close.shift(1)).abs()
        ], axis=1).max(axis=1)
        atr = tr.rolling(window=atr_period, min_periods=1).mean().bfill().fillna(0.0).to_numpy(dtype=float)

        # --- 2. HTF & LTF Market Structure (Zero Lookahead) ---
        htf_is_sh, htf_sh_p, htf_is_sl, htf_sl_p = self._detect_confirmed_swings(df, swing_htf)
        _, _, htf_trend, _, _ = self._compute_structure_and_ob(
            opens, highs, lows, closes, htf_is_sh, htf_sh_p, htf_is_sl, htf_sl_p
        )

        ltf_is_sh, ltf_sh_p, ltf_is_sl, ltf_sl_p = self._detect_confirmed_swings(df, swing_ltf)
        ltf_bos, ltf_choch, ltf_trend, ob_bull_mid, ob_bear_mid = self._compute_structure_and_ob(
            opens, highs, lows, closes, ltf_is_sh, ltf_sh_p, ltf_is_sl, ltf_sl_p, ob_lookback=15
        )

        # --- 3. Vectorized Fair Value Gap (FVG) ---
        high_2 = high.shift(2)
        low_2 = low.shift(2)
        fvg_bull = (low > high_2).to_numpy()
        fvg_bear = (high < low_2).to_numpy()

        fvg_bull_mid = np.where(fvg_bull, 0.5 * (lows + high_2.to_numpy()), np.nan)
        fvg_bear_mid = np.where(fvg_bear, 0.5 * (highs + low_2.to_numpy()), np.nan)

        # --- 4. Vectorized Liquidity Sweeps ---
        sh_series = pd.Series(ltf_sh_p, index=df.index)
        sl_series = pd.Series(ltf_sl_p, index=df.index)

        recent_sh = sh_series.ffill().shift(1).to_numpy()
        recent_sl = sl_series.ffill().shift(1).to_numpy()

        if sweep_wick_only:
            sweep_bull = (lows < recent_sl) & (closes > recent_sl)
            sweep_bear = (highs > recent_sh) & (closes < recent_sh)
        else:
            sweep_bull = lows < recent_sl
            sweep_bear = highs > recent_sh

        recent_sweep_bull = (
            pd.Series(sweep_bull, index=df.index)
            .rolling(window=sweep_lookback, min_periods=1)
            .max()
            .astype(bool)
            .to_numpy()
        )
        recent_sweep_bear = (
            pd.Series(sweep_bear, index=df.index)
            .rolling(window=sweep_lookback, min_periods=1)
            .max()
            .astype(bool)
            .to_numpy()
        )

        # --- 5. Active OB & FVG Zones ---
        active_ob_bull = pd.Series(ob_bull_mid, index=df.index).ffill(limit=15).to_numpy()
        active_ob_bear = pd.Series(ob_bear_mid, index=df.index).ffill(limit=15).to_numpy()
        active_fvg_bull = pd.Series(fvg_bull_mid, index=df.index).ffill(limit=10).to_numpy()
        active_fvg_bear = pd.Series(fvg_bear_mid, index=df.index).ffill(limit=10).to_numpy()

        bull_zone = np.full(n, np.nan)
        bear_zone = np.full(n, np.nan)

        if use_fvg:
            bull_zone = np.where(np.isfinite(active_fvg_bull), active_fvg_bull, bull_zone)
            bear_zone = np.where(np.isfinite(active_fvg_bear), active_fvg_bear, bear_zone)
        if use_ob:
            bull_zone = np.where(np.isfinite(active_ob_bull), active_ob_bull, bull_zone)
            bear_zone = np.where(np.isfinite(active_ob_bear), active_ob_bear, bear_zone)

        if not use_ob and not use_fvg:
            bull_zone = closes.copy()
            bear_zone = closes.copy()

        # --- 6. Entry Trigger Logic (Supports Multiple Sequential Signals) ---
        in_session = self._get_session_mask(df)

        # Combine HTF & LTF alignment: allow trade when LTF aligns with HTF or triggers a fresh break
        bull_break_event = (ltf_bos == 1) | (ltf_choch == 1)
        bear_break_event = (ltf_bos == -1) | (ltf_choch == -1)

        # Pullback / Continuation trigger when price is in trend and forms a new FVG or sweeps liquidity
        bull_continuation = (ltf_trend == 1) & (htf_trend >= 0) & (fvg_bull | sweep_bull)
        bear_continuation = (ltf_trend == -1) & (htf_trend <= 0) & (fvg_bear | sweep_bear)

        if require_choch:
            bull_trigger = bull_break_event | bull_continuation
            bear_trigger = bear_break_event | bear_continuation
        else:
            bull_trigger = (ltf_trend >= 0) & (fvg_bull | sweep_bull | bull_break_event)
            bear_trigger = (ltf_trend <= 0) & (fvg_bear | sweep_bear | bear_break_event)

        bull_sweep_ok = np.ones(n, dtype=bool) if not require_sweep else recent_sweep_bull
        bear_sweep_ok = np.ones(n, dtype=bool) if not require_sweep else recent_sweep_bear

        warmup = np.arange(n) >= max(swing_ltf * 2, 15)

        buy_cond = (
            warmup
            & in_session
            & bull_trigger
            & bull_sweep_ok
            & np.isfinite(bull_zone)
            & (closes > opens)  # Bullish confirmation candle
        )

        sell_cond = (
            warmup
            & in_session
            & bear_trigger
            & bear_sweep_ok
            & np.isfinite(bear_zone)
            & (closes < opens)  # Bearish confirmation candle
        )

        # Prevent consecutive duplicate signals on adjacent bars (cooldown of 3 bars between same-direction entries)
        buy_idx = np.where(buy_cond)[0]
        last_b = -999
        for idx_val in buy_idx:
            if idx_val - last_b < 3:
                buy_cond[idx_val] = False
            else:
                last_b = idx_val

        sell_idx = np.where(sell_cond)[0]
        last_s = -999
        for idx_val in sell_idx:
            if idx_val - last_s < 3:
                sell_cond[idx_val] = False
            else:
                last_s = idx_val

        sell_cond = sell_cond & (~buy_cond)

        # --- 7. Stop Loss (SL) & Take Profit (TP) Calculation ---
        # Base SL distance from ATR
        sl_dist = np.where(atr > 0, atr * atr_mult, closes * 0.002)

        # If max_sl_pips > 0, cap the SL distance to (max_sl_pips * auto_pip_value)
        if max_sl_pips > 0:
            max_sl_price_dist = max_sl_pips * pip_value
            sl_dist = np.minimum(sl_dist, max_sl_price_dist)

        bull_sl_calc = closes - sl_dist
        bull_tp_calc = closes + (sl_dist * min_rr)

        bear_sl_calc = closes + sl_dist
        bear_tp_calc = closes - (sl_dist * min_rr)

        signals[buy_cond] = 1
        signals[sell_cond] = -1

        sl[buy_cond] = np.round(bull_sl_calc[buy_cond], 5)
        tp[buy_cond] = np.round(bull_tp_calc[buy_cond], 5)

        sl[sell_cond] = np.round(bear_sl_calc[sell_cond], 5)
        tp[sell_cond] = np.round(bear_tp_calc[sell_cond], 5)

        # --- 8. Position Sizing (Min 0.01 Lot) ---
        sizes[buy_cond] = lot_size
        sizes[sell_cond] = lot_size

        # Sanitize outputs to guarantee 100% JSON compliance
        signals = signals.fillna(0).astype(int)
        sl = sl.replace([np.inf, -np.inf], 0.0).fillna(0.0).astype(float)
        tp = tp.replace([np.inf, -np.inf], 0.0).fillna(0.0).astype(float)
        sizes = sizes.replace([np.inf, -np.inf], 0.0).fillna(0.0).astype(float)

        # --- 9. Overlays for Lightweight Charts ---
        times = df["time"].tolist() if "time" in df.columns else df.index.tolist()

        sh_line_vals = sh_series.ffill().to_numpy()
        sl_line_vals = sl_series.ffill().to_numpy()
        htf_sh_vals = pd.Series(htf_sh_p, index=df.index).ffill().to_numpy()
        htf_sl_vals = pd.Series(htf_sl_p, index=df.index).ffill().to_numpy()

        return {
            "signals": signals,
            "sl": sl,
            "tp": tp,
            "sizes": sizes,
            "overlays": {
                f"LTF Swing High ({swing_ltf})": {
                    "color": "#29B6F6",
                    "lineWidth": 1,
                    "pane": "main",
                    "data": self._build_overlay_data(times, sh_line_vals)
                },
                f"LTF Swing Low ({swing_ltf})": {
                    "color": "#FFA726",
                    "lineWidth": 1,
                    "pane": "main",
                    "data": self._build_overlay_data(times, sl_line_vals)
                },
                f"HTF Structure High ({swing_htf})": {
                    "color": "#7E57C2",
                    "lineWidth": 2,
                    "pane": "main",
                    "data": self._build_overlay_data(times, htf_sh_vals)
                },
                f"HTF Structure Low ({swing_htf})": {
                    "color": "#AB47BC",
                    "lineWidth": 2,
                    "pane": "main",
                    "data": self._build_overlay_data(times, htf_sl_vals)
                },
                "Bull OB/FVG Zone": {
                    "color": "#00E676",
                    "lineWidth": 2,
                    "pane": "main",
                    "data": self._build_overlay_data(times, bull_zone)
                },
                "Bear OB/FVG Zone": {
                    "color": "#FF5252",
                    "lineWidth": 2,
                    "pane": "main",
                    "data": self._build_overlay_data(times, bear_zone)
                }
            }
        }