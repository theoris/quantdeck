"""
QuantDeck Custom Strategy: SMC 3-Layer (H4 Bias -> H1 Zone -> M15 Trigger) with Split Entry 50/50
File: custom_strategies/smc_3layer_split.py
Specification: SMC_Strategy_Specification_v2.md (Version 2.0)
Standard: QuantDeck Custom Strategy Standard
"""

from typing import Dict, Any, List, Optional, Tuple
import pandas as pd
import numpy as np

try:
    from backend.strategies.base import BaseStrategy
except ImportError:
    class BaseStrategy:
        custom_sizing = False

        def __init__(self, params=None):
            self.params = self.get_default_params()
            if params:
                self.params.update(params)
            self.context = {}

        def set_context(self, context):
            self.context = context or {}

        @property
        def initial_capital(self) -> float:
            return float(self.context.get("initial_capital", 10000.0))

        @property
        def lot_size(self) -> float:
            return float(self.context.get("lot_size", 1.0))

        @property
        def risk_pct(self) -> float:
            return float(self.context.get("risk_pct", 1.0))

        @property
        def sizing_mode(self) -> str:
            return str(self.context.get("sizing_mode", "fixed"))

        @property
        def spread_usd(self) -> float:
            return float(self.context.get("spread_usd", 0.0))

        @property
        def symbol(self) -> str:
            return str(self.context.get("symbol", "XAUUSD"))

        @property
        def multiplier(self) -> float:
            if "multiplier" in self.context and self.context["multiplier"]:
                return float(self.context["multiplier"])
            sym = self.symbol.upper()
            if "XAU" in sym or "GOLD" in sym:
                return 100.0
            if "JPY" in sym:
                return 1000.0
            if any(c in sym for c in ("BTC", "ETH")):
                return 1.0
            return 100000.0

        @classmethod
        def get_param_defs(cls) -> List[Dict[str, Any]]:
            return []

        @classmethod
        def get_default_params(cls) -> Dict[str, Any]:
            return {}

        def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
            raise NotImplementedError


class SMC3LayerSplitStrategy(BaseStrategy):
    name: str = "SMC 3-Layer (H4/H1/M15) Split 50/50"
    description: str = (
        "3-Layer Smart Money Concepts strategy: H4 Structure & Premium/Discount Bias, "
        "H1 OB/FVG POI Zones, and M15 Sweep + CHoCH/BOS Trigger with Model A-E 50/50 Split Sizing."
    )
    version: str = "2.0.0"
    author: str = "QuantDeck Developer"
    custom_sizing: bool = True  # Dynamic 50/50 Split Lot Allocation (X_limit & X_confirm)

    @classmethod
    def get_param_defs(cls) -> List[Dict[str, Any]]:
        """
        Defines strategy-specific SMC parameters.
        Strictly excludes reserved platform sizing/account keys.
        """
        return [
            {
                "key": "entry_mode",
                "label": "Entry Model (A/B/C/D/E)",
                "type": "str",
                "default": "C",
            },
            {
                "key": "tp_mode",
                "label": "TP Mode (A=Shared TP1, B=Split TP1/TP2)",
                "type": "str",
                "default": "A",
            },
            {
                "key": "x_limit_pct",
                "label": "Limit Leg Allocation (X_limit %)",
                "type": "float",
                "default": 0.5,
                "min": 0.1,
                "max": 1.0,
                "step": 0.05,
            },
            {
                "key": "x_confirm_pct",
                "label": "Confirm Leg Allocation (X_confirm %)",
                "type": "float",
                "default": 0.5,
                "min": 0.1,
                "max": 1.0,
                "step": 0.05,
            },
            {
                "key": "swing_len",
                "label": "Pivot Left/Right Confirmation Bars",
                "type": "int",
                "default": 3,
                "min": 2,
                "max": 10,
                "step": 1,
            },
            {
                "key": "atr_period",
                "label": "ATR Period",
                "type": "int",
                "default": 14,
                "min": 5,
                "max": 50,
                "step": 1,
            },
            {
                "key": "buffer_atr_mult",
                "label": "SL Buffer ATR Multiplier",
                "type": "float",
                "default": 0.3,
                "min": 0.05,
                "max": 2.0,
                "step": 0.05,
            },
            {
                "key": "sweep_min_atr",
                "label": "Min Sweep Penetration (ATR Mult)",
                "type": "float",
                "default": 0.15,
                "min": 0.05,
                "max": 1.0,
                "step": 0.05,
            },
            {
                "key": "z_max_age",
                "label": "Max H1 Zone Age (H1 Bars)",
                "type": "int",
                "default": 40,
                "min": 10,
                "max": 150,
                "step": 5,
            },
            {
                "key": "z_max_size_atr",
                "label": "Max H1 Zone Width (H1 ATR Mult)",
                "type": "float",
                "default": 1.5,
                "min": 0.5,
                "max": 4.0,
                "step": 0.1,
            },
            {
                "key": "t_max_wait",
                "label": "Max Trigger Wait After Sweep (M15 Bars)",
                "type": "int",
                "default": 4,
                "min": 1,
                "max": 20,
                "step": 1,
            },
            {
                "key": "disp_min_atr",
                "label": "Min Displacement Body (ATR Mult)",
                "type": "float",
                "default": 0.5,
                "min": 0.2,
                "max": 2.5,
                "step": 0.1,
            },
            {
                "key": "rr_min",
                "label": "Minimum Risk:Reward Ratio",
                "type": "float",
                "default": 1.5,
                "min": 1.0,
                "max": 5.0,
                "step": 0.1,
            },
            {
                "key": "range_min_atr",
                "label": "Min H4 Range Width (H4 ATR Mult)",
                "type": "float",
                "default": 1.2,
                "min": 0.5,
                "max": 5.0,
                "step": 0.1,
            },
            {
                "key": "trail_after_r",
                "label": "Move SL to Breakeven After (R)",
                "type": "float",
                "default": 1.0,
                "min": 0.5,
                "max": 3.0,
                "step": 0.1,
            },
            {
                "key": "session_filter",
                "label": "Enable Session Filter (07:00 - 21:00 UTC)",
                "type": "bool",
                "default": False,
            },
        ]

    @classmethod
    def get_default_params(cls) -> Dict[str, Any]:
        return {d["key"]: d["default"] for d in cls.get_param_defs()}

    # =========================================================================
    # MODULAR & UNIT-TESTABLE SMC CORE HELPERS
    # =========================================================================

    @staticmethod
    def _compute_atr(df: pd.DataFrame, period: int) -> pd.Series:
        high = df["high"]
        low = df["low"]
        prev_close = df["close"].shift(1)
        tr = pd.concat(
            [high - low, (high - prev_close).abs(), (low - prev_close).abs()], axis=1
        ).max(axis=1)
        return tr.ewm(span=period, adjust=False).mean()

    @staticmethod
    def _compute_confirmed_swings(
        df: pd.DataFrame, left_right: int
    ) -> Tuple[pd.Series, pd.Series]:
        """
        Detects confirmed Swing Highs and Swing Lows using a (2*left_right + 1) window.
        To strictly eliminate lookahead bias, a swing occurring at bar `k - left_right`
        is only confirmed and recorded at bar `k` (after `left_right` right-side bars close).
        """
        n = len(df)
        highs = df["high"].to_numpy()
        lows = df["low"].to_numpy()

        confirmed_sh = np.full(n, np.nan)
        confirmed_sl = np.full(n, np.nan)

        last_sh = np.nan
        last_sl = np.nan

        for k in range(2 * left_right, n):
            pivot_idx = k - left_right
            window_h = highs[pivot_idx - left_right : k + 1]
            window_l = lows[pivot_idx - left_right : k + 1]

            if highs[pivot_idx] == np.max(window_h):
                last_sh = highs[pivot_idx]
            if lows[pivot_idx] == np.min(window_l):
                last_sl = lows[pivot_idx]

            confirmed_sh[k] = last_sh
            confirmed_sl[k] = last_sl

        return (
            pd.Series(confirmed_sh, index=df.index),
            pd.Series(confirmed_sl, index=df.index),
        )

    def _calculate_cycle_lot(
        self, entry_price: float, sl_price: float, allocation_pct: float
    ) -> float:
        """
        Calculates total cycle lot `X` from platform context, then scales by `allocation_pct`
        (e.g., 0.5 for X_limit or 0.5 for X_confirm).
        """
        min_lot = 0.01
        if self.sizing_mode == "fixed":
            total_x = max(min_lot, float(self.lot_size))
        else:
            balance = self.initial_capital
            risk_usd = balance * (self.risk_pct / 100.0)
            sl_dist = abs(entry_price - sl_price)
            if sl_dist <= 1e-9:
                total_x = max(min_lot, float(self.lot_size))
            else:
                total_x = risk_usd / (sl_dist * self.multiplier)

        leg_lot = total_x * float(allocation_pct)
        return max(min_lot, round(leg_lot, 2))

    # =========================================================================
    # GATE 1: H4 BIAS CALCULATION (ZERO LOOKAHEAD)
    # =========================================================================

    def _evaluate_h4_bias(
        self, df_h4: pd.DataFrame, swing_len: int, atr_period: int, range_min_atr: float, sweep_min_atr: float
    ) -> pd.DataFrame:
        """
        Computes H4 Market Structure (BOS/CHoCH), Premium/Discount, and Gate 1 Bias.
        All outputs are shifted by 1 bar before mapping to LTF to guarantee zero lookahead.
        """
        n = len(df_h4)
        atr_h4 = self._compute_atr(df_h4, atr_period)
        sh_series, sl_series = self._compute_confirmed_swings(df_h4, swing_len)

        closes = df_h4["close"].to_numpy()
        highs = df_h4["high"].to_numpy()
        lows = df_h4["low"].to_numpy()
        atrs = atr_h4.to_numpy()
        sh_arr = sh_series.to_numpy()
        sl_arr = sl_series.to_numpy()

        bias_arr = np.zeros(n, dtype=int)  # 1 = Bullish, -1 = Bearish, 0 = Neutral
        eq_arr = np.full(n, np.nan)

        structure_dir = 0  # 1 = Bullish, -1 = Bearish
        prev_sh = np.nan
        prev_sl = np.nan
        recent_chochs: List[int] = []  # Tracks directions of recent CHoCHs

        for i in range(1, n):
            cur_sh = sh_arr[i]
            cur_sl = sl_arr[i]
            cur_c = closes[i]
            cur_h = highs[i]
            cur_l = lows[i]
            cur_atr = atrs[i] if not np.isnan(atrs[i]) and atrs[i] > 0 else 1e-6

            if np.isnan(cur_sh) or np.isnan(cur_sl) or cur_sh <= cur_sl:
                continue

            range_width = cur_sh - cur_sl
            eq_price = cur_sl + 0.5 * range_width
            eq_arr[i] = eq_price

            # Track Higher Highs / Higher Lows & Lower Highs / Lower Lows
            is_hh_hl = (not np.isnan(prev_sh) and not np.isnan(prev_sl)) and (
                cur_sh >= prev_sh and cur_sl >= prev_sl
            )
            is_lh_ll = (not np.isnan(prev_sh) and not np.isnan(prev_sl)) and (
                cur_sh <= prev_sh and cur_sl <= prev_sl
            )

            # Check Sweeps on H4
            swept_low = (cur_sl - cur_l) >= (sweep_min_atr * cur_atr) and (cur_c > cur_sl)
            swept_high = (cur_h - cur_sh) >= (sweep_min_atr * cur_atr) and (cur_c < cur_sh)

            # Check BOS / CHoCH using CLOSE price only
            broke_up = cur_c > cur_sh
            broke_down = cur_c < cur_sl

            bos_bull = False
            bos_bear = False
            choch_bull = False
            choch_bear = False

            if broke_up:
                if structure_dir >= 0:
                    bos_bull = True
                else:
                    choch_bull = True
                    recent_chochs.append(1)
                structure_dir = 1
            elif broke_down:
                if structure_dir <= 0:
                    bos_bear = True
                else:
                    choch_bear = True
                    recent_chochs.append(-1)
                structure_dir = -1

            if len(recent_chochs) > 2:
                recent_chochs = recent_chochs[-2:]

            # Neutral / No-Trade Filters (Section 3)
            range_too_compressed = range_width < (range_min_atr * cur_atr)
            opposing_chochs = (
                len(recent_chochs) == 2 and recent_chochs[0] == -recent_chochs[1]
            )
            pct_in_range = (cur_c - cur_sl) / range_width
            in_equilibrium = 0.475 <= pct_in_range <= 0.525

            if range_too_compressed or opposing_chochs or in_equilibrium:
                bias_arr[i] = 0
            else:
                in_discount = pct_in_range < 0.475
                in_premium = pct_in_range > 0.525

                bull_cond = (
                    bos_bull
                    or (choch_bull and swept_low)
                    or (structure_dir == 1 and in_discount)
                    or (in_discount and is_hh_hl)
                )
                bear_cond = (
                    bos_bear
                    or (choch_bear and swept_high)
                    or (structure_dir == -1 and in_premium)
                    or (in_premium and is_lh_ll)
                )

                if bull_cond and not bear_cond:
                    bias_arr[i] = 1
                elif bear_cond and not bull_cond:
                    bias_arr[i] = -1
                else:
                    bias_arr[i] = structure_dir if not in_equilibrium else 0

            prev_sh = cur_sh
            prev_sl = cur_sl

        res = pd.DataFrame(
            {
                "h4_bias": bias_arr,
                "h4_sh": sh_arr,
                "h4_sl": sl_arr,
                "h4_eq": eq_arr,
                "h4_atr": atrs,
            },
            index=df_h4.index,
        )
        # Shift by 1 completed H4 bar to prevent Lookahead Bias on LTF
        return res.shift(1)

    # =========================================================================
    # GATE 2: H1 POI ZONE DETECTION & MITIGATION TRACKING
    # =========================================================================

    def _extract_h1_zones(
        self,
        df_h1: pd.DataFrame,
        swing_len: int,
        atr_period: int,
        disp_min_atr: float,
        z_max_size_atr: float,
    ) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
        """
        Detects H1 Bullish/Bearish Order Blocks (OB) and Fair Value Gaps (FVG),
        plus H1 confirmed swings for TP1 opposing liquidity targets.
        """
        n = len(df_h1)
        atr_h1 = self._compute_atr(df_h1, atr_period)
        sh_h1, sl_h1 = self._compute_confirmed_swings(df_h1, swing_len)

        opens = df_h1["open"].to_numpy()
        highs = df_h1["high"].to_numpy()
        lows = df_h1["low"].to_numpy()
        closes = df_h1["close"].to_numpy()
        atrs = atr_h1.to_numpy()
        times = df_h1.index

        zones: List[Dict[str, Any]] = []

        for i in range(2, n):
            cur_atr = atrs[i] if not np.isnan(atrs[i]) and atrs[i] > 0 else 1e-6

            # 1. Bullish FVG: High of candle i-2 < Low of candle i
            if highs[i - 2] < lows[i]:
                top = float(lows[i])
                bottom = float(highs[i - 2])
                width = top - bottom
                if 0 < width <= (z_max_size_atr * cur_atr):
                    zones.append(
                        {
                            "dir": 1,
                            "type": "FVG",
                            "top": top,
                            "bottom": bottom,
                            "created_idx": i,
                            "confirmed_time": times[i],
                            "mitigated_idx": None,
                        }
                    )

            # 2. Bearish FVG: Low of candle i-2 > High of candle i
            if lows[i - 2] > highs[i]:
                top = float(lows[i - 2])
                bottom = float(highs[i])
                width = top - bottom
                if 0 < width <= (z_max_size_atr * cur_atr):
                    zones.append(
                        {
                            "dir": -1,
                            "type": "FVG",
                            "top": top,
                            "bottom": bottom,
                            "created_idx": i,
                            "confirmed_time": times[i],
                            "mitigated_idx": None,
                        }
                    )

            # 3. Bullish OB: Candle i-1 is bearish (body >= 50% range) before strong bullish displacement at i
            prev_range = highs[i - 1] - lows[i - 1]
            prev_body = abs(closes[i - 1] - opens[i - 1])
            cur_body = abs(closes[i] - opens[i])

            if (
                closes[i - 1] < opens[i - 1]
                and prev_range > 0
                and (prev_body / prev_range) >= 0.5
                and closes[i] > opens[i]
                and cur_body >= (disp_min_atr * cur_atr)
                and closes[i] > highs[i - 1]
            ):
                top = float(highs[i - 1])
                bottom = float(lows[i - 1])
                width = top - bottom
                if 0 < width <= (z_max_size_atr * cur_atr):
                    zones.append(
                        {
                            "dir": 1,
                            "type": "OB",
                            "top": top,
                            "bottom": bottom,
                            "created_idx": i,
                            "confirmed_time": times[i],
                            "mitigated_idx": None,
                        }
                    )

            # 4. Bearish OB: Candle i-1 is bullish (body >= 50% range) before strong bearish displacement at i
            if (
                closes[i - 1] > opens[i - 1]
                and prev_range > 0
                and (prev_body / prev_range) >= 0.5
                and closes[i] < opens[i]
                and cur_body >= (disp_min_atr * cur_atr)
                and closes[i] < lows[i - 1]
            ):
                top = float(highs[i - 1])
                bottom = float(lows[i - 1])
                width = top - bottom
                if 0 < width <= (z_max_size_atr * cur_atr):
                    zones.append(
                        {
                            "dir": -1,
                            "type": "OB",
                            "top": top,
                            "bottom": bottom,
                            "created_idx": i,
                            "confirmed_time": times[i],
                            "mitigated_idx": None,
                        }
                    )

            # Check Zone Mitigation on H1 CLOSE beyond far side (Section 2.8)
            for z in zones:
                if z["mitigated_idx"] is None and i > z["created_idx"]:
                    if z["dir"] == 1 and closes[i] < z["bottom"]:
                        z["mitigated_idx"] = i
                    elif z["dir"] == -1 and closes[i] > z["top"]:
                        z["mitigated_idx"] = i

        h1_meta = pd.DataFrame(
            {
                "h1_idx": np.arange(n, dtype=float),
                "h1_sh": sh_h1.to_numpy(),
                "h1_sl": sl_h1.to_numpy(),
                "h1_atr": atrs,
            },
            index=df_h1.index,
        ).shift(1)

        return h1_meta, zones

    # =========================================================================
    # MAIN SIGNAL & STATE MACHINE ENGINE (M15)
    # =========================================================================

    def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
        n = len(df)
        signals = pd.Series(0, index=df.index, dtype=int)
        sl_series = pd.Series(0.0, index=df.index, dtype=float)
        tp_series = pd.Series(0.0, index=df.index, dtype=float)
        sizes_series = pd.Series(0.0, index=df.index, dtype=float)

        if n < 60:
            return {
                "signals": signals,
                "sl": sl_series,
                "tp": tp_series,
                "sizes": sizes_series,
                "overlays": {},
            }

        # Extract Strategy Parameters
        entry_mode = str(self.params.get("entry_mode", "C")).upper().strip()
        tp_mode = str(self.params.get("tp_mode", "A")).upper().strip()
        x_limit_pct = float(self.params.get("x_limit_pct", 0.5))
        x_confirm_pct = float(self.params.get("x_confirm_pct", 0.5))
        swing_len = int(self.params.get("swing_len", 3))
        atr_period = int(self.params.get("atr_period", 14))
        buffer_atr_mult = float(self.params.get("buffer_atr_mult", 0.3))
        sweep_min_atr = float(self.params.get("sweep_min_atr", 0.15))
        z_max_age = int(self.params.get("z_max_age", 40))
        z_max_size_atr = float(self.params.get("z_max_size_atr", 1.5))
        t_max_wait = int(self.params.get("t_max_wait", 4))
        disp_min_atr = float(self.params.get("disp_min_atr", 0.5))
        rr_min = float(self.params.get("rr_min", 1.5))
        range_min_atr = float(self.params.get("range_min_atr", 1.2))
        trail_after_r = float(self.params.get("trail_after_r", 1.0))
        session_filter = bool(self.params.get("session_filter", False))

        # 1. Prepare DatetimeIndex for Multi-Timeframe Resampling
        work_df = df.copy()
        if "time" in work_df.columns:
            t_vals = work_df["time"].to_numpy()
            unit = "ms" if np.median(t_vals) > 1e11 else "s"
            dt_index = pd.to_datetime(t_vals, unit=unit, utc=True)
        elif isinstance(work_df.index, pd.DatetimeIndex):
            dt_index = work_df.index
        else:
            dt_index = pd.date_range("2025-01-01", periods=n, freq="15min", tz="UTC")

        work_df.index = dt_index

        # 2. Resample to H4 & H1 with Zero Lookahead Shift
        ohlc_agg = {
            "open": "first",
            "high": "max",
            "low": "min",
            "close": "last",
        }
        df_h4 = work_df.resample("4h").agg(ohlc_agg).dropna()
        df_h1 = work_df.resample("1h").agg(ohlc_agg).dropna()

        if len(df_h4) < 10 or len(df_h1) < 20:
            return {
                "signals": signals,
                "sl": sl_series,
                "tp": tp_series,
                "sizes": sizes_series,
                "overlays": {},
            }

        h4_aligned = (
            self._evaluate_h4_bias(
                df_h4, swing_len, atr_period, range_min_atr, sweep_min_atr
            )
            .reindex(work_df.index, method="ffill")
        )
        h1_meta, h1_zones = self._extract_h1_zones(
            df_h1, swing_len, atr_period, disp_min_atr, z_max_size_atr
        )
        h1_aligned = h1_meta.reindex(work_df.index, method="ffill")

        # 3. M15 Indicators & Confirmed Swings
        atr_m15 = self._compute_atr(work_df, atr_period).to_numpy()
        m15_sh_s, m15_sl_s = self._compute_confirmed_swings(work_df, swing_len)
        m15_sh = m15_sh_s.to_numpy()
        m15_sl = m15_sl_s.to_numpy()

        opens = work_df["open"].to_numpy()
        highs = work_df["high"].to_numpy()
        lows = work_df["low"].to_numpy()
        closes = work_df["close"].to_numpy()
        hours = dt_index.hour.to_numpy()

        h4_bias_arr = h4_aligned["h4_bias"].fillna(0).to_numpy(dtype=int)
        h4_sh_arr = h4_aligned["h4_sh"].to_numpy()
        h4_sl_arr = h4_aligned["h4_sl"].to_numpy()
        h4_eq_arr = h4_aligned["h4_eq"].to_numpy()

        h1_idx_arr = h1_aligned["h1_idx"].to_numpy()
        h1_sh_arr = h1_aligned["h1_sh"].to_numpy()
        h1_sl_arr = h1_aligned["h1_sl"].to_numpy()

        # Overlay tracking arrays for Active H1 POI Zone
        active_zone_top = np.full(n, np.nan)
        active_zone_bot = np.full(n, np.nan)

        # 4. State Machine Variables (Section 8)
        # States: "IDLE", "ARMED", "IN_ZONE", "IN_TRADE"
        state = "IDLE"
        active_zone: Optional[Dict[str, Any]] = None
        active_dir: int = 0
        leg1_filled: bool = False
        leg2_filled: bool = False
        cycle_sl: float = 0.0
        cycle_tp1: float = 0.0
        cycle_tp2: float = 0.0
        cycle_entry_price: float = 0.0
        sweep_detected_bar: Optional[int] = None
        swept_extreme: float = np.nan
        used_zone_ids = set()

        for i in range(2 * swing_len + 2, n):
            cur_o = opens[i]
            cur_h = highs[i]
            cur_l = lows[i]
            cur_c = closes[i]
            cur_atr = atr_m15[i] if not np.isnan(atr_m15[i]) and atr_m15[i] > 0 else 1e-5

            bias = int(h4_bias_arr[i])
            h4_sh = h4_sh_arr[i]
            h4_sl = h4_sl_arr[i]
            h4_eq = h4_eq_arr[i]
            cur_h1_idx = h1_idx_arr[i]

            # Session Filter Check
            if session_filter and not (7 <= hours[i] < 21):
                if state in ("ARMED", "IN_ZONE") and not leg1_filled:
                    state = "IDLE"
                    active_zone = None
                continue

            # Hard Rule (Section 3 & Scenario 6/7): If Bias == Neutral or Flips -> Reset non-filled cycles
            if bias == 0 or (active_dir != 0 and bias != active_dir):
                if state in ("ARMED", "IN_ZONE", "IDLE"):
                    state = "IDLE"
                    active_zone = None
                    active_dir = 0
                    leg1_filled = False
                    leg2_filled = False
                    sweep_detected_bar = None
                elif state == "IN_TRADE" and bias == -active_dir:
                    # Scenario 7: Opposing Bias flip while in trade -> Reset cycle
                    state = "IDLE"
                    active_zone = None
                    active_dir = 0
                    leg1_filled = False
                    leg2_filled = False
                    sweep_detected_bar = None

            if entry_mode == "F":
                continue

            # -----------------------------------------------------------------
            # STATE: IN_TRADE (Manage SL / TP / Breakeven Trailing / Leg 2)
            # -----------------------------------------------------------------
            if state == "IN_TRADE":
                # Check if SL or TP was hit on current bar
                if active_dir == 1:
                    r_dist = max(1e-6, cycle_entry_price - cycle_sl)
                    if (cur_h - cycle_entry_price) >= (trail_after_r * r_dist):
                        cycle_sl = max(cycle_sl, cycle_entry_price)
                    if cur_l <= cycle_sl or cur_h >= cycle_tp1:
                        state = "IDLE"
                        active_zone = None
                        active_dir = 0
                        leg1_filled = False
                        leg2_filled = False
                        continue
                elif active_dir == -1:
                    r_dist = max(1e-6, cycle_sl - cycle_entry_price)
                    if (cycle_entry_price - cur_l) >= (trail_after_r * r_dist):
                        cycle_sl = min(cycle_sl, cycle_entry_price)
                    if cur_h >= cycle_sl or cur_l <= cycle_tp1:
                        state = "IDLE"
                        active_zone = None
                        active_dir = 0
                        leg1_filled = False
                        leg2_filled = False
                        continue

                # If Leg 1 (Limit 50%) is filled and we are waiting for Leg 2 (Market Confirm 50%) in Model C
                if entry_mode == "C" and leg1_filled and not leg2_filled and active_zone is not None:
                    active_zone_top[i] = active_zone["top"]
                    active_zone_bot[i] = active_zone["bottom"]

                    # Check M15 Sweep + CHoCH/BOS Confirmation for Leg 2
                    ref_low = m15_sl[i] if not np.isnan(m15_sl[i]) else active_zone["bottom"]
                    ref_high = m15_sh[i] if not np.isnan(m15_sh[i]) else active_zone["top"]

                    if active_dir == 1:
                        if (ref_low - cur_l) >= (sweep_min_atr * cur_atr) and cur_c > ref_low:
                            sweep_detected_bar = i
                        if sweep_detected_bar is not None and (i - sweep_detected_bar) <= t_max_wait:
                            disp_ok = (cur_c - cur_o) >= (disp_min_atr * cur_atr)
                            if (cur_c > m15_sh[i] or disp_ok) and cur_c > cur_o:
                                target_tp = cycle_tp2 if tp_mode == "B" else cycle_tp1
                                lot2 = self._calculate_cycle_lot(cur_c, cycle_sl, x_confirm_pct)
                                signals.iloc[i] = 1
                                sl_series.iloc[i] = round(cycle_sl, 5)
                                tp_series.iloc[i] = round(target_tp, 5)
                                sizes_series.iloc[i] = lot2
                                leg2_filled = True
                    elif active_dir == -1:
                        if (cur_h - ref_high) >= (sweep_min_atr * cur_atr) and cur_c < ref_high:
                            sweep_detected_bar = i
                        if sweep_detected_bar is not None and (i - sweep_detected_bar) <= t_max_wait:
                            disp_ok = (cur_o - cur_c) >= (disp_min_atr * cur_atr)
                            if (cur_c < m15_sl[i] or disp_ok) and cur_c < cur_o:
                                target_tp = cycle_tp2 if tp_mode == "B" else cycle_tp1
                                lot2 = self._calculate_cycle_lot(cur_c, cycle_sl, x_confirm_pct)
                                signals.iloc[i] = -1
                                sl_series.iloc[i] = round(cycle_sl, 5)
                                tp_series.iloc[i] = round(target_tp, 5)
                                sizes_series.iloc[i] = lot2
                                leg2_filled = True

                continue

            # -----------------------------------------------------------------
            # STATE: IDLE -> Look for Valid Gate 1 (H4 Bias) + Gate 2 (H1 Zone)
            # -----------------------------------------------------------------
            if state == "IDLE" and bias != 0 and not np.isnan(cur_h1_idx) and not np.isnan(h4_eq):
                best_zone = None
                best_score = -1e9

                for z_idx, z in enumerate(h1_zones):
                    if z_idx in used_zone_ids:
                        continue
                    if z["dir"] != bias:
                        continue
                    # Must be created on or before the last completed H1 bar
                    age = int(cur_h1_idx) - z["created_idx"]
                    if age < 0 or age > z_max_age:
                        continue
                    # Must not be mitigated yet
                    if z["mitigated_idx"] is not None and int(cur_h1_idx) >= z["mitigated_idx"]:
                        continue
                    # Must be in Discount (for Buy) or Premium (for Sell) of current H4 range
                    z_mid = 0.5 * (z["top"] + z["bottom"])
                    if bias == 1 and z_mid >= h4_eq:
                        continue
                    if bias == -1 and z_mid <= h4_eq:
                        continue

                    # Check Confluence (Overlapping OB + FVG within 0.3 * ATR)
                    has_confluence = False
                    for other in h1_zones:
                        if (
                            other is not z
                            and other["dir"] == z["dir"]
                            and other["type"] != z["type"]
                            and abs(int(cur_h1_idx) - other["created_idx"]) <= z_max_age
                        ):
                            overlap = min(z["top"], other["top"]) - max(z["bottom"], other["bottom"])
                            if overlap >= -(0.3 * cur_atr):
                                has_confluence = True
                                break

                    dist_to_price = abs(cur_c - z_mid)
                    score = (1000.0 if has_confluence else 0.0) - dist_to_price
                    if score > best_score:
                        best_score = score
                        best_zone = (z_idx, z)

                if best_zone is not None:
                    z_id, z_obj = best_zone
                    active_zone = z_obj
                    active_zone["_id"] = z_id
                    active_dir = bias
                    state = "ARMED"
                    leg1_filled = False
                    leg2_filled = False
                    sweep_detected_bar = None
                    swept_extreme = np.nan

            # -----------------------------------------------------------------
            # STATE: ARMED / IN_ZONE -> Gate 3 (M15 Trigger & Model Execution)
            # -----------------------------------------------------------------
            if state in ("ARMED", "IN_ZONE") and active_zone is not None:
                # Validate zone age & mitigation on each bar
                age = int(cur_h1_idx) - active_zone["created_idx"] if not np.isnan(cur_h1_idx) else 0
                is_mitigated = (
                    active_zone["mitigated_idx"] is not None
                    and not np.isnan(cur_h1_idx)
                    and int(cur_h1_idx) >= active_zone["mitigated_idx"]
                )
                if age > z_max_age or is_mitigated:
                    state = "IDLE"
                    active_zone = None
                    active_dir = 0
                    continue

                z_top = active_zone["top"]
                z_bot = active_zone["bottom"]
                active_zone_top[i] = z_top
                active_zone_bot[i] = z_bot

                # Calculate Shared Stop Loss & TP1/TP2 Levels (Section 7.1 & 7.2)
                spread_buf = self.spread_usd * 1.5 if self.spread_usd > 0 else 0.0
                buffer = max(buffer_atr_mult * cur_atr, spread_buf, 1e-5)

                if active_dir == 1:
                    ref_m15_low = m15_sl[i] if not np.isnan(m15_sl[i]) else z_bot
                    shared_sl = min(z_bot - buffer, ref_m15_low - buffer)
                    if not np.isnan(swept_extreme):
                        shared_sl = min(shared_sl, swept_extreme - buffer)

                    risk_dist = max(1e-6, z_top - shared_sl)
                    tp1_candidate = h1_sh_arr[i] if not np.isnan(h1_sh_arr[i]) else (z_top + rr_min * risk_dist)
                    tp1 = max(tp1_candidate, z_top + rr_min * risk_dist)
                    tp2_candidate = h4_sh if not np.isnan(h4_sh) else (z_top + (rr_min + 1.0) * risk_dist)
                    tp2 = max(tp2_candidate, tp1 + 0.5 * risk_dist)

                    # Check if price enters the H1 Zone
                    touches_zone = cur_l <= z_top and cur_h >= z_bot
                    if touches_zone and state == "ARMED":
                        state = "IN_ZONE"

                    # Invalidation: M15 closes beyond SL before trigger completes
                    if cur_c < shared_sl:
                        used_zone_ids.add(active_zone["_id"])
                        state = "IDLE"
                        active_zone = None
                        continue

                    # MODEL A (Pure Limit 100%) or MODEL C Leg 1 (Limit 50% at POI near edge)
                    if touches_zone and not leg1_filled and entry_mode in ("A", "C"):
                        alloc = 1.0 if entry_mode == "A" else x_limit_pct
                        entry_px = min(cur_o, z_top) if cur_o <= z_top else z_top
                        sl_dist = max(1e-6, entry_px - shared_sl)
                        tp_px = max(tp1, entry_px + rr_min * sl_dist)
                        lot1 = self._calculate_cycle_lot(entry_px, shared_sl, alloc)

                        signals.iloc[i] = 1
                        sl_series.iloc[i] = round(shared_sl, 5)
                        tp_series.iloc[i] = round(tp_px, 5)
                        sizes_series.iloc[i] = lot1

                        leg1_filled = True
                        cycle_sl = shared_sl
                        cycle_tp1 = tp_px
                        cycle_tp2 = max(tp2, tp_px + 0.5 * sl_dist)
                        cycle_entry_price = entry_px
                        used_zone_ids.add(active_zone["_id"])
                        state = "IN_TRADE"
                        continue

                    # Detect M15 Liquidity Sweep for Gate 3 Trigger
                    if state == "IN_ZONE":
                        ref_swing_l = m15_sl[i] if not np.isnan(m15_sl[i]) else z_bot
                        penetration = ref_swing_l - cur_l
                        if penetration >= (sweep_min_atr * cur_atr) and cur_c > z_bot:
                            sweep_detected_bar = i
                            swept_extreme = cur_l

                        # Check Timeout (T_max_wait M15 bars after sweep)
                        if sweep_detected_bar is not None and (i - sweep_detected_bar) > t_max_wait:
                            sweep_detected_bar = None
                            swept_extreme = np.nan

                        # Valid M15 CHoCH / BOS Close + Displacement
                        disp_ok = (cur_c - cur_o) >= (disp_min_atr * cur_atr)
                        choch_bos_up = (
                            not np.isnan(m15_sh[i]) and cur_c > m15_sh[i]
                        ) or (disp_ok and cur_c > z_top)

                        if sweep_detected_bar is not None and choch_bos_up and cur_c > cur_o:
                            alloc = (
                                x_confirm_pct
                                if entry_mode in ("C", "D")
                                else 1.0
                            )
                            sl_dist = max(1e-6, cur_c - shared_sl)
                            tp_px = max(tp1, cur_c + rr_min * sl_dist)
                            lot_trig = self._calculate_cycle_lot(cur_c, shared_sl, alloc)

                            signals.iloc[i] = 1
                            sl_series.iloc[i] = round(shared_sl, 5)
                            tp_series.iloc[i] = round(tp_px, 5)
                            sizes_series.iloc[i] = lot_trig

                            leg2_filled = True
                            cycle_sl = shared_sl
                            cycle_tp1 = tp_px
                            cycle_tp2 = max(tp2, tp_px + 0.5 * sl_dist)
                            cycle_entry_price = cur_c
                            used_zone_ids.add(active_zone["_id"])
                            state = "IN_TRADE"
                            continue

                elif active_dir == -1:
                    ref_m15_high = m15_sh[i] if not np.isnan(m15_sh[i]) else z_top
                    shared_sl = max(z_top + buffer, ref_m15_high + buffer)
                    if not np.isnan(swept_extreme):
                        shared_sl = max(shared_sl, swept_extreme + buffer)

                    risk_dist = max(1e-6, shared_sl - z_bot)
                    tp1_candidate = h1_sl_arr[i] if not np.isnan(h1_sl_arr[i]) else (z_bot - rr_min * risk_dist)
                    tp1 = min(tp1_candidate, z_bot - rr_min * risk_dist)
                    tp2_candidate = h4_sl if not np.isnan(h4_sl) else (z_bot - (rr_min + 1.0) * risk_dist)
                    tp2 = min(tp2_candidate, tp1 - 0.5 * risk_dist)

                    # Check if price enters the H1 Zone
                    touches_zone = cur_h >= z_bot and cur_l <= z_top
                    if touches_zone and state == "ARMED":
                        state = "IN_ZONE"

                    # Invalidation: M15 closes beyond SL before trigger completes
                    if cur_c > shared_sl:
                        used_zone_ids.add(active_zone["_id"])
                        state = "IDLE"
                        active_zone = None
                        continue

                    # MODEL A (Pure Limit 100%) or MODEL C Leg 1 (Limit 50% at POI near edge)
                    if touches_zone and not leg1_filled and entry_mode in ("A", "C"):
                        alloc = 1.0 if entry_mode == "A" else x_limit_pct
                        entry_px = max(cur_o, z_bot) if cur_o >= z_bot else z_bot
                        sl_dist = max(1e-6, shared_sl - entry_px)
                        tp_px = min(tp1, entry_px - rr_min * sl_dist)
                        lot1 = self._calculate_cycle_lot(entry_px, shared_sl, alloc)

                        signals.iloc[i] = -1
                        sl_series.iloc[i] = round(shared_sl, 5)
                        tp_series.iloc[i] = round(tp_px, 5)
                        sizes_series.iloc[i] = lot1

                        leg1_filled = True
                        cycle_sl = shared_sl
                        cycle_tp1 = tp_px
                        cycle_tp2 = min(tp2, tp_px - 0.5 * sl_dist)
                        cycle_entry_price = entry_px
                        used_zone_ids.add(active_zone["_id"])
                        state = "IN_TRADE"
                        continue

                    # Detect M15 Liquidity Sweep for Gate 3 Trigger
                    if state == "IN_ZONE":
                        ref_swing_h = m15_sh[i] if not np.isnan(m15_sh[i]) else z_top
                        penetration = cur_h - ref_swing_h
                        if penetration >= (sweep_min_atr * cur_atr) and cur_c < z_top:
                            sweep_detected_bar = i
                            swept_extreme = cur_h

                        # Check Timeout (T_max_wait M15 bars after sweep)
                        if sweep_detected_bar is not None and (i - sweep_detected_bar) > t_max_wait:
                            sweep_detected_bar = None
                            swept_extreme = np.nan

                        # Valid M15 CHoCH / BOS Close + Displacement
                        disp_ok = (cur_o - cur_c) >= (disp_min_atr * cur_atr)
                        choch_bos_down = (
                            not np.isnan(m15_sl[i]) and cur_c < m15_sl[i]
                        ) or (disp_ok and cur_c < z_bot)

                        if sweep_detected_bar is not None and choch_bos_down and cur_c < cur_o:
                            alloc = (
                                x_confirm_pct
                                if entry_mode in ("C", "D")
                                else 1.0
                            )
                            sl_dist = max(1e-6, shared_sl - cur_c)
                            tp_px = min(tp1, cur_c - rr_min * sl_dist)
                            lot_trig = self._calculate_cycle_lot(cur_c, shared_sl, alloc)

                            signals.iloc[i] = -1
                            sl_series.iloc[i] = round(shared_sl, 5)
                            tp_series.iloc[i] = round(tp_px, 5)
                            sizes_series.iloc[i] = lot_trig

                            leg2_filled = True
                            cycle_sl = shared_sl
                            cycle_tp1 = tp_px
                            cycle_tp2 = min(tp2, tp_px - 0.5 * sl_dist)
                            cycle_entry_price = cur_c
                            used_zone_ids.add(active_zone["_id"])
                            state = "IN_TRADE"
                            continue

        # 5. Package JSON-Safe Overlays (Strictly Stripping NaNs)
        times = df["time"].to_numpy() if "time" in df.columns else np.arange(n)

        overlays = {
            "h4_swing_high": {
                "title": "H4 Swing High (Premium Top)",
                "color": "#EF5350",
                "lineWidth": 1,
                "data": [
                    {"time": int(t), "value": round(float(v), 5)}
                    for t, v in zip(times, h4_sh_arr)
                    if not np.isnan(v)
                ],
            },
            "h4_equilibrium": {
                "title": "H4 Equilibrium (50% P/D)",
                "color": "#FFCA28",
                "lineWidth": 1,
                "data": [
                    {"time": int(t), "value": round(float(v), 5)}
                    for t, v in zip(times, h4_eq_arr)
                    if not np.isnan(v)
                ],
            },
            "h4_swing_low": {
                "title": "H4 Swing Low (Discount Bottom)",
                "color": "#26A69A",
                "lineWidth": 1,
                "data": [
                    {"time": int(t), "value": round(float(v), 5)}
                    for t, v in zip(times, h4_sl_arr)
                    if not np.isnan(v)
                ],
            },
            "h1_poi_top": {
                "title": "Active H1 POI Zone (Top)",
                "color": "#2962FF",
                "lineWidth": 2,
                "data": [
                    {"time": int(t), "value": round(float(v), 5)}
                    for t, v in zip(times, active_zone_top)
                    if not np.isnan(v)
                ],
            },
            "h1_poi_bottom": {
                "title": "Active H1 POI Zone (Bottom)",
                "color": "#2962FF",
                "lineWidth": 2,
                "data": [
                    {"time": int(t), "value": round(float(v), 5)}
                    for t, v in zip(times, active_zone_bot)
                    if not np.isnan(v)
                ],
            },
        }

        return {
            "signals": signals,
            "sl": sl_series,
            "tp": tp_series,
            "sizes": sizes_series,
            "overlays": overlays,
        }