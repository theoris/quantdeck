/**
 * QuantDeck Custom Indicator TypeScript Template
 * You can save this file as `.ts` or `.js` in `F:\GIT\App28_bot\chart\custom_indicators\`
 */

export interface OHLCBar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface IndicatorParamDef {
  key: string;
  label: string;
  type: 'number' | 'color' | 'select' | 'text';
  default: any;
  options?: Array<{ label: string; value: any }>;
  min?: number;
  max?: number;
  step?: number;
  placeholder?: string;
}

export interface CustomIndicatorDefinition {
  name: string;
  pane: 'main' | 'sub';
  description?: string;
  params: Record<string, any>;
  paramDefs: IndicatorParamDef[];
  calculate: (bars: OHLCBar[], params: Record<string, any>) => any;
}

const template: CustomIndicatorDefinition = {
  name: "MyCustomIndicator",
  pane: "main", // Use "main" for price overlays, or "sub" for lower oscillator pane
  description: "Custom mathematical indicator algorithm",
  params: {
    period: 20,
    color: "#00bcd4",
    lineWidth: 2
  },
  paramDefs: [
    { key: "period", label: "Period", type: "number", default: 20, min: 1, max: 200 },
    { key: "color", label: "Line Color", type: "color", default: "#00bcd4" },
    {
      key: "lineWidth",
      label: "Line Width",
      type: "select",
      default: 2,
      options: [
        { label: "1px", value: 1 },
        { label: "2px", value: 2 },
        { label: "3px", value: 3 }
      ]
    }
  ],

  calculate(bars: OHLCBar[], params: Record<string, any>) {
    const period = params.period || 20;
    if (!bars || bars.length < period) return [];

    const result = [];
    for (let i = period - 1; i < bars.length; i++) {
      let sum = 0;
      for (let j = i - period + 1; j <= i; j++) {
        sum += bars[j].close;
      }
      result.push({
        time: bars[i].time,
        value: sum / period
      });
    }
    return result;
  }
};

export default template;
