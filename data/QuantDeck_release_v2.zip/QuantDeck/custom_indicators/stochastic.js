/**
 * Stochastic Oscillator for QuantDeck
 * Type: Sub-Pane
 * Description: %K and %D Momentum Oscillator with Overbought/Oversold levels
 */

export default {
  name: "Stochastic Oscillator",
  pane: "sub",
  description: "%K and %D Momentum Oscillator (80/20 Levels)",
  params: {
    kPeriod: 14,
    dPeriod: 3,
    slowing: 3,
    kColor: "#2196f3",
    dColor: "#ff9800",
    lineWidth: 2
  },
  paramDefs: [
    { key: "kPeriod", label: "%K Period", type: "number", default: 14, min: 2, max: 100 },
    { key: "dPeriod", label: "%D Period", type: "number", default: 3, min: 1, max: 50 },
    { key: "slowing", label: "Slowing", type: "number", default: 3, min: 1, max: 50 },
    { key: "kColor", label: "%K Color", type: "color", default: "#2196f3" },
    { key: "dColor", label: "%D Color", type: "color", default: "#ff9800" },
    {
      key: "lineWidth",
      label: "Line Width",
      type: "select",
      default: 2,
      options: [
        { label: "1px", value: 1 },
        { label: "2px", value: 2 },
        { label: "3px", value: 3 }
      ]
    }
  ],

  calculate(bars, params) {
    const kPeriod = params.kPeriod || 14;
    const dPeriod = params.dPeriod || 3;
    const slowing = params.slowing || 3;

    if (!bars || bars.length < kPeriod + dPeriod + slowing) return { k: [], d: [] };

    // 1. Raw Fast %K
    const fastK = [];
    for (let i = kPeriod - 1; i < bars.length; i++) {
      let highest = -Infinity;
      let lowest = Infinity;
      for (let j = i - kPeriod + 1; j <= i; j++) {
        if (bars[j].high > highest) highest = bars[j].high;
        if (bars[j].low < lowest) lowest = bars[j].low;
      }
      const diff = highest - lowest;
      const k = diff === 0 ? 50 : ((bars[i].close - lowest) / diff) * 100;
      fastK.push({ time: bars[i].time, value: k });
    }

    // 2. Slow %K (SMA of Fast %K with slowing period)
    const slowK = [];
    for (let i = slowing - 1; i < fastK.length; i++) {
      let sum = 0;
      for (let j = i - slowing + 1; j <= i; j++) {
        sum += fastK[j].value;
      }
      slowK.push({ time: fastK[i].time, value: sum / slowing });
    }

    // 3. %D (SMA of slow %K with dPeriod)
    const dLine = [];
    for (let i = dPeriod - 1; i < slowK.length; i++) {
      let sum = 0;
      for (let j = i - dPeriod + 1; j <= i; j++) {
        sum += slowK[j].value;
      }
      dLine.push({ time: slowK[i].time, value: sum / dPeriod });
    }

    return {
      k: slowK,
      d: dLine
    };
  }
};
