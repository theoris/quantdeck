/**
 * QuantDeck Custom Indicator: Last Price HUD (Big Ticker Display)
 * Strictly follows QuantDeck Custom Indicator Specification (Lightweight Charts v4)
 * - Zero runtime imports (Blob URL compatible)
 * - Clean canvas clearing on Hide (setVisible) and Remove (destroy) via full chart layout invalidation
 * - Auto-detection of Symbol Digits (0-8 decimals) from symbol metadata & live OHLC/Tick data
 * - Real-time intra-candle tick updates & TradingView-accurate Daily %Chg (17:00 NY session reset)
 */

interface BarData {
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume?: number;
    bid?: number;
    ask?: number;
}

interface SymbolMetric {
    symbol: string;
    lastPrice: number;
    bidPrice: number | null;
    askPrice: number | null;
    refPrice: number;
    change: number;
    changePct: number;
    dayHigh: number;
    dayLow: number;
    digits: number;
    isUp: boolean;
    isDown: boolean;
    hasData: boolean;
}

interface HudMetrics {
    symbol: string;
    lastPrice: number;
    bidPrice: number | null;
    askPrice: number | null;
    refPrice: number;
    change: number;
    changePct: number;
    dayHigh: number;
    dayLow: number;
    digits: number;
    isUp: boolean;
    isDown: boolean;
    hasData: boolean;
    symbols?: SymbolMetric[];
}

class LastPriceHudPrimitive {
    private _indicator: LastPriceHudIndicator;
    private _chart: any = null;
    private _series: any = null;
    private _requestUpdate?: () => void;
    private _paneViews: any[];

    constructor(indicator: LastPriceHudIndicator) {
        this._indicator = indicator;
        this._paneViews = [new LastPriceHudPaneView(this)];
    }

    public attached(param: any): void {
        this._chart = param?.chart ?? null;
        this._series = param?.series ?? null;
        this._requestUpdate = param?.requestUpdate;
    }

    public detached(): void {
        this._chart = null;
        this._series = null;
        this._requestUpdate = undefined;
    }

    public updateAllViews(): void {
        // Required by Lightweight Charts v4 lifecycle
    }

    public paneViews(): any[] {
        if (!this._indicator.isVisible || this._indicator.isDestroyed) {
            return [];
        }
        return this._paneViews;
    }

    public requestUpdate(): void {
        if (typeof this._requestUpdate === 'function') {
            try {
                this._requestUpdate();
            } catch (_e) {
                // Ignore update error
            }
        }
    }

    public getIndicator(): LastPriceHudIndicator {
        return this._indicator;
    }

    public getChart(): any {
        return this._chart;
    }

    public getSeries(): any {
        return this._series;
    }
}

class LastPriceHudPaneView {
    private _source: LastPriceHudPrimitive;

    constructor(source: LastPriceHudPrimitive) {
        this._source = source;
    }

    public zOrder(): string {
        return 'top';
    }

    public renderer(): any {
        const indicator = this._source.getIndicator();
        return {
            draw: (target: any) => {
                if (!indicator.isVisible || indicator.isDestroyed) return;
                const metrics = indicator.getHudMetrics();
                if (!metrics) return;
                const hasAnyData =
                    metrics.hasData ||
                    (Array.isArray(metrics.symbols) &&
                        metrics.symbols.some((s: any) => s && (s.hasData || s.lastPrice > 0)));
                if (!hasAnyData) return;

                if (typeof target.useMediaCoordinateSpace === 'function') {
                    target.useMediaCoordinateSpace(({ context, mediaSize }: any) => {
                        this._drawHud(context, mediaSize.width, mediaSize.height, metrics, indicator.params);
                    });
                } else if (typeof target.useBitmapCoordinateSpace === 'function') {
                    target.useBitmapCoordinateSpace(
                        ({ context, bitmapSize, horizontalPixelRatio, verticalPixelRatio }: any) => {
                            const hRatio = horizontalPixelRatio || 1;
                            const vRatio = verticalPixelRatio || 1;
                            context.save();
                            context.scale(hRatio, vRatio);
                            this._drawHud(
                                context,
                                bitmapSize.width / hRatio,
                                bitmapSize.height / vRatio,
                                metrics,
                                indicator.params
                            );
                            context.restore();
                        }
                    );
                }
            },
        };
    }

    private _drawHud(
        ctx: CanvasRenderingContext2D,
        width: number,
        height: number,
        metrics: HudMetrics,
        params: Record<string, any>
    ): void {
        const rawSymbolsList =
            metrics.symbols && metrics.symbols.length > 0 ? metrics.symbols : [metrics];
        const symbolsList = rawSymbolsList.filter((s) => s && (s.hasData || s.lastPrice > 0));
        if (symbolsList.length === 0) return;

        const isMulti = symbolsList.length > 1;
        const showSymbol = Number(params.showSymbol) === 1;
        const showDetails = Number(params.showDetails) === 1;
        const location = String(params.location || 'top-center');
        const colorMode = String(params.colorMode || 'dynamic');
        const fontFamily = String(params.fontFamily || 'Inter, system-ui, sans-serif');
        const textColor = String(params.textColor || '#e2e8f0');
        const upColor = String(params.upColor || '#22c55e');
        const downColor = String(params.downColor || '#ef4444');
        const lastSize = Math.max(12, Number(params.lastPriceSize) || 50);
        const otherSize = Math.max(8, Number(params.otherTextSize) || 22);
        const bgMode = String(params.bgMode || 'none');
        const bgColor = String(params.bgColor || '#0f172a');
        const configuredDecimals = Number(params.decimals ?? -1);

        const lastFont = `800 ${lastSize}px ${fontFamily}`;
        const otherFont = `600 ${otherSize}px ${fontFamily}`;
        const symbolFont = `600 ${otherSize}px ${fontFamily}`;
        const subLineGap = '   ';

        ctx.save();

        interface RenderRow {
            symbol: string;
            priceText: string;
            priceColor: string;
            symbolColor: string;
            pctColor: string;
            priceWidth: number;
            symbolWidth: number;
            pctText: string;
            pctWidth: number;
            highText: string;
            highWidth: number;
            lowText: string;
            lowWidth: number;
            gapWidth: number;
            detailsWidth: number;
        }

        const rows: RenderRow[] = [];
        let maxRowWidth = 0;

        ctx.font = otherFont;
        const gapWidth = ctx.measureText(subLineGap).width;

        for (const item of symbolsList) {
            const activeDigits = configuredDecimals >= 0 ? configuredDecimals : item.digits;
            const priceText = this._formatPrice(item.lastPrice, activeDigits);

            // 1. Color resolution: dynamic (up/down per symbol) vs fixed (textColor parameter)
            let priceColor = textColor;
            let symbolColor = textColor;
            let pctColor = textColor;

            if (colorMode === 'dynamic') {
                if (item.isUp) {
                    priceColor = upColor;
                    symbolColor = upColor;
                    pctColor = upColor;
                } else if (item.isDown) {
                    priceColor = downColor;
                    symbolColor = downColor;
                    pctColor = downColor;
                }
            }

            ctx.font = lastFont;
            const priceWidth = ctx.measureText(priceText).width;

            let symbolWidth = 0;
            if (showSymbol) {
                ctx.font = symbolFont;
                symbolWidth = ctx.measureText(item.symbol.toUpperCase()).width;
            }

            let pctText = '';
            let pctWidth = 0;
            let highText = '';
            let highWidth = 0;
            let lowText = '';
            let lowWidth = 0;
            let detailsWidth = 0;

            if (showDetails) {
                const sign = item.changePct > 0 ? '+' : '';
                pctText = `${sign}${item.changePct.toFixed(2)}%`;
                highText = `H: ${this._formatPrice(item.dayHigh, activeDigits)}`;
                lowText = `L: ${this._formatPrice(item.dayLow, activeDigits)}`;

                ctx.font = otherFont;
                pctWidth = ctx.measureText(pctText).width;
                highWidth = ctx.measureText(highText).width;
                lowWidth = ctx.measureText(lowText).width;
                detailsWidth = pctWidth + gapWidth + highWidth + gapWidth + lowWidth;
            }

            let rowLineWidth = priceWidth;
            if (showSymbol) {
                if (isMulti) {
                    rowLineWidth = symbolWidth + 14 + priceWidth;
                } else {
                    rowLineWidth = Math.max(symbolWidth, priceWidth);
                }
            }
            if (showDetails) {
                rowLineWidth = Math.max(rowLineWidth, detailsWidth);
            }

            if (rowLineWidth > maxRowWidth) {
                maxRowWidth = rowLineWidth;
            }

            rows.push({
                symbol: item.symbol.toUpperCase(),
                priceText,
                priceColor,
                symbolColor,
                pctColor,
                priceWidth,
                symbolWidth,
                pctText,
                pctWidth,
                highText,
                highWidth,
                lowText,
                lowWidth,
                gapWidth,
                detailsWidth,
            });
        }

        const lastHeight = Math.round(lastSize * 1.15);
        const otherHeight = Math.round(otherSize * 1.25);
        const lineSpacing = Math.max(4, Math.round(otherSize * 0.25));

        let contentHeight = 0;
        if (!isMulti && showSymbol) {
            contentHeight += otherHeight + lineSpacing;
        }

        for (let i = 0; i < rows.length; i++) {
            contentHeight += lastHeight;
            if (showDetails) {
                contentHeight += lineSpacing + otherHeight;
            }
            if (i < rows.length - 1) {
                contentHeight += isMulti ? lineSpacing * 2 : lineSpacing;
            }
        }

        const padX = Math.max(14, Math.round(lastSize * 0.35));
        const padY = Math.max(10, Math.round(lastSize * 0.25));

        const boxWidth = maxRowWidth + padX * 2;
        const boxHeight = contentHeight + padY * 2;

        const marginX = 20;
        const marginY = 18;

        let boxX = (width - boxWidth) / 2;
        let boxY = marginY;

        if (location.includes('left')) {
            boxX = marginX;
        } else if (location.includes('right')) {
            boxX = Math.max(marginX, width - boxWidth - marginX);
        } else {
            boxX = Math.max(marginX, (width - boxWidth) / 2);
        }

        if (location.startsWith('bottom')) {
            boxY = Math.max(marginY, height - boxHeight - marginY);
        } else if (location === 'middle-center' || location === 'center') {
            boxY = Math.max(marginY, (height - boxHeight) / 2);
        } else {
            boxY = marginY;
        }

        // When multi-symbol, use neutral border so the container doesn't take one symbol's color as a whole
        let primaryBorderColor = textColor;
        if (!isMulti && colorMode === 'dynamic' && rows.length > 0) {
            primaryBorderColor = rows[0].priceColor;
        }

        if (bgMode !== 'none') {
            let alpha = 0.85;
            if (bgMode === 'solid') alpha = 1.0;
            else if (bgMode === 'semi') alpha = 0.8;
            else if (bgMode === 'soft') alpha = 0.5;

            ctx.fillStyle = this._hexToRgba(bgColor, alpha);
            this._roundRect(ctx, boxX, boxY, boxWidth, boxHeight, 12);
            ctx.fill();

            const borderAlpha = (!isMulti && colorMode === 'dynamic') ? 0.35 : 0.2;
            ctx.strokeStyle = this._hexToRgba(primaryBorderColor, borderAlpha);
            ctx.lineWidth = 1.5;
            ctx.stroke();
        } else {
            ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
            ctx.shadowBlur = 6;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 2;
        }

        const centerX = boxX + boxWidth / 2;
        let cursorY = boxY + padY;
        ctx.textBaseline = 'top';

        // Single symbol with showSymbol: draw symbol above price
        if (!isMulti && showSymbol && rows.length > 0) {
            ctx.font = symbolFont;
            ctx.fillStyle = rows[0].symbolColor;
            ctx.textAlign = 'center';
            ctx.fillText(rows[0].symbol, centerX, cursorY);
            cursorY += otherHeight + lineSpacing;
        }

        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];

            if (isMulti && showSymbol) {
                // Multi-symbol with showSymbol: draw "SYMBOL   PRICE" (each symbol gets its own independent color)
                const gap = 14;
                const totalLineWidth = row.symbolWidth + gap + row.priceWidth;
                let startX = centerX - totalLineWidth / 2;
                if (location.includes('left')) {
                    startX = boxX + padX;
                } else if (location.includes('right')) {
                    startX = boxX + boxWidth - padX - totalLineWidth;
                }

                ctx.textAlign = 'left';
                ctx.font = symbolFont;
                ctx.fillStyle = row.symbolColor;
                ctx.fillText(row.symbol, startX, cursorY + (lastHeight - otherSize) / 2);

                ctx.font = lastFont;
                ctx.fillStyle = row.priceColor;
                ctx.fillText(row.priceText, startX + row.symbolWidth + gap, cursorY);
                cursorY += lastHeight;
            } else {
                // Pure Price number (e.g. 3965.59 / 50.08 / 77371.20)
                ctx.font = lastFont;
                ctx.fillStyle = row.priceColor;
                let drawX = centerX;
                if (location.includes('left')) {
                    ctx.textAlign = 'left';
                    drawX = boxX + padX;
                } else if (location.includes('right')) {
                    ctx.textAlign = 'right';
                    drawX = boxX + boxWidth - padX;
                } else {
                    ctx.textAlign = 'center';
                    drawX = centerX;
                }
                ctx.fillText(row.priceText, drawX, cursorY);
                cursorY += lastHeight;
            }

            // Draw Details Line (%Chg / High / Low) if showDetails is true
            if (showDetails && row.detailsWidth > 0) {
                cursorY += lineSpacing;
                ctx.font = otherFont;
                let detailsStartX = centerX - row.detailsWidth / 2;
                if (location.includes('left')) {
                    detailsStartX = boxX + padX;
                } else if (location.includes('right')) {
                    detailsStartX = boxX + boxWidth - padX - row.detailsWidth;
                }

                ctx.textAlign = 'left';
                ctx.fillStyle = row.pctColor;
                ctx.fillText(row.pctText, detailsStartX, cursorY);
                detailsStartX += row.pctWidth + row.gapWidth;

                ctx.fillStyle = textColor;
                ctx.fillText(row.highText, detailsStartX, cursorY);
                detailsStartX += row.highWidth + row.gapWidth;

                ctx.fillStyle = textColor;
                ctx.fillText(row.lowText, detailsStartX, cursorY);

                cursorY += otherHeight;
            }

            if (i < rows.length - 1) {
                if (isMulti && bgMode !== 'none') {
                    const dividerY = cursorY + lineSpacing;
                    ctx.strokeStyle = this._hexToRgba(textColor, 0.12);
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(boxX + padX, dividerY);
                    ctx.lineTo(boxX + boxWidth - padX, dividerY);
                    ctx.stroke();
                }
                cursorY += isMulti ? lineSpacing * 2 : lineSpacing;
            }
        }

        ctx.restore();
    }

    private _formatPrice(value: number, digits: number): string {
        if (!Number.isFinite(value)) return '-';
        const safeDigits = Math.max(0, Math.min(8, Math.round(digits)));
        return value.toLocaleString('en-US', {
            minimumFractionDigits: safeDigits,
            maximumFractionDigits: safeDigits,
        });
    }

    private _hexToRgba(hex: string, alpha: number): string {
        const clean = hex.replace('#', '').trim();
        if (clean.length === 3) {
            const r = parseInt(clean[0] + clean[0], 16);
            const g = parseInt(clean[1] + clean[1], 16);
            const b = parseInt(clean[2] + clean[2], 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }
        if (clean.length >= 6) {
            const r = parseInt(clean.substring(0, 2), 16);
            const g = parseInt(clean.substring(2, 4), 16);
            const b = parseInt(clean.substring(4, 6), 16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }
        return `rgba(15, 23, 42, ${alpha})`;
    }

    private _roundRect(
        ctx: CanvasRenderingContext2D,
        x: number,
        y: number,
        w: number,
        h: number,
        r: number
    ): void {
        const radius = Math.min(r, w / 2, h / 2);
        ctx.beginPath();
        ctx.moveTo(x + radius, y);
        ctx.lineTo(x + w - radius, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
        ctx.lineTo(x + w, y + h - radius);
        ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
        ctx.lineTo(x + radius, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
        ctx.lineTo(x, y + radius);
        ctx.quadraticCurveTo(x, y, x + radius, y);
        ctx.closePath();
    }
}

export class LastPriceHudIndicator {
    public id: string;
    public name: string;
    public pane: 'main' | 'sub';
    public isVisible: boolean = true;
    public isDestroyed: boolean = false;
    public params: Record<string, any>;
    public paramDefs: Array<{
        key: string;
        label: string;
        type: 'number' | 'color' | 'select' | 'text';
        default: any;
        min?: number;
        max?: number;
        step?: number;
        placeholder?: string;
        options?: Array<{ label: string; value: any }>;
    }>;

    private _rawBars: BarData[] = [];
    private _symbol: string = '';
    private _source: string = 'default';
    private _detectedDigits: number = 2;
    private _htfDailyCache: Map<string, { bars: BarData[]; fetchedAt: number }> = new Map();
    private _dailyBars: BarData[] = [];
    private _externalSymbolData: Map<
        string,
        {
            last: number;
            low: number;
            high: number;
            chg_pct: number;
            digits: number;
            bid?: number;
            ask?: number;
            fetchedAt: number;
        }
    > = new Map();
    private engine: any = null;
    private series: any = null;
    private _primitive: LastPriceHudPrimitive | null = null;
    private _attachedSeries: any = null;
    private _tickTimer: any = null;
    private _lastRenderedSignature: string = '';
    private _liveBid: number | null = null;
    private _liveAsk: number | null = null;
    private cachedData: Array<{ time: number; value: number }> = [];
    private cachedMarkers: any[] = [];
    private _hudMetrics: HudMetrics = {
        symbol: '',
        lastPrice: 0,
        bidPrice: null,
        askPrice: null,
        refPrice: 0,
        change: 0,
        changePct: 0,
        dayHigh: 0,
        dayLow: 0,
        digits: 2,
        isUp: false,
        isDown: false,
        hasData: false,
        symbols: [],
    };

    constructor() {
        this.id = `custom_ind_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        this.name = 'Last Price HUD';
        this.pane = 'main';
        this.isVisible = true;
        this.isDestroyed = false;

        // 1. Default Parameter Values
        this.params = {
            symbols: 'current', // Default: current symbol (e.g. XAUUSD)
            showDetails: 0, // Default: false (0 = Hide %chg, high, low line)
            showSymbol: 0, // Default false (0 = Hide)
            location: 'top-center', // Default Top Center
            priceSource: 'last', // 'last' | 'bid' | 'ask' | 'mid'
            colorMode: 'dynamic', // 'dynamic' (Up/Down per symbol) | 'fixed' (Use Parameter Font Color)
            sessionReset: 'auto', // 'auto' (17:00 NY for XAU/FX, 00:00 UTC for Crypto)
            dailyRefMode: 'prevClose', // 'prevClose' (TradingView default) | 'dayOpen'
            fontFamily: 'Inter, system-ui, sans-serif',
            textColor: '#e2e8f0',
            upColor: '#22c55e',
            downColor: '#ef4444',
            lastPriceSize: 50, // Default 50
            otherTextSize: 22, // Default 22
            bgMode: 'none',
            bgColor: '#0f172a',
            decimals: -1, // -1 = Auto (Symbol Digits)
        };

        // 2. Settings Modal UI Definitions (English Labels Only)
        this.paramDefs = [
            {
                key: 'symbols',
                label: 'Asset Symbol(s)',
                type: 'text',
                default: 'current',
                placeholder: 'current (e.g. current, XAGUSD, BTCUSD)',
            },
            {
                key: 'showDetails',
                label: 'Show %Chg / High / Low Line',
                type: 'select',
                default: 0,
                options: [
                    { label: 'Hide (Default)', value: 0 },
                    { label: 'Show', value: 1 },
                ],
            },
            {
                key: 'showSymbol',
                label: 'Show Symbol Name',
                type: 'select',
                default: 0,
                options: [
                    { label: 'Hide', value: 0 },
                    { label: 'Show', value: 1 },
                ],
            },
            {
                key: 'location',
                label: 'Label Location',
                type: 'select',
                default: 'top-center',
                options: [
                    { label: 'Top Center', value: 'top-center' },
                    { label: 'Top Left', value: 'top-left' },
                    { label: 'Top Right', value: 'top-right' },
                    { label: 'Center', value: 'center' },
                    { label: 'Bottom Left', value: 'bottom-left' },
                    { label: 'Bottom Center', value: 'bottom-center' },
                    { label: 'Bottom Right', value: 'bottom-right' },
                ],
            },
            {
                key: 'priceSource',
                label: 'Price Source (Tick Mode)',
                type: 'select',
                default: 'last',
                options: [
                    { label: 'Last / Live Candle Close (Tick)', value: 'last' },
                    { label: 'Bid Price', value: 'bid' },
                    { label: 'Ask Price', value: 'ask' },
                    { label: 'Mid Price ((Bid + Ask) / 2)', value: 'mid' },
                ],
            },
            {
                key: 'sessionReset',
                label: 'Daily Session Reset Time',
                type: 'select',
                default: 'auto',
                options: [
                    { label: 'Auto (17:00 NY for Gold/FX, 00:00 UTC Crypto)', value: 'auto' },
                    { label: '17:00 New York (TradingView Gold / Forex)', value: 'ny17' },
                    { label: '00:00 UTC (Crypto / UTC Standard)', value: 'utc0' },
                    { label: '00:00 Bangkok Time (UTC+7 / TFEX)', value: 'th0' },
                ],
            },
            {
                key: 'dailyRefMode',
                label: 'Daily %Chg Reference',
                type: 'select',
                default: 'prevClose',
                options: [
                    { label: 'Previous Day Close (TradingView Standard)', value: 'prevClose' },
                    { label: 'Current Day Open', value: 'dayOpen' },
                ],
            },
            {
                key: 'fontFamily',
                label: 'Font Type',
                type: 'select',
                default: 'Inter, system-ui, sans-serif',
                options: [
                    { label: 'Sans-Serif (Inter / System)', value: 'Inter, system-ui, sans-serif' },
                    { label: 'Monospace (JetBrains / Consolas)', value: '"JetBrains Mono", Consolas, monospace' },
                    { label: 'Kanit', value: 'Kanit, sans-serif' },
                    { label: 'Sarabun', value: 'Sarabun, sans-serif' },
                    { label: 'Arial / Helvetica', value: 'Arial, Helvetica, sans-serif' },
                    { label: 'Impact (Extra Bold)', value: 'Impact, Arial Black, sans-serif' },
                ],
            },
            {
                key: 'colorMode',
                label: 'Price Color Mode',
                type: 'select',
                default: 'dynamic',
                options: [
                    { label: 'Dynamic (Up: Green / Down: Red per Symbol)', value: 'dynamic' },
                    { label: 'Fixed (Use Font Color Parameter)', value: 'fixed' },
                ],
            },
            {
                key: 'textColor',
                label: 'Font Color (Parameter / Base Color)',
                type: 'color',
                default: '#e2e8f0',
            },
            {
                key: 'upColor',
                label: 'Up Price Color (Green)',
                type: 'color',
                default: '#22c55e',
            },
            {
                key: 'downColor',
                label: 'Down Price Color (Red)',
                type: 'color',
                default: '#ef4444',
            },
            {
                key: 'lastPriceSize',
                label: 'Last Price Font Size',
                type: 'number',
                default: 50,
                min: 16,
                max: 160,
                step: 2,
            },
            {
                key: 'otherTextSize',
                label: 'Other Text Font Size (%Chg / H / L)',
                type: 'number',
                default: 22,
                min: 10,
                max: 80,
                step: 1,
            },
            {
                key: 'bgMode',
                label: 'Background Mode',
                type: 'select',
                default: 'none',
                options: [
                    { label: 'None (Transparent)', value: 'none' },
                    { label: 'Semi-Transparent (80%)', value: 'semi' },
                    { label: 'Soft Glass (50%)', value: 'soft' },
                    { label: 'Solid Color (100%)', value: 'solid' },
                ],
            },
            {
                key: 'bgColor',
                label: 'Background Color',
                type: 'color',
                default: '#0f172a',
            },
            {
                key: 'decimals',
                label: 'Decimal Places (Digits)',
                type: 'select',
                default: -1,
                options: [
                    { label: 'Auto (Symbol Digits)', value: -1 },
                    { label: '0', value: 0 },
                    { label: '1', value: 1 },
                    { label: '2', value: 2 },
                    { label: '3', value: 3 },
                    { label: '4', value: 4 },
                    { label: '5', value: 5 },
                    { label: '6', value: 6 },
                    { label: '7', value: 7 },
                    { label: '8', value: 8 },
                ],
            },
        ];
    }

    public setSymbol(symbol: string): void {
        if (symbol && typeof symbol === 'string') {
            if (this._symbol !== symbol) {
                this._symbol = symbol;
                this._liveBid = null;
                this._liveAsk = null;
            }
        }
    }

    public setSource(source: string): void {
        if (source && typeof source === 'string') {
            this._source = source;
        }
    }

    public getHudMetrics(): HudMetrics {
        return this._hudMetrics;
    }

    public async calculate(bars: BarData[], symbol?: string): Promise<Array<{ time: number; value: number }>> {
        if (this.isDestroyed) return [];

        if (symbol && typeof symbol === 'string') {
            this.setSymbol(symbol);
        } else if (!this._symbol && this.engine?.symbol) {
            this.setSymbol(String(this.engine.symbol));
        }

        if (!Array.isArray(bars) || bars.length === 0) {
            this._rawBars = [];
            this.cachedData = [];
            this._hudMetrics.hasData = false;
            return this.cachedData;
        }

        this._rawBars = bars
            .filter(
                (b) =>
                    b &&
                    Number.isFinite(b.time) &&
                    Number.isFinite(b.open) &&
                    Number.isFinite(b.high) &&
                    Number.isFinite(b.low) &&
                    Number.isFinite(b.close)
            )
            .slice()
            .sort((a, b) => a.time - b.time);

        this._detectedDigits = this._detectSymbolDigits();

        await this._fetchDailyBarsIfNeeded();

        const curSym =
            this._symbol ||
            (this.engine && this.engine.symbol ? String(this.engine.symbol) : 'XAUUSD');
        const reqSymbols = this._parseSymbolList(this.params.symbols, curSym);
        if (reqSymbols.some((s) => s.toUpperCase() !== curSym.toUpperCase())) {
            await this._fetchExternalSymbolsData(reqSymbols);
        }

        this._recomputeHudMetrics();

        const lastBar = this._rawBars[this._rawBars.length - 1];
        this.cachedData = lastBar ? [{ time: lastBar.time, value: this._hudMetrics.lastPrice }] : [];
        return this.cachedData;
    }

    public render(engine: any, _onSettings?: () => void, _onClose?: () => void): void {
        this.isDestroyed = false;
        this.engine = engine;
        if (engine?.symbol && !this._symbol) {
            this._symbol = String(engine.symbol);
        }
        if (engine?.source && this._source === 'default') {
            this._source = String(engine.source);
        }

        const scalePos =
            typeof engine.getPriceScalePosition === 'function' ? engine.getPriceScalePosition() : 'right';

        if (!this.series && engine?.chart && typeof engine.chart.addLineSeries === 'function') {
            const priceFmt =
                typeof engine.getPriceFormat === 'function'
                    ? engine.getPriceFormat()
                    : { type: 'price', precision: 5, minMove: 0.00001 };
            this.series = engine.chart.addLineSeries({
                priceScaleId: 'hud-dummy-scale',
                priceFormat: priceFmt,
                visible: false,
                lastValueVisible: false,
                priceLineVisible: false,
                crosshairMarkerVisible: false,
                color: 'rgba(0, 0, 0, 0)',
                lineWidth: 1,
                lineStyle: 0,
            });
        }

        if (!this._primitive) {
            this._primitive = new LastPriceHudPrimitive(this);
        }

        if (this.isVisible) {
            this._ensurePrimitiveAttached();
            this._startTickWatcher();
        }
        this._forceChartFullRepaint();
    }

    public setData(data: Array<{ time: number; value: number }>): void {
        if (this.isDestroyed) return;
        if (Array.isArray(data)) {
            this.cachedData = data;
        }
        if (this.series && typeof this.series.setData === 'function') {
            try {
                this.series.setData(this.cachedData || []);
            } catch (_err) {
                // Ignore anchor series error
            }
        }
        this.applyMarkers();
        if (this.isVisible) {
            this._ensurePrimitiveAttached();
        }
        this._forceChartFullRepaint();
    }

    public onTick(tick: any): void {
        if (this.isDestroyed || !this.isVisible || !tick) return;
        if (Number.isFinite(Number(tick.bid))) this._liveBid = Number(tick.bid);
        if (Number.isFinite(Number(tick.ask))) this._liveAsk = Number(tick.ask);

        const price = Number.isFinite(Number(tick.price))
            ? Number(tick.price)
            : Number.isFinite(Number(tick.close))
                ? Number(tick.close)
                : Number.isFinite(Number(tick.last))
                    ? Number(tick.last)
                    : this._liveBid;

        if (price !== null && Number.isFinite(price) && this._rawBars.length > 0) {
            const lastIdx = this._rawBars.length - 1;
            const cur = this._rawBars[lastIdx];
            this.update({
                time: Number.isFinite(Number(tick.time)) && Number(tick.time) >= cur.time ? Number(tick.time) : cur.time,
                open: cur.open,
                high: Math.max(cur.high, price),
                low: Math.min(cur.low, price),
                close: price,
                bid: this._liveBid ?? undefined,
                ask: this._liveAsk ?? undefined,
            });
        }
    }

    public update(bar: BarData): void {
        if (
            this.isDestroyed ||
            !bar ||
            !Number.isFinite(bar.time) ||
            !Number.isFinite(bar.close) ||
            !Number.isFinite(bar.high) ||
            !Number.isFinite(bar.low)
        ) {
            return;
        }

        if (Number.isFinite(Number(bar.bid))) this._liveBid = Number(bar.bid);
        if (Number.isFinite(Number(bar.ask))) this._liveAsk = Number(bar.ask);

        if (this.engine?.symbol && String(this.engine.symbol) !== this._symbol) {
            this.setSymbol(String(this.engine.symbol));
        }

        if (this._rawBars.length === 0) {
            this._rawBars.push({ ...bar });
        } else {
            const lastIdx = this._rawBars.length - 1;
            const lastBar = this._rawBars[lastIdx];
            if (bar.time === lastBar.time) {
                this._rawBars[lastIdx] = {
                    ...lastBar,
                    ...bar,
                    high: Math.max(lastBar.high, bar.high, bar.close),
                    low: Math.min(lastBar.low, bar.low, bar.close),
                };
            } else if (bar.time > lastBar.time) {
                this._rawBars.push({ ...bar });
            } else {
                const idx = this._rawBars.findIndex((b) => b.time === bar.time);
                if (idx !== -1) {
                    this._rawBars[idx] = { ...bar };
                }
            }
        }

        this._detectedDigits = this._detectSymbolDigits();
        this._recomputeHudMetrics();

        if (this.isVisible) {
            this._ensurePrimitiveAttached();
            this._forceChartFullRepaint();
        }
    }

    public async updateParams(newParams: Record<string, any>, engine?: any): Promise<void> {
        if (this.isDestroyed) return;
        this.params = { ...this.params, ...newParams };
        if (engine) {
            this.engine = engine;
        }

        const bars =
            engine && Array.isArray(engine.allBars) && engine.allBars.length > 0
                ? engine.allBars
                : this._rawBars;

        if (Array.isArray(bars) && bars.length > 0) {
            this._rawBars = bars
                .filter((b: BarData) => b && Number.isFinite(b.time) && Number.isFinite(b.close))
                .slice()
                .sort((a: BarData, b: BarData) => a.time - b.time);
            this._detectedDigits = this._detectSymbolDigits();
        }

        const curSym =
            this._symbol ||
            (this.engine && this.engine.symbol ? String(this.engine.symbol) : 'XAUUSD');
        const reqSymbols = this._parseSymbolList(this.params.symbols, curSym);
        if (reqSymbols.some((s) => s.toUpperCase() !== curSym.toUpperCase())) {
            await this._fetchExternalSymbolsData(reqSymbols);
        }

        this._recomputeHudMetrics();
        this.setData(this.cachedData);
    }

    public setVisible(visible: boolean): void {
        this.isVisible = visible !== false;
        this.series?.applyOptions({ visible: false });

        const chart = this.engine?.chart || this._primitive?.getChart();
        const mainSeries =
            (typeof this.engine?.getMainSeries === 'function' ? this.engine.getMainSeries() : null) ||
            this._attachedSeries ||
            this._primitive?.getSeries();

        if (!this.isVisible) {
            this.clearMarkers();
            // Request update before detaching and then detach so primitive cannot draw while hidden
            this._primitive?.requestUpdate();
            this._detachPrimitive(this.engine);
            this._forceChartFullRepaint(this.engine, chart, mainSeries);
        } else {
            this._ensurePrimitiveAttached();
            this._detectedDigits = this._detectSymbolDigits();
            this._recomputeHudMetrics();
            this.applyMarkers();
            this._forceChartFullRepaint(this.engine, chart, mainSeries);
        }
    }

    public applyMarkers(): void {
        if (!this.engine || !this.isVisible || this.isDestroyed) {
            this.clearMarkers();
            return;
        }
        if (typeof this.engine.setIndicatorMarkers === 'function') {
            this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
            return;
        }
    }

    public clearMarkers(): void {
        if (!this.engine) return;
        if (typeof this.engine.clearIndicatorMarkers === 'function') {
            this.engine.clearIndicatorMarkers(this.id);
            return;
        }
    }

    public destroy(engine?: any): void {
        this.isDestroyed = true;
        this.isVisible = false;
        this._hudMetrics.hasData = false;
        this._stopTickWatcher();

        const targetEngine = engine || this.engine;
        const chart = targetEngine?.chart || this._primitive?.getChart() || this.engine?.chart;
        const mainSeries =
            (typeof targetEngine?.getMainSeries === 'function' ? targetEngine.getMainSeries() : null) ||
            this._attachedSeries ||
            this._primitive?.getSeries();

        this.clearMarkers();

        // 1. Notify primitive update while still attached
        this._primitive?.requestUpdate();

        // 2. Detach primitive from all possible series references
        this._detachPrimitive(targetEngine);

        // 3. Remove anchor series
        if (this.series && chart && typeof chart.removeSeries === 'function') {
            try {
                chart.removeSeries(this.series);
            } catch (_e) {
                // Ignore remove error
            }
        }
        this.series = null;

        // 4. Force full chart canvas repaint (same internal call as changing Theme background)
        this._forceChartFullRepaint(targetEngine, chart, mainSeries);
    }

    /**
     * Automatically detects the Symbol's native decimal precision (Digits)
     * using symbol metadata, priceFormat, and actual OHLC/Bid/Ask values.
     */
    private _detectSymbolDigits(): number {
        const eng = this.engine;

        // 1. Check explicit Symbol / Engine metadata or getSymbolPrecision
        const explicitPrec = typeof eng?.getSymbolPrecision === 'function' ? eng.getSymbolPrecision() : undefined;
        if (explicitPrec !== undefined && explicitPrec !== null && Number.isFinite(Number(explicitPrec))) {
            const ep = Math.round(Number(explicitPrec));
            if (ep >= 0 && ep <= 8) return ep;
        }

        const metaCandidates = [
            eng?.digits,
            eng?.precision,
            eng?.decimals,
            eng?.symbolInfo?.digits,
            eng?.symbolInfo?.precision,
            eng?.instrument?.digits,
            eng?.instrument?.precision,
            eng?.currentSymbol?.digits,
        ];
        for (const cand of metaCandidates) {
            if (cand !== undefined && cand !== null && Number.isFinite(Number(cand))) {
                const d = Math.round(Number(cand));
                if (d >= 0 && d <= 8) return d;
            }
        }

        // 2. Check mainSeries priceFormat if explicitly configured (and not default 2 when bars have more decimals)
        let seriesPrecision: number | null = null;
        const mainSeries = typeof eng?.getMainSeries === 'function' ? eng.getMainSeries() : this._attachedSeries;
        if (mainSeries && typeof mainSeries.options === 'function') {
            try {
                const pf = mainSeries.options()?.priceFormat;
                if (pf) {
                    if (Number.isFinite(Number(pf.precision)) && Number(pf.precision) >= 0) {
                        seriesPrecision = Math.round(Number(pf.precision));
                    } else if (Number.isFinite(Number(pf.minMove)) && Number(pf.minMove) > 0) {
                        seriesPrecision = Math.max(0, Math.round(-Math.log10(Number(pf.minMove))));
                    }
                }
            } catch (_e) {
                // Ignore options read error
            }
        }

        // 3. Scan actual OHLC + Bid/Ask prices from recent bars to find true decimal precision
        let maxBarDecimals = 0;
        const len = this._rawBars.length;
        const startIdx = Math.max(0, len - 120);

        const countDecimals = (val: number | null | undefined): number => {
            if (val === null || val === undefined || !Number.isFinite(val)) return 0;
            const absVal = Math.abs(val);
            // Clean IEEE-754 floating point noise (e.g., 1.0854300000000001 -> 1.08543)
            const maxCleanDigits = absVal >= 0.001 || absVal === 0 ? 6 : 8;
            const cleanedStr = Number(val.toFixed(maxCleanDigits)).toString();
            if (cleanedStr.includes('e-')) {
                const parts = cleanedStr.split('e-');
                return Math.min(8, parseInt(parts[1], 10) || 0);
            }
            const dotIdx = cleanedStr.indexOf('.');
            return dotIdx === -1 ? 0 : cleanedStr.length - dotIdx - 1;
        };

        for (let i = startIdx; i < len; i++) {
            const b = this._rawBars[i];
            const dOpen = countDecimals(b.open);
            const dHigh = countDecimals(b.high);
            const dLow = countDecimals(b.low);
            const dClose = countDecimals(b.close);
            const localMax = Math.max(dOpen, dHigh, dLow, dClose);
            if (localMax > maxBarDecimals) {
                maxBarDecimals = localMax;
            }
        }

        maxBarDecimals = Math.max(
            maxBarDecimals,
            countDecimals(this._liveBid),
            countDecimals(this._liveAsk)
        );

        // 4. Combine with known Symbol conventions if all sampled prices happened to end in trailing zeros
        const sym = (this._symbol || eng?.symbol || '').toUpperCase();
        const FIAT_CURRENCIES = new Set([
            'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD',
            'SGD', 'HKD', 'CNH', 'CNY', 'SEK', 'NOK', 'DKK', 'ZAR',
            'MXN', 'PLN', 'TRY', 'THB', 'INR', 'KRW', 'BRL', 'TWD'
        ]);
        const isCrypto =
            sym.includes('BTC') ||
            sym.includes('ETH') ||
            sym.includes('SOL') ||
            sym.includes('XRP') ||
            sym.includes('BNB') ||
            sym.includes('DOGE') ||
            sym.includes('SHIB') ||
            sym.includes('LTC') ||
            sym.includes('ADA') ||
            sym.includes('DOT') ||
            sym.includes('AVAX') ||
            sym.includes('LINK') ||
            sym.includes('CRYPTO');

        let symbolConventionMin = 0;
        if (sym) {
            if (sym.includes('XAU') || sym.includes('GOLD')) {
                symbolConventionMin = 2;
            } else if (sym.includes('XAG') || sym.includes('SILVER')) {
                symbolConventionMin = Math.max(2, maxBarDecimals);
            } else if (isCrypto) {
                // In crypto, never force 5-digit forex convention
                symbolConventionMin = maxBarDecimals > 0 ? maxBarDecimals : 2;
            } else if (sym.length === 6 && FIAT_CURRENCIES.has(sym.slice(0, 3)) && FIAT_CURRENCIES.has(sym.slice(3, 6))) {
                // Strict True Forex Pair
                if (sym.includes('JPY')) {
                    symbolConventionMin = 3;
                } else {
                    symbolConventionMin = 5;
                }
            }
        }

        if (seriesPrecision !== null && seriesPrecision !== 2) {
            return seriesPrecision;
        }

        const detected = Math.max(maxBarDecimals, symbolConventionMin);
        if (detected > 0) return Math.min(8, detected);

        return seriesPrecision !== null ? seriesPrecision : 2;
    }

    /**
     * Forces Lightweight Charts v4 to execute a Full Canvas Invalidation (InvalidationLevel.Full),
     * identical to changing the Theme Background Color, so hidden/removed primitives never leave ghost pixels.
     */
    private _forceChartFullRepaint(targetEngine?: any, explicitChart?: any, explicitSeries?: any): void {
        const eng = targetEngine || this.engine;
        const chart = explicitChart || eng?.chart || this._primitive?.getChart();
        const mainSeries =
            explicitSeries ||
            (typeof eng?.getMainSeries === 'function' ? eng.getMainSeries() : null) ||
            this._attachedSeries ||
            this._primitive?.getSeries();

        const triggerPaint = () => {
            this._primitive?.requestUpdate();

            if (mainSeries && typeof mainSeries.applyOptions === 'function') {
                try {
                    mainSeries.applyOptions({});
                } catch (_e) {
                    // Ignore series applyOptions error
                }
            }

            if (chart && typeof chart.applyOptions === 'function') {
                try {
                    const cOpts = typeof chart.options === 'function' ? chart.options() : null;
                    const bg = cOpts?.layout?.background;
                    if (bg) {
                        chart.applyOptions({
                            layout: {
                                background: { ...bg },
                            },
                        });
                    } else {
                        chart.applyOptions({ layout: {} });
                    }
                } catch (_e) {
                    // Ignore chart applyOptions error
                }
            }

            if (chart && typeof chart.timeScale === 'function') {
                try {
                    const ts = chart.timeScale();
                    if (ts && typeof ts.applyOptions === 'function') {
                        ts.applyOptions({});
                    }
                } catch (_e) {
                    // Ignore timeScale applyOptions error
                }
            }
        };

        triggerPaint();

        if (typeof requestAnimationFrame === 'function') {
            requestAnimationFrame(() => {
                triggerPaint();
            });
        }
    }

    private _ensurePrimitiveAttached(): void {
        if (!this.engine || !this._primitive || !this.isVisible || this.isDestroyed) return;
        const mainSeries =
            typeof this.engine.getMainSeries === 'function' ? this.engine.getMainSeries() : null;
        if (!mainSeries || typeof mainSeries.attachPrimitive !== 'function') return;

        if (this._attachedSeries !== mainSeries) {
            this._detachPrimitive(this.engine);
            try {
                mainSeries.attachPrimitive(this._primitive);
                this._attachedSeries = mainSeries;
            } catch (_e) {
                // Ignore attach error
            }
        }
    }

    private _detachPrimitive(targetEngine?: any): void {
        if (!this._primitive) return;
        const eng = targetEngine || this.engine;
        const seriesCandidates = new Set<any>();

        if (this._attachedSeries) seriesCandidates.add(this._attachedSeries);
        if (this._primitive.getSeries()) seriesCandidates.add(this._primitive.getSeries());
        if (eng && typeof eng.getMainSeries === 'function') {
            const ms = eng.getMainSeries();
            if (ms) seriesCandidates.add(ms);
        }

        seriesCandidates.forEach((s) => {
            if (s && typeof s.detachPrimitive === 'function') {
                try {
                    s.detachPrimitive(this._primitive);
                } catch (_e) {
                    // Ignore detach error
                }
            }
        });

        this._attachedSeries = null;
    }

    private _startTickWatcher(): void {
        this._stopTickWatcher();
        let loopCounter = 0;
        this._tickTimer = setInterval(async () => {
            if (this.isDestroyed || !this.isVisible || !this.engine) return;
            this._syncLiveTickFromEngine();

            loopCounter++;
            if (loopCounter % 10 === 0) {
                const curSym = (
                    this._symbol ||
                    (this.engine && this.engine.symbol ? String(this.engine.symbol) : 'XAUUSD')
                ).toUpperCase();
                const reqSymbols = this._parseSymbolList(this.params.symbols, curSym);
                const hasExternal = reqSymbols.some((s) => s.toUpperCase() !== curSym);
                if (hasExternal) {
                    await this._fetchExternalSymbolsData(reqSymbols);
                    this._recomputeHudMetrics();
                    this._primitive?.requestUpdate();
                }
            }
        }, 100);
    }

    private _stopTickWatcher(): void {
        if (this._tickTimer !== null) {
            clearInterval(this._tickTimer);
            this._tickTimer = null;
        }
    }

    private _syncLiveTickFromEngine(): void {
        if (!this.engine || this.isDestroyed || !this.isVisible) return;

        const eng = this.engine;
        if (eng.symbol && String(eng.symbol) !== this._symbol) {
            this.setSymbol(String(eng.symbol));
            this._fetchDailyBarsIfNeeded();
        }

        const rawBid =
            eng.bid ??
            eng.lastTick?.bid ??
            eng.quote?.bid ??
            eng.currentQuote?.bid ??
            eng.ticker?.bid ??
            null;
        const rawAsk =
            eng.ask ??
            eng.lastTick?.ask ??
            eng.quote?.ask ??
            eng.currentQuote?.ask ??
            eng.ticker?.ask ??
            null;

        if (rawBid !== null && Number.isFinite(Number(rawBid))) {
            this._liveBid = Number(rawBid);
        }
        if (rawAsk !== null && Number.isFinite(Number(rawAsk))) {
            this._liveAsk = Number(rawAsk);
        }

        let latestBar: BarData | null = null;
        const mainSeries = typeof eng.getMainSeries === 'function' ? eng.getMainSeries() : null;

        if (mainSeries && typeof mainSeries.data === 'function') {
            try {
                const seriesData = mainSeries.data();
                if (Array.isArray(seriesData) && seriesData.length > 0) {
                    const cand = seriesData[seriesData.length - 1];
                    if (cand && Number.isFinite(Number(cand.time))) {
                        const closeVal = Number.isFinite(Number(cand.close))
                            ? Number(cand.close)
                            : Number(cand.value);
                        if (Number.isFinite(closeVal)) {
                            latestBar = {
                                time: Number(cand.time),
                                open: Number.isFinite(Number(cand.open)) ? Number(cand.open) : closeVal,
                                high: Number.isFinite(Number(cand.high)) ? Number(cand.high) : closeVal,
                                low: Number.isFinite(Number(cand.low)) ? Number(cand.low) : closeVal,
                                close: closeVal,
                            };
                        }
                    }
                }
            } catch (_e) {
                // Fallback to engine.allBars
            }
        }

        if (!latestBar && Array.isArray(eng.allBars) && eng.allBars.length > 0) {
            const b = eng.allBars[eng.allBars.length - 1];
            if (b && Number.isFinite(Number(b.time)) && Number.isFinite(Number(b.close))) {
                latestBar = {
                    time: Number(b.time),
                    open: Number(b.open),
                    high: Number(b.high),
                    low: Number(b.low),
                    close: Number(b.close),
                };
            }
        }

        const directLivePrice =
            eng.lastPrice ?? eng.currentPrice ?? eng.lastTick?.price ?? eng.lastTick?.close ?? null;
        if (latestBar && directLivePrice !== null && Number.isFinite(Number(directLivePrice))) {
            const p = Number(directLivePrice);
            latestBar.close = p;
            if (p > latestBar.high) latestBar.high = p;
            if (p < latestBar.low) latestBar.low = p;
        }

        if (!latestBar) return;

        const sig = `${this._symbol}_${latestBar.time}_${latestBar.close}_${latestBar.high}_${latestBar.low}_${this._liveBid}_${this._liveAsk}_${this.params.priceSource}`;
        if (sig !== this._lastRenderedSignature) {
            this._lastRenderedSignature = sig;
            this.update(latestBar);
        }
    }

    private async _fetchDailyBarsIfNeeded(): Promise<void> {
        const sym = this._symbol || this.engine?.symbol || '';
        if (!sym) return;

        const src = this._source || this.engine?.source || 'default';
        const cacheKey = `${sym}__D1__${src}`;
        const now = Date.now();
        const cached = this._htfDailyCache.get(cacheKey);

        if (cached && now - cached.fetchedAt < 60_000) {
            this._dailyBars = cached.bars;
            return;
        }

        try {
            const apiBase =
                typeof window !== 'undefined' && window.location && window.location.origin
                    ? ''
                    : 'http://127.0.0.1:8765';
            const url = `${apiBase}/api/bars?symbol=${encodeURIComponent(sym)}&timeframe=D1&count=1000&source=${encodeURIComponent(src)}`;
            const res = await fetch(url);
            if (!res.ok) return;
            const json = await res.json();
            const rawList = Array.isArray(json) ? json : Array.isArray(json?.bars) ? json.bars : [];
            const cleanDaily: BarData[] = rawList
                .filter(
                    (b: any) =>
                        b &&
                        Number.isFinite(Number(b.time)) &&
                        Number.isFinite(Number(b.open)) &&
                        Number.isFinite(Number(b.high)) &&
                        Number.isFinite(Number(b.low)) &&
                        Number.isFinite(Number(b.close))
                )
                .map((b: any) => ({
                    time: Number(b.time),
                    open: Number(b.open),
                    high: Number(b.high),
                    low: Number(b.low),
                    close: Number(b.close),
                    volume: Number(b.volume || 0),
                }))
                .sort((a: BarData, b: BarData) => a.time - b.time);

            if (cleanDaily.length > 0) {
                this._dailyBars = cleanDaily;
                this._htfDailyCache.set(cacheKey, { bars: cleanDaily, fetchedAt: now });
            }
        } catch (_err) {
            // Fallback to intraday session calculation
        }
    }

    private _getSessionShiftSeconds(unixSeconds: number): number {
        const mode = String(this.params.sessionReset || 'auto');
        const sym = (this._symbol || this.engine?.symbol || '').toUpperCase();

        if (mode === 'utc0') return 0;
        if (mode === 'th0') return 7 * 3600;

        let useNy17 = mode === 'ny17';
        if (mode === 'auto') {
            const isCrypto =
                sym.includes('BTC') ||
                sym.includes('ETH') ||
                sym.includes('SOL') ||
                sym.includes('BNB') ||
                sym.includes('XRP') ||
                sym.includes('DOGE') ||
                sym.includes('USDT');
            useNy17 = !isCrypto;
        }

        if (useNy17) {
            const isEdt = this._isUsDaylightSavingTime(unixSeconds);
            return isEdt ? 3 * 3600 : 2 * 3600;
        }

        return 0;
    }

    private _isUsDaylightSavingTime(unixSeconds: number): boolean {
        const d = new Date(unixSeconds * 1000);
        const year = d.getUTCFullYear();
        const month = d.getUTCMonth();

        if (month > 2 && month < 10) return true;
        if (month < 2 || month > 10) return false;

        if (month === 2) {
            const marchFirstDay = new Date(Date.UTC(year, 2, 1)).getUTCDay();
            const secondSunday = 1 + ((7 - marchFirstDay) % 7) + 7;
            const dstStartUtc = Date.UTC(year, 2, secondSunday, 7, 0, 0) / 1000;
            return unixSeconds >= dstStartUtc;
        }

        const novFirstDay = new Date(Date.UTC(year, 10, 1)).getUTCDay();
        const firstSunday = 1 + ((7 - novFirstDay) % 7);
        const dstEndUtc = Date.UTC(year, 10, firstSunday, 6, 0, 0) / 1000;
        return unixSeconds < dstEndUtc;
    }

    private _getSessionKey(unixSeconds: number, shiftSeconds: number): number {
        return Math.floor((unixSeconds + shiftSeconds) / 86400);
    }

    private _parseSymbolList(input: any, currentChartSymbol: string): string[] {
        const raw = String(input ?? '').trim();
        const curSym = (currentChartSymbol || 'XAUUSD').trim().toUpperCase();
        if (!raw || raw.toLowerCase() === 'current' || raw.toLowerCase() === 'auto') {
            return [curSym];
        }

        const startsWithComma = raw.startsWith(',');

        if (raw.includes(',')) {
            const tokens = raw
                .split(',')
                .map((s) => s.trim().toUpperCase())
                .filter((s) => s.length > 0);
            const resolved = tokens.map((s) => (s === 'CURRENT' ? curSym : s));

            // Only prepend chart symbol if the user explicitly started input with a comma (e.g. ", XAGUSD, BTCUSD")
            if (startsWithComma && !resolved.includes(curSym)) {
                return [curSym, ...resolved];
            }
            return resolved;
        }

        const single = raw.toUpperCase();
        if (single === 'CURRENT') return [curSym];
        return [single];
    }

    private _detectDigitsForSymbol(symbol: string): number {
        const sym = (symbol || '').toUpperCase();
        if (sym.includes('XAU') || sym.includes('GOLD')) return 2;
        if (sym.includes('XAG') || sym.includes('SILVER')) return 3;
        if (sym.includes('BTC') || sym.includes('ETH')) return 2;
        if (sym.includes('JPY')) return 3;
        const FIAT_CURRENCIES = new Set([
            'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD',
            'SGD', 'HKD', 'CNH', 'CNY', 'SEK', 'NOK', 'DKK', 'ZAR',
            'MXN', 'PLN', 'TRY', 'THB', 'INR', 'KRW', 'BRL', 'TWD'
        ]);
        if (sym.length === 6 && FIAT_CURRENCIES.has(sym.slice(0, 3)) && FIAT_CURRENCIES.has(sym.slice(3, 6))) {
            return 5;
        }
        return 2;
    }

    private async _fetchExternalSymbolsData(symbols: string[]): Promise<void> {
        const primarySym = (this._symbol || this.engine?.symbol || '').toUpperCase();
        const needed = symbols.filter((s) => s && s.toUpperCase() !== primarySym);
        if (needed.length === 0) return;

        const src = this._source || this.engine?.source || '';
        const srcParam = src ? `&source=${encodeURIComponent(src)}` : '';
        const apiBase =
            typeof window !== 'undefined' && window.location && window.location.origin
                ? ''
                : 'http://127.0.0.1:8765';

        try {
            const symsParam = encodeURIComponent(needed.join(','));
            const res = await fetch(`${apiBase}/api/watchlist-stats?symbols=${symsParam}&timeframe=M5${srcParam}`);
            if (res.ok) {
                const data = await res.json();
                if (Array.isArray(data) && data.length > 0) {
                    const now = Date.now();
                    for (const item of data) {
                        const sUpper = String(item.symbol || '').toUpperCase();
                        const last = Number(item.last || 0);
                        if (last > 0) {
                            this._externalSymbolData.set(sUpper, {
                                last,
                                low: Number(item.low ?? last),
                                high: Number(item.high ?? last),
                                chg_pct: Number(item.chg_pct ?? 0),
                                digits: Number.isFinite(Number(item.digits))
                                    ? Number(item.digits)
                                    : this._detectDigitsForSymbol(sUpper),
                                fetchedAt: now,
                            });
                        }
                    }
                }
            }
        } catch (_err) {
            // Fallback to /api/tick
        }

        // For any symbol not found in watchlist-stats, query /api/tick
        for (const s of needed) {
            const cached = this._externalSymbolData.get(s);
            if (!cached || cached.last <= 0 || Date.now() - cached.fetchedAt > 2000) {
                try {
                    const resTick = await fetch(`${apiBase}/api/tick?symbol=${encodeURIComponent(s)}${srcParam}`);
                    if (resTick.ok) {
                        const tick = await resTick.json();
                        const p =
                            Number(tick.last) > 0
                                ? Number(tick.last)
                                : Number(tick.bid) > 0
                                    ? Number(tick.bid)
                                    : Number(tick.ask);
                        if (p > 0) {
                            const digits = this._detectDigitsForSymbol(s);
                            const prev = this._externalSymbolData.get(s);
                            let chgPct = prev ? prev.chg_pct : 0;
                            if (prev && prev.last > 0 && p !== prev.last && chgPct === 0) {
                                chgPct = ((p - prev.last) / prev.last) * 100;
                            }
                            this._externalSymbolData.set(s, {
                                last: p,
                                low: prev ? Math.min(prev.low, p) : p,
                                high: prev ? Math.max(prev.high, p) : p,
                                chg_pct: chgPct,
                                digits,
                                bid: Number(tick.bid) || undefined,
                                ask: Number(tick.ask) || undefined,
                                fetchedAt: Date.now(),
                            });
                        }
                    }
                } catch (_e) {
                    // Ignore tick fetch error
                }
            }
        }
    }

    private _recomputeHudMetrics(): void {
        const n = this._rawBars.length;
        const lastBar = n > 0 ? this._rawBars[n - 1] : null;

        const priceSource = String(this.params.priceSource || 'last');
        let activePrice = lastBar ? lastBar.close : 0;
        if (priceSource === 'bid' && this._liveBid !== null) {
            activePrice = this._liveBid;
        } else if (priceSource === 'ask' && this._liveAsk !== null) {
            activePrice = this._liveAsk;
        } else if (priceSource === 'mid' && this._liveBid !== null && this._liveAsk !== null) {
            activePrice = (this._liveBid + this._liveAsk) / 2;
        }

        const isDailyChart =
            n >= 2 && lastBar && this._rawBars[n - 1].time - this._rawBars[n - 2].time >= 43200;

        let dayOpen = lastBar ? lastBar.open : 0;
        let dayHigh = lastBar ? Math.max(lastBar.high, activePrice) : activePrice;
        let dayLow = lastBar ? Math.min(lastBar.low, activePrice) : activePrice;
        let prevDayClose: number | null = null;

        if (lastBar) {
            if (isDailyChart) {
                dayOpen = lastBar.open;
                dayHigh = Math.max(lastBar.high, activePrice);
                dayLow = Math.min(lastBar.low, activePrice);
                if (n >= 2) {
                    prevDayClose = this._rawBars[n - 2].close;
                }
            } else {
                const shiftSec = this._getSessionShiftSeconds(lastBar.time);
                const currentSessionKey = this._getSessionKey(lastBar.time, shiftSec);

                for (let i = n - 1; i >= 0; i--) {
                    const b = this._rawBars[i];
                    const bKey = this._getSessionKey(b.time, shiftSec);
                    if (bKey === currentSessionKey) {
                        dayOpen = b.open;
                        if (b.high > dayHigh) dayHigh = b.high;
                        if (b.low < dayLow) dayLow = b.low;
                    } else if (bKey < currentSessionKey) {
                        prevDayClose = b.close;
                        break;
                    }
                }

                if (this._dailyBars.length > 0) {
                    const dLen = this._dailyBars.length;
                    const lastD1 = this._dailyBars[dLen - 1];

                    const isLastD1CurrentSession =
                        this._getSessionKey(lastD1.time, shiftSec) === currentSessionKey ||
                        (lastBar.time >= lastD1.time && lastBar.time - lastD1.time < 86400);

                    if (isLastD1CurrentSession) {
                        dayHigh = Math.max(dayHigh, lastD1.high);
                        dayLow = Math.min(dayLow, lastD1.low);
                        if (prevDayClose === null && dLen >= 2) {
                            prevDayClose = this._dailyBars[dLen - 2].close;
                        }
                    } else if (prevDayClose === null && lastD1.time < lastBar.time) {
                        prevDayClose = lastD1.close;
                    }
                }
            }
        }

        const refMode = String(this.params.dailyRefMode || 'prevClose');
        const refPrice =
            refMode === 'prevClose' && prevDayClose !== null && prevDayClose > 0
                ? prevDayClose
                : dayOpen > 0
                    ? dayOpen
                    : lastBar
                        ? lastBar.open
                        : activePrice;

        const change = activePrice - refPrice;
        const changePct = refPrice !== 0 ? (change / refPrice) * 100 : 0;

        const displaySymbol =
            (this._symbol ||
                (this.engine && this.engine.symbol ? String(this.engine.symbol) : '') ||
                'XAUUSD').toUpperCase();

        const primaryMetric: SymbolMetric = {
            symbol: displaySymbol,
            lastPrice: activePrice,
            bidPrice: this._liveBid,
            askPrice: this._liveAsk,
            refPrice,
            change,
            changePct,
            dayHigh,
            dayLow,
            digits: this._detectedDigits,
            isUp: change > 0,
            isDown: change < 0,
            hasData: n > 0 && activePrice > 0,
        };

        const reqSymbols = this._parseSymbolList(this.params.symbols, displaySymbol);
        const resolvedSymbolsList: SymbolMetric[] = [];

        for (const reqSym of reqSymbols) {
            const symUpper = reqSym.toUpperCase();
            if (symUpper === displaySymbol && primaryMetric.hasData) {
                resolvedSymbolsList.push({ ...primaryMetric, symbol: symUpper });
            } else {
                const ext = this._externalSymbolData.get(symUpper);
                if (ext && ext.last > 0) {
                    const chg = ext.chg_pct;
                    const digits = ext.digits ?? this._detectDigitsForSymbol(symUpper);
                    resolvedSymbolsList.push({
                        symbol: symUpper,
                        lastPrice: ext.last,
                        bidPrice: ext.bid ?? null,
                        askPrice: ext.ask ?? null,
                        refPrice: ext.last / (1 + chg / 100),
                        change: (ext.last * chg) / 100,
                        changePct: chg,
                        dayHigh: ext.high,
                        dayLow: ext.low,
                        digits,
                        isUp: chg > 0,
                        isDown: chg < 0,
                        hasData: true,
                    });
                } else if (symUpper === displaySymbol) {
                    resolvedSymbolsList.push({ ...primaryMetric, symbol: symUpper });
                } else {
                    resolvedSymbolsList.push({
                        symbol: symUpper,
                        lastPrice: 0,
                        bidPrice: null,
                        askPrice: null,
                        refPrice: 0,
                        change: 0,
                        changePct: 0,
                        dayHigh: 0,
                        dayLow: 0,
                        digits: this._detectDigitsForSymbol(symUpper),
                        isUp: false,
                        isDown: false,
                        hasData: false,
                    });
                }
            }
        }

        const first = resolvedSymbolsList.length > 0 ? resolvedSymbolsList[0] : primaryMetric;

        this._hudMetrics = {
            symbol: first.symbol,
            lastPrice: first.lastPrice,
            bidPrice: first.bidPrice,
            askPrice: first.askPrice,
            refPrice: first.refPrice,
            change: first.change,
            changePct: first.changePct,
            dayHigh: first.dayHigh,
            dayLow: first.dayLow,
            digits: first.digits,
            isUp: first.isUp,
            isDown: first.isDown,
            hasData: first.hasData || (n > 0 && activePrice > 0),
            symbols: resolvedSymbolsList,
        };
    }
}

export default LastPriceHudIndicator;