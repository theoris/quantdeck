/**
 * ML Market Regime Classifier Indicator (Phase 2)
 * Connects to Python FastAPI Backend (/api/ml/regime/predict)
 * Output: 0 = Ranging, 1 = Trending, 2 = High Volatility
 */

export default {
  name: "ML Market Regime",
  pane: "sub",
  description: "AI Hidden Markov Model (0=Ranging, 1=Trending, 2=High Vol)",
  params: {
    color: "#00e676",
    lineWidth: 2
  },
  paramDefs: [
    { key: "color", label: "Line Color", type: "color", default: "#00e676" },
    {
      key: "lineWidth",
      label: "Line Width",
      type: "select",
      default: 2,
      options: [
        { label: "1px", value: 1 },
        { label: "2px", value: 2 },
        { label: "3px", value: 3 }
      ]
    }
  ],

  async calculate(bars, params) {
    if (!bars || bars.length < 30) return [];
    try {
      const res = await fetch('/api/ml/regime/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bars })
      });
      if (!res.ok) return [];
      const json = await res.json();
      if (!json || json.status !== 'ok' || !Array.isArray(json.data)) return [];
      return json.data.map(item => ({
        time: item.time,
        value: item.regime
      }));
    } catch (e) {
      console.error('[ML Market Regime] API error:', e);
      return [];
    }
  }
};
