/**
 * QuantDeck Custom Indicator: Footprint + Iceberg Sweep + Order Flow Score
 * All-in-one Order Flow tool for Binance
 */

export class FootprintIndicator {
    public id: string;
    public name: string;
    public pane: 'main' | 'sub';
    public isVisible: boolean = true;
    public params: Record<string, any>;
    public paramDefs: Array<{
        key: string;
        label: string;
        type: 'number' | 'color' | 'select';
        default: any;
        min?: number;
        max?: number;
        step?: number;
        options?: Array<{ label: string; value: any }>;
    }>;

    private engine: any = null;
    private series: any = null;
    private scoreSeries: any = null;
    private _primitive: any = null;
    private _rawBars: any[] = [];
    private cachedData: any[] = [];
    private cachedMarkers: any[] = [];
    private footprintMap: Map<number, any> = new Map();

    constructor() {
        this.id = `custom_ind_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        this.name = 'Footprint + Flow Score';
        this.pane = 'main';
        this.isVisible = true;

        this.params = {
            barsToShow: 50,
            maxLevels: 12,
            imbalanceRatio: 3,
            absorptionThreshold: 2.5,
            showLabels: 1,
            showPriceLevels: 1,
            enableIcebergSweep: 1,
            icebergSensitivity: 2,
            sweepSensitivity: 2,
            showFlowScore: 1,
            textColor: '#000000',
            bidColor: '#ef5350',
            askColor: '#26a69a',
            scoreColor: '#ab47bc',
        };

        this.paramDefs = [
            { key: 'barsToShow', label: 'Bars to Display', type: 'number', default: 50, min: 5, max: 200, step: 1 },
            { key: 'maxLevels', label: 'Max Price Levels per Bar', type: 'number', default: 12, min: 5, max: 30, step: 1 },
            { key: 'imbalanceRatio', label: 'Imbalance Ratio', type: 'number', default: 3, min: 2, max: 10, step: 0.5 },
            { key: 'absorptionThreshold', label: 'Absorption Multiplier', type: 'number', default: 2.5, min: 1.5, max: 5, step: 0.1 },
            {
                key: 'showLabels',
                label: 'Show Footprint Labels',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showPriceLevels',
                label: 'Show Price Levels',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'enableIcebergSweep',
                label: 'Enable Iceberg & Sweep',
                type: 'select',
                default: 1,
                options: [{ label: 'Enable', value: 1 }, { label: 'Disable', value: 0 }],
            },
            {
                key: 'icebergSensitivity',
                label: 'Iceberg Sensitivity',
                type: 'select',
                default: 2,
                options: [
                    { label: 'Low', value: 1 },
                    { label: 'Medium', value: 2 },
                    { label: 'High', value: 3 },
                ],
            },
            {
                key: 'sweepSensitivity',
                label: 'Sweep Sensitivity',
                type: 'select',
                default: 2,
                options: [
                    { label: 'Low', value: 1 },
                    { label: 'Medium', value: 2 },
                    { label: 'High', value: 3 },
                ],
            },
            {
                key: 'showFlowScore',
                label: 'Show Order Flow Score',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            { key: 'textColor', label: 'Text Color', type: 'color', default: '#000000' },
            { key: 'bidColor', label: 'Bid Volume Color', type: 'color', default: '#ef5350' },
            { key: 'askColor', label: 'Ask Volume Color', type: 'color', default: '#26a69a' },
            { key: 'scoreColor', label: 'Flow Score Line Color', type: 'color', default: '#ab47bc' },
        ];
    }

    async calculate(bars: any[], symbol?: string): Promise<any> {
        this._rawBars = bars || [];
        if (!bars || bars.length === 0) return [];

        const sym = (symbol || 'BTCUSDT').toUpperCase();
        const barsToProcess = Math.min(Math.max(5, this.params.barsToShow || 50), bars.length);
        const targetBars = bars.slice(-barsToProcess);

        const result = await this._fetchByBarPriority(sym, targetBars);
        this.footprintMap = result.map;
        this.cachedMarkers = result.markers;

        // Build score series data
        this.cachedData = targetBars.map(b => {
            const fp = this.footprintMap.get(b.time);
            const score = fp ? this._calculateFlowScore(fp) : 0;
            return { time: b.time, value: score };
        });

        return this.cachedData;
    }

    private _calculateFlowScore(fp: any): number {
        if (!fp || !fp.levels || fp.levels.length === 0) return 0;

        let score = 0;
        const total = fp.total || 1;
        const deltaRatio = fp.delta / total;

        // Delta contribution
        score += deltaRatio * 40;

        // Imbalance contribution
        let buyImb = 0;
        let sellImb = 0;
        for (const lv of fp.levels) {
            if (lv.ask > lv.bid * this.params.imbalanceRatio) buyImb++;
            if (lv.bid > lv.ask * this.params.imbalanceRatio) sellImb++;
        }
        score += (buyImb - sellImb) * 8;

        // Clamp between -100 and 100
        return Math.max(-100, Math.min(100, Math.round(score)));
    }

    private async _fetchByBarPriority(symbol: string, bars: any[]) {
        const map = new Map<number, any>();
        const markers: any[] = [];

        if (bars.length === 0) return { map, markers };

        const MAX_REQUESTS = 20;
        const DELAY_MS = 160;
        let requestCount = 0;

        for (let i = bars.length - 1; i >= 0 && requestCount < MAX_REQUESTS; i--) {
            const bar = bars[i];
            const barStart = bar.time * 1000;
            const barEnd = (i < bars.length - 1 ? bars[i + 1].time : bar.time + 300) * 1000;

            try {
                const url = `https://api.binance.com/api/v3/aggTrades?symbol=${encodeURIComponent(symbol)}&startTime=${barStart}&endTime=${barEnd}&limit=1000`;
                const res = await fetch(url);
                requestCount++;

                if (!res.ok) continue;
                const trades: any[] = await res.json();
                if (!trades || trades.length === 0) continue;

                const priceLevels = new Map<number, { bid: number; ask: number; count: number }>();

                for (const tr of trades) {
                    const price = parseFloat(tr.p);
                    const qty = parseFloat(tr.q);
                    const isBuyerMaker = tr.m;
                    const key = Math.round(price * 100) / 100;

                    if (!priceLevels.has(key)) priceLevels.set(key, { bid: 0, ask: 0, count: 0 });
                    const cell = priceLevels.get(key)!;
                    cell.count++;
                    if (isBuyerMaker) cell.bid += qty;
                    else cell.ask += qty;
                }

                const sorted = Array.from(priceLevels.entries())
                    .map(([price, vol]) => ({ price, ...vol, total: vol.bid + vol.ask }))
                    .sort((a, b) => b.total - a.total)
                    .slice(0, this.params.maxLevels);

                const totalBid = sorted.reduce((s, c) => s + c.bid, 0);
                const totalAsk = sorted.reduce((s, c) => s + c.ask, 0);
                const delta = totalAsk - totalBid;
                const totalVol = totalBid + totalAsk;

                const fpData = {
                    levels: sorted,
                    delta,
                    total: totalVol,
                    trades: trades.length,
                    open: bar.open,
                    high: bar.high,
                    low: bar.low,
                    close: bar.close,
                };

                map.set(bar.time, fpData);

                if (Number(this.params.showLabels) === 1) {
                    const fpLabel = this._detectFootprintPattern(sorted, bar, delta, totalBid, totalAsk);
                    if (fpLabel) {
                        markers.push({ time: bar.time, position: fpLabel.position, color: fpLabel.color, shape: 'circle', text: fpLabel.text });
                    }
                }

                if (Number(this.params.enableIcebergSweep) === 1) {
                    const isLabels = this._detectIcebergSweep(sorted, bar, trades, delta, totalVol);
                    for (const lb of isLabels) {
                        markers.push({ time: bar.time, position: lb.position, color: lb.color, shape: 'circle', text: lb.text });
                    }
                }

                // Flow Score label (simple)
                if (Number(this.params.showFlowScore) === 1) {
                    const score = this._calculateFlowScore(fpData);
                    if (Math.abs(score) >= 35) {
                        markers.push({
                            time: bar.time,
                            position: score > 0 ? 'aboveBar' : 'belowBar',
                            color: score > 0 ? '#26a69a' : '#ef5350',
                            shape: 'circle',
                            text: score > 0 ? `FLOW +${score}` : `FLOW ${score}`,
                        });
                    }
                }

                if (requestCount < MAX_REQUESTS && i > 0) {
                    await new Promise(r => setTimeout(r, DELAY_MS));
                }
            } catch (e) {
                continue;
            }
        }

        return { map, markers };
    }

    private _detectFootprintPattern(levels: any[], bar: any, delta: number, totalBid: number, totalAsk: number) {
        if (levels.length === 0) return null;
        const ratio = this.params.imbalanceRatio;
        let buyStack = 0, sellStack = 0;
        for (const lv of levels) {
            if (lv.ask > lv.bid * ratio) buyStack++;
            if (lv.bid > lv.ask * ratio) sellStack++;
        }
        if (buyStack >= 3) return { text: 'STACKED BUY IMB', position: 'aboveBar' as const, color: '#26a69a' };
        if (sellStack >= 3) return { text: 'STACKED SELL IMB', position: 'belowBar' as const, color: '#ef5350' };

        const maxVol = Math.max(...levels.map(l => l.total));
        const avgVol = levels.reduce((s, l) => s + l.total, 0) / Math.max(1, levels.length);
        if (maxVol > avgVol * this.params.absorptionThreshold) {
            const extreme = levels.find(l => l.total === maxVol);
            if (extreme) {
                const range = Math.max(bar.high - bar.low, 0.0001);
                if (Math.abs(extreme.price - bar.low) / range < 0.3 && extreme.bid > extreme.ask && delta > 0)
                    return { text: 'ABSORPTION (BUY)', position: 'belowBar' as const, color: '#26a69a' };
                if (Math.abs(extreme.price - bar.high) / range < 0.3 && extreme.ask > extreme.bid && delta < 0)
                    return { text: 'ABSORPTION (SELL)', position: 'aboveBar' as const, color: '#ef5350' };
            }
        }
        if (Math.abs(delta) > (totalBid + totalAsk) * 0.35) {
            return delta > 0
                ? { text: 'STRONG BUY DELTA', position: 'aboveBar' as const, color: '#26a69a' }
                : { text: 'STRONG SELL DELTA', position: 'belowBar' as const, color: '#ef5350' };
        }
        return null;
    }

    private _detectIcebergSweep(levels: any[], bar: any, trades: any[], delta: number, totalVol: number) {
        const labels: any[] = [];
        if (levels.length === 0 || trades.length < 5) return labels;

        const maxLevel = levels[0];
        const avgLevelVol = levels.reduce((s, l) => s + l.total, 0) / levels.length;
        const icebergMult = this.params.icebergSensitivity === 1 ? 4 : this.params.icebergSensitivity === 3 ? 2.2 : 3;

        if (maxLevel && maxLevel.total > avgLevelVol * icebergMult && maxLevel.count >= 4) {
            const range = Math.max(bar.high - bar.low, 0.0001);
            const pricePos = (maxLevel.price - bar.low) / range;
            if (maxLevel.bid > maxLevel.ask * 1.4 && pricePos < 0.4)
                labels.push({ text: 'ICEBERG BUY', position: 'belowBar' as const, color: '#26a69a' });
            else if (maxLevel.ask > maxLevel.bid * 1.4 && pricePos > 0.6)
                labels.push({ text: 'ICEBERG SELL', position: 'aboveBar' as const, color: '#ef5350' });
        }

        const uniquePrices = new Set(trades.map(t => Math.round(parseFloat(t.p) * 100) / 100)).size;
        const avgTradeSize = totalVol / Math.max(1, trades.length);
        const largeTrades = trades.filter(t => parseFloat(t.q) > avgTradeSize * 2.2).length;

        if (uniquePrices >= 4 && largeTrades >= 3 && trades.length > 8) {
            if (delta > totalVol * 0.25) labels.push({ text: 'SWEEP UP', position: 'aboveBar' as const, color: '#66bb6a' });
            else if (delta < -totalVol * 0.25) labels.push({ text: 'SWEEP DOWN', position: 'belowBar' as const, color: '#ef5350' });
        }

        if (labels.some(l => l.text.startsWith('SWEEP')) && labels.some(l => l.text.startsWith('ICEBERG'))) {
            labels.push({ text: 'ABSORBED SWEEP', position: 'aboveBar' as const, color: '#ffeb3b' });
        }

        return labels;
    }

    render(engine: any, onSettings?: () => void, onClose?: () => void) {
        this.engine = engine;
        const scalePos = typeof engine.getPriceScalePosition === 'function' ? engine.getPriceScalePosition() : 'right';

        this.series = engine.chart.addLineSeries({
            priceScaleId: scalePos,
            color: 'transparent',
            lineWidth: 1,
            lastValueVisible: false,
            priceLineVisible: false,
        });

        if (Number(this.params.showFlowScore) === 1) {
            this.scoreSeries = engine.chart.addLineSeries({
                priceScaleId: scalePos,
                color: this.params.scoreColor,
                lineWidth: 2,
                lineStyle: 0,
                title: 'Flow Score',
            });
        }

        this._createPrimitive();
        if (engine.getMainSeries && this._primitive) {
            engine.getMainSeries().attachPrimitive(this._primitive);
        }

        this.setData(this.cachedData);
    }

    private _createPrimitive() {
        const self = this;
        this._primitive = {
            attached: () => { },
            detached: () => { },
            paneViews: () => [{
                renderer: () => ({
                    draw: (target: any) => {
                        if (!self.isVisible || !self.engine || Number(self.params.showPriceLevels) !== 1) return;
                        const chart = self.engine.chart;
                        const mainSeries = self.engine.getMainSeries?.();
                        if (!chart || !mainSeries) return;
                        const timeScale = chart.timeScale();
                        const textColor = self.params.textColor || '#000000';

                        const drawFn = (context: CanvasRenderingContext2D) => {
                            context.save();
                            context.font = '10px monospace';
                            context.textAlign = 'center';
                            context.textBaseline = 'middle';

                            for (const [time, fp] of self.footprintMap) {
                                const x = timeScale.timeToCoordinate(time as any);
                                if (x === null) continue;
                                const barWidth = Math.max(22, (timeScale.options().barSpacing || 6) * 0.9);
                                let yOffset = 0;

                                for (const lv of fp.levels.slice(0, 8)) {
                                    const y = mainSeries.priceToCoordinate(lv.price);
                                    if (y === null) continue;

                                    context.fillStyle = self.params.bidColor + 'cc';
                                    context.fillRect(x - barWidth / 2, y - 7 + yOffset, barWidth / 2 - 1, 13);
                                    context.fillStyle = textColor;
                                    context.fillText(lv.bid.toFixed(1), x - barWidth / 4, y + yOffset);

                                    context.fillStyle = self.params.askColor + 'cc';
                                    context.fillRect(x + 1, y - 7 + yOffset, barWidth / 2 - 1, 13);
                                    context.fillStyle = textColor;
                                    context.fillText(lv.ask.toFixed(1), x + barWidth / 4, y + yOffset);

                                    context.font = '8px monospace';
                                    context.fillText(lv.price.toFixed(1), x, y + yOffset - 11);
                                    context.font = '10px monospace';
                                    yOffset += 14;
                                }

                                const deltaY = mainSeries.priceToCoordinate(fp.low);
                                if (deltaY !== null) {
                                    context.fillStyle = fp.delta >= 0 ? '#26a69a' : '#ef5350';
                                    context.fillText(`Δ ${fp.delta > 0 ? '+' : ''}${fp.delta.toFixed(1)}`, x, deltaY + 18);
                                }
                            }
                            context.restore();
                        };

                        if (target.useMediaCoordinateSpace) target.useMediaCoordinateSpace(({ context }: any) => drawFn(context));
                        else if (target.useBitmapCoordinateSpace) target.useBitmapCoordinateSpace(({ context }: any) => drawFn(context));
                    },
                }),
            }],
            requestUpdate: () => { },
        };
    }

    setData(data: any[]) {
        if (this.series) this.series.setData(data || []);
        if (this.scoreSeries && Number(this.params.showFlowScore) === 1) {
            this.scoreSeries.setData(data || []);
        }
        this.applyMarkers();
        this._primitive?.requestUpdate?.();
    }

    update(bar: any) {
        if (!bar) return;
        const idx = this._rawBars.findIndex(b => b.time === bar.time);
        if (idx >= 0) this._rawBars[idx] = bar;
        else this._rawBars.push(bar);
    }

    updateParams(newParams: any, engine: any) {
        this.params = { ...this.params, ...newParams };
        const bars = (engine && engine.allBars && engine.allBars.length > 0) ? engine.allBars : this._rawBars;
        this.calculate(bars).then(() => this.setData(this.cachedData));
    }

    setVisible(visible: boolean) {
        this.isVisible = visible !== false;
        this.series?.applyOptions({ visible: this.isVisible });
        this.scoreSeries?.applyOptions({ visible: this.isVisible && Number(this.params.showFlowScore) === 1 });
        if (!this.isVisible) this.clearMarkers();
        else this.applyMarkers();
        this._primitive?.requestUpdate?.();
    }

    applyMarkers() {
        if (!this.engine || !this.isVisible) {
            this.clearMarkers();
            return;
        }
        if (typeof this.engine.setIndicatorMarkers === 'function') {
            this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries && typeof mainSeries.setMarkers === 'function') {
            mainSeries.setMarkers(this.cachedMarkers || []);
        }
    }

    clearMarkers() {
        if (!this.engine) return;
        if (typeof this.engine.clearIndicatorMarkers === 'function') {
            this.engine.clearIndicatorMarkers(this.id);
        }
    }

    destroy(engine: any) {
        this.clearMarkers();
        if (this._primitive && engine?.getMainSeries) {
            try { engine.getMainSeries().detachPrimitive(this._primitive); } catch (e) { }
        }
        if (this.series && engine?.chart) engine.chart.removeSeries(this.series);
        if (this.scoreSeries && engine?.chart) engine.chart.removeSeries(this.scoreSeries);
        this.series = null;
        this.scoreSeries = null;
        this._primitive = null;
        this.engine = null;
    }
}

export default FootprintIndicator;