/**
 * SuperTrend Indicator for QuantDeck
 * Type: Main Overlay
 * Description: ATR Volatility Trend Breakout Bands
 */

export default {
  name: "SuperTrend",
  pane: "main",
  description: "ATR Volatility Trend Breakout Bands",
  params: {
    period: 10,
    multiplier: 3.0,
    upColor: "#00E676",
    downColor: "#FF1744",
    lineWidth: 2
  },
  paramDefs: [
    { key: "period", label: "ATR Period", type: "number", default: 10, min: 2, max: 100 },
    { key: "multiplier", label: "ATR Multiplier", type: "number", default: 3.0, min: 0.5, max: 10.0, step: 0.1 },
    { key: "upColor", label: "Up Trend Color", type: "color", default: "#00E676" },
    { key: "downColor", label: "Down Trend Color", type: "color", default: "#FF1744" },
    {
      key: "lineWidth",
      label: "Line Width",
      type: "select",
      default: 2,
      options: [
        { label: "1px", value: 1 },
        { label: "2px", value: 2 },
        { label: "3px", value: 3 },
        { label: "4px", value: 4 }
      ]
    }
  ],

  calculate(bars, params) {
    const period = params.period || 10;
    const mult = params.multiplier || 3.0;
    const upColor = params.upColor || "#00E676";
    const downColor = params.downColor || "#FF1744";

    if (!bars || bars.length < period + 1) return [];

    // 1. Calculate True Range (TR)
    const tr = [bars[0].high - bars[0].low];
    for (let i = 1; i < bars.length; i++) {
      const h = bars[i].high;
      const l = bars[i].low;
      const prevC = bars[i - 1].close;
      tr.push(Math.max(h - l, Math.abs(h - prevC), Math.abs(l - prevC)));
    }

    // 2. Initial ATR
    let atr = 0;
    for (let i = 0; i < period; i++) {
      atr += tr[i];
    }
    atr /= period;

    const atrs = new Array(bars.length).fill(0);
    atrs[period - 1] = atr;
    for (let i = period; i < bars.length; i++) {
      atr = (atr * (period - 1) + tr[i]) / period;
      atrs[i] = atr;
    }

    // 3. Calculate SuperTrend bands
    const result = [];
    let prevLower = 0;
    let prevUpper = 0;
    let trend = 1; // 1 = Bullish, -1 = Bearish

    for (let i = period; i < bars.length; i++) {
      const hl2 = (bars[i].high + bars[i].low) / 2;
      const currentAtr = atrs[i];
      let basicUpper = hl2 + mult * currentAtr;
      let basicLower = hl2 - mult * currentAtr;

      let upper = basicUpper;
      let lower = basicLower;

      if (i > period) {
        const prevC = bars[i - 1].close;
        if (basicLower > prevLower || prevC < prevLower) {
          lower = basicLower;
        } else {
          lower = prevLower;
        }

        if (basicUpper < prevUpper || prevC > prevUpper) {
          upper = basicUpper;
        } else {
          upper = prevUpper;
        }
      }

      if (bars[i].close > prevUpper) {
        trend = 1;
      } else if (bars[i].close < prevLower) {
        trend = -1;
      }

      prevLower = lower;
      prevUpper = upper;

      const val = trend === 1 ? lower : upper;
      const color = trend === 1 ? upColor : downColor;

      result.push({
        time: bars[i].time,
        value: val,
        color: color
      });
    }

    return result;
  }
};
