# QuantDeck Custom Indicators & Community Plugins Guide

This directory is the dedicated home for user-created and community open-source technical indicators for **QuantDeck**.

---

## 1. Open-Source Community Indicator Repositories (TypeScript / JS)

You can explore, study, and inspect existing open-source indicator implementations from these official and community repositories:

1. **TradingView Lightweight Charts Official Plugin Examples:**
   - URL: [https://github.com/tradingview/lightweight-charts/tree/master/plugin-examples](https://github.com/tradingview/lightweight-charts/tree/master/plugin-examples)
   - *Contents:* Complete TypeScript examples for Anchored VWAP, Trend Lines, Session High/Low, Tooltips, Volume Profile, and custom series primitives.

2. **TechnicalIndicators (100% TypeScript / JavaScript Indicator Engine):**
   - URL: [https://github.com/anandanand84/technicalindicators](https://github.com/anandanand84/technicalindicators)
   - *Contents:* 50+ quantitative indicators written in pure TypeScript, including:
     - SuperTrend, RSI, Stochastic (%K/%D), Bollinger Bands, MACD, ATR, ADX, CCI, Ichimoku Cloud, Parabolic SAR, Keltner Channels, Williams %R, VWAP, SMA/EMA/WMA.

3. **TradingView Lightweight Charts Plugins Tutorial & Documentation:**
   - URL: [https://tradingview.github.io/lightweight-charts/tutorials/plugins/](https://tradingview.github.io/lightweight-charts/tutorials/plugins/)

4. **Community Plugins & Extensions for Lightweight Charts:**
   - URL: [https://github.com/timocov/lightweight-charts-plugins](https://github.com/timocov/lightweight-charts-plugins)

---

## 2. How to Add a New Custom Indicator to QuantDeck

### Step 1: Save your indicator file in this folder
Place your `.js` or `.ts` indicator file inside:
```
F:\GIT\App28_bot\chart\custom_indicators\
```
*(Example: `my_indicator.js` or `supertrend.js`)*

### Step 2: Open QuantDeck & Import
1. In QuantDeck, click the **"📊 Indicators"** button on the top toolbar.
2. Go to the **"🧩 Community / Custom"** tab.
3. Click **"🔍 Scan Folder"** to detect any new or updated indicator files.
4. Click **"➕ Import & Add"** next to your indicator. It will instantly calculate and display on the chart!

---

## 3. Indicator File Format

You can write your indicator using **Simple Mode** (easiest) or **Advanced Mode** (full control).

### Simple Mode (Recommended)
Export a default JavaScript object:
```javascript
export default {
  name: "ATR Bands",
  pane: "main", // "main" = overlay on price, "sub" = separate bottom pane
  description: "Average True Range Bands",
  params: {
    period: 14,
    color: "#ff9800",
    lineWidth: 2
  },
  paramDefs: [
    { key: "period", label: "Period", type: "number", default: 14, min: 2, max: 100 },
    { key: "color", label: "Line Color", type: "color", default: "#ff9800" },
    { key: "lineWidth", label: "Width", type: "select", default: 2, options: [
      { label: "1px", value: 1 },
      { label: "2px", value: 2 },
      { label: "3px", value: 3 }
    ]}
  ],
  calculate(bars, params) {
    // bars: Array of { time, open, high, low, close, volume }
    const results = [];
    // Calculate your values...
    for (let i = 0; i < bars.length; i++) {
      results.push({
        time: bars[i].time,
        value: bars[i].close
      });
    }
    return results;
  }
};
```
