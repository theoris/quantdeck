// Standalone Indicator: Higher Timeframe Moving Average (HTF EMA/SMA/WMA/RMA)
// Compatible with Lightweight Charts v4 (Native ES Module, Zero-Dependency)
// Uses true native Higher Timeframe historical bars (1,000 HTF bars via /api/bars)
// so long-period MAs (e.g. D1 EMA 100/200 viewed on M5/M15) have full institutional warmup accuracy.

const _HTF_BARS_CACHE = new Map();

export class HtfMovingAverageIndicator {
  constructor() {
    this.id = `htf_ma_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    this.name = 'HTF Moving Average';
    this.pane = 'main';
    this.isVisible = true;

    this.currentSymbol = 'XAUUSD';
    this.currentSource = '';

    // 1. Default Parameters (Removed unnecessary Session Daily Cutoff)
    this.params = {
      htf: '1D',                // Default Higher Timeframe: Daily (D1)
      period: 100,              // Default Period: 100
      maType: 'EMA',            // Default MA Type: Exponential (EMA)
      smoothingMode: 'smooth',  // 'smooth' = Smooth Intraday / True HTF, 'step' = Step on HTF Bar
      lineColor: '#f59e0b',     // Line Color: Amber Gold
      lineStyle: 0,             // Line Style: 0 = Solid, 1 = Dotted, 2 = Dashed
      lineWidth: 2,             // Line Width: 2px
      showLastValue: 1,         // Show price tag on Y-Axis
      showPriceLine: 1,         // Show horizontal price level line across chart
    };

    // 2. GUI Settings Definitions
    this.paramDefs = [
      {
        key: 'htf',
        label: 'Higher Timeframe',
        type: 'select',
        default: '1D',
        options: [
          { label: '15 Minutes (M15)', value: '15' },
          { label: '30 Minutes (M30)', value: '30' },
          { label: '1 Hour (H1)', value: '60' },
          { label: '4 Hours (H4)', value: '240' },
          { label: 'Daily (D1)', value: '1D' },
          { label: 'Weekly (W1)', value: '1W' },
          { label: 'Monthly (MN1)', value: '1M' },
        ],
      },
      {
        key: 'period',
        label: 'Period (Length)',
        type: 'number',
        default: 100,
        min: 1,
        max: 500,
        step: 1,
      },
      {
        key: 'maType',
        label: 'MA Type',
        type: 'select',
        default: 'EMA',
        options: [
          { label: 'Exponential (EMA)', value: 'EMA' },
          { label: 'Simple (SMA)', value: 'SMA' },
          { label: 'Weighted (WMA)', value: 'WMA' },
          { label: 'Wilders (RMA)', value: 'RMA' },
        ],
      },
      {
        key: 'smoothingMode',
        label: 'HTF Curve Mode',
        type: 'select',
        default: 'smooth',
        options: [
          { label: 'Smooth (Live Intraday Progression)', value: 'smooth' },
          { label: 'Step (HTF Bar Boundaries)', value: 'step' },
        ],
      },
      {
        key: 'lineColor',
        label: 'Line Color',
        type: 'color',
        default: '#f59e0b',
      },
      {
        key: 'lineStyle',
        label: 'Line Style',
        type: 'select',
        default: 0,
        options: [
          { label: 'Solid', value: 0 },
          { label: 'Dotted', value: 1 },
          { label: 'Dashed', value: 2 },
        ],
      },
      {
        key: 'lineWidth',
        label: 'Line Width',
        type: 'select',
        default: 2,
        options: [
          { label: '1px', value: 1 },
          { label: '2px', value: 2 },
          { label: '3px', value: 3 },
          { label: '4px', value: 4 },
        ],
      },
      {
        key: 'showPriceLine',
        label: 'Show Price Level Line',
        type: 'select',
        default: 1,
        options: [
          { label: 'Show', value: 1 },
          { label: 'Hide', value: 0 },
        ],
      },
      {
        key: 'showLastValue',
        label: 'Show Y-Axis Price Badge',
        type: 'select',
        default: 1,
        options: [
          { label: 'Show', value: 1 },
          { label: 'Hide', value: 0 },
        ],
      },
    ];

    this.series = null;
    this.engine = null;
    this.cachedData = [];
    this._rawBars = [];
    this._htfBars = [];
    this._lastKnownScale = 'right';
  }

  setSymbol(symbol) {
    if (symbol && typeof symbol === 'string') {
      this.currentSymbol = symbol.trim().toUpperCase();
    }
  }

  setSource(source) {
    if (source && typeof source === 'string') {
      this.currentSource = source.trim().toUpperCase();
    }
  }

  _resolveActiveSymbol(symbolArg) {
    if (symbolArg && typeof symbolArg === 'string' && symbolArg.trim()) {
      this.currentSymbol = symbolArg.trim().toUpperCase();
      return this.currentSymbol;
    }
    if (this.currentSymbol) return this.currentSymbol;
    try {
      const symInput = document.getElementById('symbol-input');
      if (symInput && symInput.value) {
        return symInput.value.trim().toUpperCase();
      }
    } catch (e) {}
    return 'XAUUSD';
  }

  _resolveActiveSource() {
    if (this.currentSource) return this.currentSource;
    try {
      const srcSelect = document.getElementById('source-select');
      if (srcSelect && srcSelect.value) {
        return srcSelect.value.trim().toUpperCase();
      }
    } catch (e) {}
    return '';
  }

  _resolveApiTimeframe(htf) {
    const key = String(htf || '1D').trim().toUpperCase();
    const map = {
      '1': 'M1',
      '5': 'M5',
      '15': 'M15',
      '30': 'M30',
      '60': 'H1',
      '120': 'H2',
      '240': 'H4',
      '1D': 'D1',
      'D1': 'D1',
      'D': 'D1',
      '1440': 'D1',
      '1W': 'W1',
      'W1': 'W1',
      'W': 'W1',
      '1M': 'MN1',
      'MN1': 'MN1',
      'M15': 'M15',
      'M30': 'M30',
      'H1': 'H1',
      'H4': 'H4',
    };
    return map[key] || 'D1';
  }

  _getHtfSeconds(apiTf) {
    const map = {
      M1: 60,
      M5: 300,
      M15: 900,
      M30: 1800,
      H1: 3600,
      H2: 7200,
      H4: 14400,
      D1: 86400,
      W1: 604800,
      MN1: 2592000,
    };
    return map[apiTf] || 86400;
  }

  // Robust timestamp extractor supporting numbers, strings, and BusinessDay objects
  _getBarSeconds(time) {
    if (typeof time === 'number') {
      return time > 1e11 ? Math.floor(time / 1000) : time;
    }
    if (typeof time === 'string') {
      const num = Number(time);
      if (!isNaN(num) && num > 0) return num > 1e11 ? Math.floor(num / 1000) : num;
      const parsed = Date.parse(time);
      if (!isNaN(parsed)) return Math.floor(parsed / 1000);
    }
    if (time && typeof time === 'object') {
      if ('year' in time && 'month' in time && 'day' in time) {
        return Math.floor(Date.UTC(time.year, time.month - 1, time.day) / 1000);
      }
    }
    return 0;
  }

  // Normalize HTF bar start timestamp so EOD-stamped daily bars (e.g. SET 16:30 BKK / 09:30 UTC)
  // align cleanly from the start of that trading day on intraday charts
  _getNormalizedHtfStartSec(htfBarTime, apiTf) {
    const sec = this._getBarSeconds(htfBarTime);
    if (apiTf === 'D1') {
      const d = new Date(sec * 1000);
      // If stamped at SET EOD (09:30 UTC = 16:30 BKK), shift to 00:00 BKK of that date (-16.5h)
      if (d.getUTCHours() === 9 && d.getUTCMinutes() === 30) {
        return sec - 16.5 * 3600;
      }
    }
    return sec;
  }

  // Fallback resampler used only if backend API is unreachable
  _buildFallbackHtfBars(bars, apiTf) {
    const htfBars = [];
    const intervalSec = this._getHtfSeconds(apiTf);
    let currentHtf = null;

    for (let i = 0; i < bars.length; i++) {
      const sec = this._getBarSeconds(bars[i].time);
      const bucketTime = Math.floor(sec / intervalSec) * intervalSec;
      if (!currentHtf || currentHtf.bucketTime !== bucketTime) {
        currentHtf = {
          bucketTime,
          time: bucketTime,
          open: bars[i].open,
          high: bars[i].high,
          low: bars[i].low,
          close: bars[i].close,
          volume: bars[i].volume || 0,
        };
        htfBars.push(currentHtf);
      } else {
        currentHtf.high = Math.max(currentHtf.high, bars[i].high);
        currentHtf.low = Math.min(currentHtf.low, bars[i].low);
        currentHtf.close = bars[i].close;
        currentHtf.volume += bars[i].volume || 0;
      }
    }
    return htfBars;
  }

  async _fetchTrueHtfBars(symbol, source, apiTf, fallbackBars) {
    const cacheKey = `${source || 'AUTO'}:${symbol}:${apiTf}`;
    const now = Date.now();
    const cached = _HTF_BARS_CACHE.get(cacheKey);
    if (cached && Array.isArray(cached.bars) && cached.bars.length > 0 && now - cached.ts < 25000) {
      return cached.bars;
    }

    try {
      const srcQuery = source ? `&source=${encodeURIComponent(source)}` : '';
      const url = `/api/bars?symbol=${encodeURIComponent(symbol)}&timeframe=${encodeURIComponent(apiTf)}&count=1000${srcQuery}`;
      const resp = await fetch(url);
      if (resp.ok) {
        const data = await resp.json();
        if (Array.isArray(data) && data.length > 0) {
          _HTF_BARS_CACHE.set(cacheKey, { ts: now, bars: data });
          return data;
        }
      }
    } catch (err) {
      console.warn('[HTF_MA] Failed to fetch native HTF bars, using fallback:', err);
    }

    if (cached && Array.isArray(cached.bars) && cached.bars.length > 0) {
      return cached.bars;
    }
    return this._buildFallbackHtfBars(fallbackBars, apiTf);
  }

  // Institutional Moving Average calculation with standard SMA seeding for EMA and RMA
  _calculateMaSeries(closes, period, maType) {
    const n = closes.length;
    const ma = new Array(n).fill(NaN);
    if (n === 0) return ma;

    const p = Math.max(1, parseInt(period, 10) || 100);

    if (maType === 'SMA') {
      let runningSum = 0;
      for (let i = 0; i < n; i++) {
        runningSum += closes[i];
        if (i >= p) {
          runningSum -= closes[i - p];
          ma[i] = runningSum / p;
        } else {
          ma[i] = runningSum / (i + 1);
        }
      }
    } else if (maType === 'EMA') {
      const k = 2 / (p + 1);
      let runningSum = 0;
      for (let i = 0; i < n; i++) {
        if (i < p) {
          runningSum += closes[i];
          ma[i] = runningSum / (i + 1);
        } else {
          ma[i] = closes[i] * k + ma[i - 1] * (1 - k);
        }
      }
    } else if (maType === 'WMA') {
      for (let i = 0; i < n; i++) {
        const lookback = Math.min(i + 1, p);
        const weightSum = (lookback * (lookback + 1)) / 2;
        let weightedSum = 0;
        for (let j = 0; j < lookback; j++) {
          weightedSum += closes[i - lookback + 1 + j] * (j + 1);
        }
        ma[i] = weightedSum / weightSum;
      }
    } else if (maType === 'RMA') {
      const k = 1 / p;
      let runningSum = 0;
      for (let i = 0; i < n; i++) {
        if (i < p) {
          runningSum += closes[i];
          ma[i] = runningSum / (i + 1);
        } else {
          ma[i] = closes[i] * k + ma[i - 1] * (1 - k);
        }
      }
    }

    return ma;
  }

  // Compute intraday live-progressed or stepped HTF MA across all chart bars
  _projectHtfMaToChartBars(bars, rawHtfBars, apiTf) {
    if (!bars || bars.length === 0 || !rawHtfBars || rawHtfBars.length === 0) {
      return [];
    }

    // Clone HTF bars and sync the latest HTF bar's close with the latest chart bar's close
    const htfBars = rawHtfBars.map((b) => ({ ...b }));
    const lastChartBar = bars[bars.length - 1];
    const lastChartSec = this._getBarSeconds(lastChartBar.time);
    const htfSec = this._getHtfSeconds(apiTf);

    const lastHtf = htfBars[htfBars.length - 1];
    const lastHtfStartSec = this._getNormalizedHtfStartSec(lastHtf.time, apiTf);

    if (lastChartSec >= lastHtfStartSec + htfSec) {
      // A new HTF bar has started on the live chart before the cache refreshed
      const newBucketTime = lastHtfStartSec + Math.floor((lastChartSec - lastHtfStartSec) / htfSec) * htfSec;
      htfBars.push({
        time: newBucketTime,
        open: lastChartBar.open,
        high: lastChartBar.high,
        low: lastChartBar.low,
        close: lastChartBar.close,
        volume: lastChartBar.volume || 0,
      });
    } else if (lastChartSec >= lastHtfStartSec) {
      // Update current forming HTF bar with latest live chart close
      lastHtf.close = lastChartBar.close;
      lastHtf.high = Math.max(lastHtf.high, lastChartBar.high);
      lastHtf.low = Math.min(lastHtf.low, lastChartBar.low);
    }

    const htfStartTimes = htfBars.map((b) => this._getNormalizedHtfStartSec(b.time, apiTf));
    const htfCloses = htfBars.map((b) => b.close);
    const p = Math.max(1, parseInt(this.params.period, 10) || 100);
    const maType = this.params.maType || 'EMA';
    const isSmooth = this.params.smoothingMode !== 'step';

    const htfMa = this._calculateMaSeries(htfCloses, p, maType);

    const result = [];
    const n = bars.length;
    const m = htfBars.length;
    let htfIdx = 0;

    const kEma = 2 / (p + 1);
    const kRma = 1 / p;

    for (let i = 0; i < n; i++) {
      const sec = this._getBarSeconds(bars[i].time);

      while (htfIdx + 1 < m && htfStartTimes[htfIdx + 1] <= sec) {
        htfIdx++;
      }

      let val = htfMa[htfIdx];

      // In Smooth mode, evaluate the forming HTF MA at each intraday bar's close
      // anchored on the previous completed HTF bar (htfIdx - 1), eliminating lookahead bias
      // while converging to the exact HTF close MA at the end of every HTF bar.
      if (isSmooth && htfIdx > 0 && sec >= htfStartTimes[htfIdx]) {
        const prevMa = htfMa[htfIdx - 1];
        const curClose = bars[i].close;
        if (!isNaN(prevMa) && isFinite(prevMa)) {
          if (maType === 'EMA') {
            val = curClose * kEma + prevMa * (1 - kEma);
          } else if (maType === 'RMA') {
            val = curClose * kRma + prevMa * (1 - kRma);
          } else if (maType === 'SMA') {
            const lookback = Math.min(htfIdx + 1, p);
            let sum = curClose;
            for (let j = 1; j < lookback; j++) {
              sum += htfCloses[htfIdx - j];
            }
            val = sum / lookback;
          } else if (maType === 'WMA') {
            const lookback = Math.min(htfIdx + 1, p);
            const weightSum = (lookback * (lookback + 1)) / 2;
            let weightedSum = curClose * lookback;
            for (let j = 0; j < lookback - 1; j++) {
              weightedSum += htfCloses[htfIdx - lookback + 1 + j] * (j + 1);
            }
            val = weightedSum / weightSum;
          }
        }
      }

      if (!isNaN(val) && isFinite(val)) {
        result.push({
          time: bars[i].time,
          value: Number(val.toFixed(4)),
        });
      }
    }

    this.cachedData = result;
    return result;
  }

  async calculate(bars, symbol) {
    if (!bars || bars.length === 0) {
      this.cachedData = [];
      this._rawBars = [];
      return [];
    }

    this._rawBars = bars;
    const sym = this._resolveActiveSymbol(symbol);
    const src = this._resolveActiveSource();
    const apiTf = this._resolveApiTimeframe(this.params.htf);

    const htfBars = await this._fetchTrueHtfBars(sym, src, apiTf, bars);
    this._htfBars = htfBars;

    return this._projectHtfMaToChartBars(bars, htfBars, apiTf);
  }

  _getActivePriceScaleId() {
    if (!this.engine) return 'right';
    const mainSeries = this.engine.getMainSeries();
    if (mainSeries && typeof mainSeries.priceScale === 'function') {
      try {
        const id = mainSeries.priceScale().id();
        if (id) return id;
      } catch (e) {}
    }
    return typeof this.engine.getPriceScalePosition === 'function'
      ? this.engine.getPriceScalePosition()
      : 'right';
  }

  _syncPriceScale() {
    const activeScale = this._getActivePriceScaleId();
    if (this.series && this._lastKnownScale !== activeScale) {
      this._lastKnownScale = activeScale;
      this.series.applyOptions({ priceScaleId: activeScale });
    }
  }

  render(engine, onSettings, onClose) {
    this.engine = engine;
    const scalePos = this._getActivePriceScaleId();
    this._lastKnownScale = scalePos;
    const apiTf = this._resolveApiTimeframe(this.params.htf);

    // Create Main Chart Line Series
    this.series = engine.chart.addLineSeries({
      color: this.params.lineColor,
      lineWidth: this.params.lineWidth,
      lineStyle: this.params.lineStyle,
      priceScaleId: scalePos,
      title: `${apiTf} ${this.params.maType} ${this.params.period}`,
      lastValueVisible: Number(this.params.showLastValue) === 1,
      priceLineVisible: Number(this.params.showPriceLine) === 1,
      visible: this.isVisible !== false,
    });

    if (this.cachedData.length > 0 && this.series) {
      this.series.setData(this.cachedData);
    } else {
      const bars =
        engine.allBars ||
        (typeof engine.getMainSeries === 'function' && engine.getMainSeries()?.data
          ? engine.getMainSeries().data()
          : []) ||
        [];
      if (bars.length > 0) {
        const res = this.calculate(bars, this.currentSymbol);
        if (res && typeof res.then === 'function') {
          res.then((d) => {
            if (d) this.setData(d);
          });
        } else if (res) {
          this.setData(res);
        }
      }
    }
  }

  update(bar) {
    if (!bar) return;
    if (this._rawBars.length > 0) {
      const last = this._rawBars[this._rawBars.length - 1];
      if (last.time === bar.time) {
        this._rawBars[this._rawBars.length - 1] = bar;
      } else {
        this._rawBars.push(bar);
      }

      // Fast synchronous projection using cached _htfBars on live ticks
      if (this._htfBars && this._htfBars.length > 0) {
        const apiTf = this._resolveApiTimeframe(this.params.htf);
        const newData = this._projectHtfMaToChartBars(this._rawBars, this._htfBars, apiTf);
        this.setData(newData);
      } else {
        const res = this.calculate(this._rawBars, this.currentSymbol);
        if (res && typeof res.then === 'function') {
          res.then((d) => {
            if (d) this.setData(d);
          });
        } else if (res) {
          this.setData(res);
        }
      }
    }
  }

  setData(data) {
    this._syncPriceScale();
    if (this.series && Array.isArray(data)) {
      this.series.setData(data);
    }
  }

  setVisible(visible) {
    this.isVisible = visible;
    if (this.series && typeof this.series.applyOptions === 'function') {
      this.series.applyOptions({ visible: visible !== false });
    }
  }

  updateParams(newParams, engine) {
    this.params = { ...this.params, ...newParams };
    this._syncPriceScale();
    const apiTf = this._resolveApiTimeframe(this.params.htf);

    if (this.series) {
      this.series.applyOptions({
        color: this.params.lineColor,
        lineWidth: this.params.lineWidth,
        lineStyle: this.params.lineStyle,
        title: `${apiTf} ${this.params.maType} ${this.params.period}`,
        lastValueVisible: Number(this.params.showLastValue) === 1,
        priceLineVisible: Number(this.params.showPriceLine) === 1,
        visible: this.isVisible !== false,
      });
    }

    const bars = (engine && engine.allBars && engine.allBars.length > 0) ? engine.allBars : this._rawBars;
    if (bars && bars.length > 0) {
      const res = this.calculate(bars, this.currentSymbol);
      if (res && typeof res.then === 'function') {
        res.then((d) => {
          if (d) this.setData(d);
        });
      } else if (res) {
        this.setData(res);
      }
    }
  }

  destroy(engine) {
    if (this.series && engine && engine.chart) {
      try {
        engine.chart.removeSeries(this.series);
      } catch (e) {}
    }
    this.cachedData = [];
    this._rawBars = [];
    this._htfBars = [];
    this.series = null;
    this.engine = null;
  }
}

export default HtfMovingAverageIndicator;
