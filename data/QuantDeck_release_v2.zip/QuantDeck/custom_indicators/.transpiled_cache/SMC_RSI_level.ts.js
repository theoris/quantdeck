// @ts-sha256: 2de47e7e34a11ccb680e70f2c74e1669a3f59205783dabba51ba820113afe110
// Standalone Indicator: SMC (Smart Money Concepts) + Wilson RPC + Precision Levels + Theme Engine
// Compatible with Lightweight Charts v4 (Native ES Module)
// ============================================================================
// 1. Custom Primitive: Canvas Pane View for SMC Graphics & Right Levels
// ============================================================================
class SmcCanvasPaneView {
    constructor(primitive) {
        this._primitive = primitive;
    }
    zOrder() {
        return 'normal';
    }
    renderer() {
        return {
            draw: (target) => {
                const primitive = this._primitive;
                const indicator = primitive._indicator;
                if (!indicator || indicator.isVisible === false)
                    return;
                const chart = primitive._chart || indicator.engine?.chart;
                const series = primitive._series || indicator.engine?.getMainSeries() || indicator.baseSeries;
                if (!chart || !series)
                    return;
                const bars = indicator._rawBars || [];
                if (bars.length < 5)
                    return;
                const lastBar = indicator.lastBar || bars[bars.length - 1];
                const timeScale = chart.timeScale();
                const tc = indicator._getThemeColors();
                const getBarX = (barIdx, barTime) => {
                    let x = null;
                    if (barTime !== undefined) {
                        try {
                            x = timeScale.timeToCoordinate(barTime);
                        }
                        catch (e) { }
                    }
                    if ((x === null || x === undefined || isNaN(x)) && typeof timeScale.logicalToCoordinate === 'function' && barIdx !== undefined) {
                        try {
                            x = timeScale.logicalToCoordinate(barIdx);
                        }
                        catch (e) { }
                    }
                    return x !== null && x !== undefined && !isNaN(x) ? x : null;
                };
                const getPriceY = (price) => {
                    if (price === null || price === undefined || isNaN(price) || !isFinite(price))
                        return null;
                    const y = series.priceToCoordinate(price);
                    return y !== null && y !== undefined && !isNaN(y) ? y : null;
                };
                let lastX = getBarX(bars.length - 1, lastBar?.time);
                const renderFn = (ctx, width, height) => {
                    ctx.save();
                    // ------------------------------------------------------------------
                    // A. SMC Order Block (OB) Zones
                    // ------------------------------------------------------------------
                    if (Number(indicator.params.showSmc) === 1 && Number(indicator.params.showObZones) === 1 && indicator.computedOBs?.length > 0) {
                        for (const ob of indicator.computedOBs) {
                            const x1Raw = getBarX(ob.startIdx, ob.startTime);
                            const x2Raw = ob.mitigated && ob.endIdx !== undefined
                                ? getBarX(ob.endIdx, ob.endTime)
                                : (lastX !== null ? lastX + 35 : width);
                            if (x1Raw === null || x2Raw === null)
                                continue;
                            const leftX = Math.min(x1Raw, x2Raw);
                            const rightX = Math.max(x1Raw, x2Raw);
                            if (rightX < 0 || leftX > width)
                                continue;
                            const yTopRaw = getPriceY(ob.top);
                            const yBotRaw = getPriceY(ob.bottom);
                            if (yTopRaw === null || yBotRaw === null)
                                continue;
                            const topY = Math.min(yTopRaw, yBotRaw);
                            const botY = Math.max(yTopRaw, yBotRaw);
                            if (botY < 0 || topY > height)
                                continue;
                            const boxW = Math.max(3, rightX - leftX);
                            const boxH = Math.max(2, botY - topY);
                            // Fill
                            ctx.fillStyle = ob.isBull ? tc.obBullFill : tc.obBearFill;
                            ctx.fillRect(leftX, topY, boxW, boxH);
                            // Border
                            ctx.strokeStyle = ob.isBull ? tc.obBullBorder : tc.obBearBorder;
                            ctx.lineWidth = 1;
                            if (ob.mitigated) {
                                ctx.setLineDash([3, 3]);
                            }
                            else {
                                ctx.setLineDash([]);
                            }
                            ctx.strokeRect(leftX, topY, boxW, boxH);
                            // Label badge inside near right edge
                            if (boxW > 32 && boxH >= 8) {
                                ctx.font = 'bold 9px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                                ctx.fillStyle = ob.isBull ? tc.obBullText : tc.obBearText;
                                ctx.textAlign = 'right';
                                ctx.textBaseline = 'middle';
                                const label = ob.isBull
                                    ? (ob.mitigated ? '+OB [Mit]' : '+OB')
                                    : (ob.mitigated ? '-OB [Mit]' : '-OB');
                                ctx.fillText(label, rightX - 4, topY + boxH / 2);
                            }
                        }
                    }
                    // ------------------------------------------------------------------
                    // B. SMC Fair Value Gaps (FVG)
                    // ------------------------------------------------------------------
                    if (Number(indicator.params.showSmc) === 1 && Number(indicator.params.showFvg) === 1 && indicator.computedFVGs?.length > 0) {
                        for (const fvg of indicator.computedFVGs) {
                            const x1Raw = getBarX(fvg.startIdx, fvg.startTime);
                            const x2Raw = fvg.mitigated && fvg.endIdx !== undefined
                                ? getBarX(fvg.endIdx, fvg.endTime)
                                : (lastX !== null ? lastX + 20 : width);
                            if (x1Raw === null || x2Raw === null)
                                continue;
                            const leftX = Math.min(x1Raw, x2Raw);
                            const rightX = Math.max(x1Raw, x2Raw);
                            if (rightX < 0 || leftX > width)
                                continue;
                            const yTopRaw = getPriceY(fvg.top);
                            const yBotRaw = getPriceY(fvg.bottom);
                            if (yTopRaw === null || yBotRaw === null)
                                continue;
                            const topY = Math.min(yTopRaw, yBotRaw);
                            const botY = Math.max(yTopRaw, yBotRaw);
                            if (botY < 0 || topY > height)
                                continue;
                            const boxW = Math.max(2, rightX - leftX);
                            const boxH = Math.max(2, botY - topY);
                            ctx.fillStyle = fvg.isBull ? tc.fvgBullFill : tc.fvgBearFill;
                            ctx.fillRect(leftX, topY, boxW, boxH);
                            ctx.strokeStyle = fvg.isBull ? tc.fvgBullBorder : tc.fvgBearBorder;
                            ctx.lineWidth = 1;
                            ctx.setLineDash([2, 2]);
                            ctx.strokeRect(leftX, topY, boxW, boxH);
                            if (boxW > 28 && boxH >= 8) {
                                ctx.font = 'bold 8px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                                ctx.fillStyle = fvg.isBull ? tc.fvgBullBorder : tc.fvgBearBorder;
                                ctx.textAlign = 'right';
                                ctx.textBaseline = 'middle';
                                ctx.fillText('FVG', rightX - 3, topY + boxH / 2);
                            }
                        }
                    }
                    // ------------------------------------------------------------------
                    // C. BOS & CHoCH Breakout Structure Lines
                    // ------------------------------------------------------------------
                    if (Number(indicator.params.showSmc) === 1 && indicator.computedStructures?.length > 0) {
                        for (const st of indicator.computedStructures) {
                            if (st.type === 'BOS' && Number(indicator.params.showBos) !== 1)
                                continue;
                            if (st.type === 'CHoCH' && Number(indicator.params.showChoch) !== 1)
                                continue;
                            const y = getPriceY(st.price);
                            const x1 = getBarX(st.pivotIdx, st.pivotTime);
                            const x2 = getBarX(st.breakIdx, st.breakTime);
                            if (y === null || x1 === null || x2 === null)
                                continue;
                            const startX = Math.min(x1, x2);
                            const endX = Math.max(x1, x2);
                            if (endX < 0 || startX > width || y < 0 || y > height)
                                continue;
                            const color = st.isBull
                                ? (st.type === 'CHoCH' ? tc.chochBull : tc.bosBull)
                                : (st.type === 'CHoCH' ? tc.chochBear : tc.bosBear);
                            // Dashed structure line
                            ctx.strokeStyle = color;
                            ctx.lineWidth = 1.2;
                            ctx.setLineDash([4, 3]);
                            ctx.beginPath();
                            ctx.moveTo(startX, y);
                            ctx.lineTo(endX, y);
                            ctx.stroke();
                            // Center pill badge
                            const midX = (startX + endX) / 2;
                            const labelText = st.type;
                            ctx.font = 'bold 9px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                            const textWidth = ctx.measureText(labelText).width;
                            ctx.fillStyle = tc.badgeBg;
                            ctx.fillRect(midX - textWidth / 2 - 4, y - 6, textWidth + 8, 12);
                            ctx.strokeStyle = color;
                            ctx.lineWidth = 0.8;
                            ctx.setLineDash([]);
                            ctx.strokeRect(midX - textWidth / 2 - 4, y - 6, textWidth + 8, 12);
                            ctx.fillStyle = color;
                            ctx.textAlign = 'center';
                            ctx.textBaseline = 'middle';
                            ctx.fillText(labelText, midX, y);
                        }
                    }
                    // ------------------------------------------------------------------
                    // D. Equal Highs / Lows (EQH / EQL - Liquidity Pools)
                    // ------------------------------------------------------------------
                    if (Number(indicator.params.showSmc) === 1 && Number(indicator.params.showLiquidity) === 1 && indicator.computedLiquidity?.length > 0) {
                        for (const liq of indicator.computedLiquidity) {
                            const y = getPriceY(liq.price);
                            const x1 = getBarX(liq.idx1, liq.time1);
                            const x2 = getBarX(liq.idx2, liq.time2);
                            if (y === null || x1 === null || x2 === null)
                                continue;
                            const startX = Math.min(x1, x2);
                            const endX = Math.max(x1, x2) + 24;
                            if (endX < 0 || startX > width || y < 0 || y > height)
                                continue;
                            ctx.strokeStyle = tc.eqhLine;
                            ctx.lineWidth = 1;
                            ctx.setLineDash([2, 3]);
                            ctx.beginPath();
                            ctx.moveTo(startX, y);
                            ctx.lineTo(endX, y);
                            ctx.stroke();
                            ctx.font = 'bold 9px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                            ctx.fillStyle = tc.eqhLine;
                            ctx.textAlign = 'left';
                            ctx.textBaseline = 'middle';
                            ctx.fillText(liq.type, endX + 3, y);
                        }
                    }
                    // ------------------------------------------------------------------
                    // E. Swing Structure Points (HH, HL, LH, LL)
                    // ------------------------------------------------------------------
                    if (Number(indicator.params.showSmc) === 1 && Number(indicator.params.showSwingLabels) === 1 && indicator.computedSwings?.length > 0) {
                        for (const sw of indicator.computedSwings) {
                            const y = getPriceY(sw.price);
                            const x = getBarX(sw.idx, sw.time);
                            if (y === null || x === null || x < 0 || x > width || y < 0 || y > height)
                                continue;
                            ctx.font = 'bold 9px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                            ctx.textAlign = 'center';
                            ctx.fillStyle = sw.isHigh ? tc.swingHighColor : tc.swingLowColor;
                            if (sw.isHigh) {
                                ctx.textBaseline = 'bottom';
                                ctx.fillText(sw.label, x, y - 5);
                            }
                            else {
                                ctx.textBaseline = 'top';
                                ctx.fillText(sw.label, x, y + 5);
                            }
                        }
                    }
                    // ------------------------------------------------------------------
                    // F. Precision Right Levels (H, L, YH, YL, VWAP, DPOC, ADR, RSI 70/30)
                    // ------------------------------------------------------------------
                    if (Number(indicator.params.showLevelLines) === 1 && lastX !== null && lastX > 0) {
                        indicator._refreshRealtimeLevels();
                        const levels = indicator.computedLevels;
                        if (levels && levels.length > 0) {
                            const startX = lastX + 12;
                            const lineLength = 55;
                            const endX = startX + lineLength;
                            const validItems = [];
                            for (const lvl of levels) {
                                if (isNaN(lvl.price) || !isFinite(lvl.price))
                                    continue;
                                const y = getPriceY(lvl.price);
                                if (y === null || y < 5 || y > height - 5)
                                    continue;
                                validItems.push({
                                    label: lvl.label,
                                    price: lvl.price,
                                    color: lvl.color,
                                    lineStyle: lvl.lineStyle,
                                    lineWidth: lvl.lineWidth || 1,
                                    y: Math.round(y),
                                });
                            }
                            if (validItems.length > 0) {
                                validItems.sort((a, b) => a.y - b.y);
                                let lastItemY = -999;
                                let currentOffsetCol = 0;
                                for (let i = 0; i < validItems.length; i++) {
                                    const item = validItems[i];
                                    if (Math.abs(item.y - lastItemY) < 13) {
                                        currentOffsetCol = (currentOffsetCol + 1) % 2;
                                    }
                                    else {
                                        currentOffsetCol = 0;
                                    }
                                    item.textX = endX + 8 + currentOffsetCol * 52;
                                    lastItemY = item.y;
                                }
                                ctx.font = 'bold 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                                ctx.textBaseline = 'middle';
                                ctx.textAlign = 'left';
                                for (const item of validItems) {
                                    ctx.strokeStyle = item.color;
                                    ctx.lineWidth = item.lineWidth;
                                    if (item.lineStyle === 1 || item.lineStyle === 2) {
                                        ctx.setLineDash([4, 3]);
                                    }
                                    else {
                                        ctx.setLineDash([]);
                                    }
                                    ctx.beginPath();
                                    ctx.moveTo(startX, item.y);
                                    ctx.lineTo(endX, item.y);
                                    ctx.stroke();
                                    ctx.fillStyle = item.color;
                                    ctx.fillText(item.label, item.textX, item.y);
                                }
                            }
                        }
                    }
                    ctx.restore();
                };
                if (typeof target.useMediaCoordinateSpace === 'function') {
                    target.useMediaCoordinateSpace((scope) => {
                        renderFn(scope.context, scope.mediaSize.width, scope.mediaSize.height);
                    });
                }
                else if (typeof target.useBitmapCoordinateSpace === 'function') {
                    target.useBitmapCoordinateSpace((scope) => {
                        const ctx = scope.context;
                        const ratio = scope.horizontalPixelRatio || 1;
                        ctx.save();
                        ctx.scale(ratio, ratio);
                        renderFn(ctx, scope.mediaSize.width, scope.mediaSize.height);
                        ctx.restore();
                    });
                }
                else if (target.context) {
                    renderFn(target.context, target.context.canvas.width, target.context.canvas.height);
                }
            },
        };
    }
}
class SmcCanvasPrimitive {
    constructor(indicator) {
        this._indicator = indicator;
        this._chart = null;
        this._series = null;
        this._requestUpdate = null;
        this._paneViews = [new SmcCanvasPaneView(this)];
    }
    attached({ chart, series, requestUpdate }) {
        this._chart = chart;
        this._series = series;
        this._requestUpdate = requestUpdate;
    }
    detached() {
        this._chart = null;
        this._series = null;
        this._requestUpdate = null;
        if (this._indicator && !this._indicator._isDestroyed) {
            this._indicator._onPrimitiveDetached();
        }
    }
    paneViews() {
        return this._paneViews;
    }
    timeAxisViews() {
        return [];
    }
    priceAxisViews() {
        return [];
    }
    updateAllViews() { }
    requestUpdate() {
        if (typeof this._requestUpdate === 'function') {
            this._requestUpdate();
        }
    }
}
// ============================================================================
// 2. คลาสหลัก SmcWilsonRsiIndicator
// ============================================================================
export class SmcWilsonRsiIndicator {
    constructor() {
        this.id = `smc_wilson_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        this.name = 'SMC Pro + Wilson RPC & Precision Levels';
        this.pane = 'main';
        this.params = {
            // 1. Session / Market Timezone Settings
            sessionMode: 'forex_gold', // 'forex_gold' (17:00 NY), 'bkk' (UTC+7), 'utc' (00:00 UTC), 'custom'
            customOffsetHours: 2,
            // 2. Color Theme
            theme: 'dark', // 'dark' หรือ 'light'
            // 3. SMC Settings (Smart Money Concepts)
            showSmc: 1,
            pivotLen: 5,
            showChoch: 1,
            showBos: 1,
            showObZones: 1,
            maxActiveOb: 5,
            showSwingLabels: 1,
            showFvg: 1,
            showLiquidity: 1,
            // 4. Level Lines Switches
            showLevelLines: 1,
            showDayLevels: 1, // H, L, YH, YL
            showVwapLevels: 1, // VWAP, VWAP +2σ, VWAP -2σ (Session-anchored)
            showPocLevels: 1, // DPOC, WPOC, MPOC
            showAdrLevels: 1, // O, ADR_H, ADR_L
            showRsiPredictor: 1,
            obLevel: 70,
            osLevel: 30,
            showM5Rsi: 0,
            showM15Rsi: 0,
            showH1Rsi: 0,
            showH4Rsi: 0,
            // 5. Wilson RPC Settings
            showWilson: 1,
            lenRSI: 14,
            lenEMA: 34,
            widthMult: 2.0,
            lineWidth: 2,
            // 6. Divergence Settings
            showDivRsi: 1,
            lbLeft: 5,
            lbRight: 5,
        };
        this.paramDefs = [
            {
                key: 'sessionMode',
                label: '[Session] Market Daily Cutoff',
                type: 'select',
                default: 'forex_gold',
                options: [
                    { label: 'Gold / Forex / US (17:00 NY)', value: 'forex_gold' },
                    { label: 'Thai Market / TFEX (UTC+7)', value: 'bkk' },
                    { label: 'Crypto (00:00 UTC)', value: 'utc' },
                    { label: 'Custom Hour Offset', value: 'custom' },
                ],
            },
            {
                key: 'customOffsetHours',
                label: '[Session] Custom Offset Hours',
                type: 'number',
                default: 2,
                min: -12,
                max: 14,
                step: 1,
            },
            {
                key: 'theme',
                label: 'Chart Theme (Color Mode)',
                type: 'select',
                default: 'dark',
                options: [
                    { label: 'Dark Theme', value: 'dark' },
                    { label: 'Light Theme', value: 'light' },
                ],
            },
            {
                key: 'showSmc',
                label: '[SMC] Enable Smart Money Concepts',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'pivotLen',
                label: '[SMC] Pivot Lookback Length',
                type: 'number',
                default: 5,
                min: 2,
                max: 20,
                step: 1,
            },
            {
                key: 'showChoch',
                label: '[SMC] Show CHoCH (Change of Character)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showBos',
                label: '[SMC] Show BOS (Break of Structure)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showObZones',
                label: '[SMC] Show Order Block (OB) Zones',
                type: 'select',
                default: 1,
                options: [{ label: 'Show Zones', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'maxActiveOb',
                label: '[SMC] Max Active OB Zones',
                type: 'number',
                default: 5,
                min: 1,
                max: 15,
                step: 1,
            },
            {
                key: 'showSwingLabels',
                label: '[SMC] Show Swing Labels (HH/HL/LH/LL)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showFvg',
                label: '[SMC] Show Fair Value Gaps (FVG)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showLiquidity',
                label: '[SMC] Show Liquidity (EQH / EQL)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showLevelLines',
                label: '[Levels] Master Show Levels',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showDayLevels',
                label: '[Levels] Show H / L / YH / YL',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showVwapLevels',
                label: '[Levels] Show VWAP & ±2σ',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showPocLevels',
                label: '[Levels] Show DPOC / WPOC / MPOC',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showAdrLevels',
                label: '[Levels] Show O / ADR_H / ADR_L',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showRsiPredictor',
                label: '[Levels] Show RSI 70 / 30 Target',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showWilson',
                label: '[Wilson] Show Bands & EMA',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showDivRsi',
                label: '[Div] Show Divergence Arrows',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
        ];
        this.baseSeries = null;
        this.upperSeries = null;
        this.lowerSeries = null;
        this.engine = null;
        this.lastBar = null;
        this.cachedData = [];
        this.cachedUpperData = [];
        this.cachedLowerData = [];
        this.cachedMarkers = [];
        this.computedLevels = [];
        // SMC Data Cache
        this.computedStructures = [];
        this.computedOBs = [];
        this.computedFVGs = [];
        this.computedLiquidity = [];
        this.computedSwings = [];
        this._rawBars = [];
        this._rmaUp = [];
        this._rmaDown = [];
        this._staticLevels = {};
        this._isDestroyed = false;
        this._lastKnownScale = 'right';
        this._reattachTimer = null;
        this._watchdogTimer = null;
        this._unsubRange = null;
        this._unsubCrosshair = null;
        this.isVisible = true;
        this._primitive = new SmcCanvasPrimitive(this);
    }
    _getThemeColors() {
        const isLight = this.params.theme === 'light';
        if (isLight) {
            return {
                // Levels
                hlColor: '#0f172a',
                yhlColor: '#475569',
                vwapColor: '#1e293b',
                vwapBandColor: '#64748b',
                dpocColor: '#a21caf',
                wpocColor: '#86198f',
                mpocColor: '#701a75',
                adrColor: '#0369a1',
                rsiObColor: '#b91c1c',
                rsiOsColor: '#15803d',
                htfObColor: '#991b1b',
                htfOsColor: '#166534',
                wilsonBase: '#1d4ed8',
                wilsonUpper: '#b91c1c',
                wilsonLower: '#15803d',
                bullMarker: '#15803d',
                bearMarker: '#b91c1c',
                // SMC Pro Palette (Light Mode)
                obBullFill: 'rgba(16, 185, 129, 0.14)',
                obBullBorder: 'rgba(5, 150, 105, 0.65)',
                obBullText: '#047857',
                obBearFill: 'rgba(239, 68, 68, 0.14)',
                obBearBorder: 'rgba(220, 38, 38, 0.65)',
                obBearText: '#b91c1c',
                bosBull: '#059669',
                bosBear: '#dc2626',
                chochBull: '#0284c7',
                chochBear: '#ea580c',
                badgeBg: 'rgba(255, 255, 255, 0.92)',
                swingHighColor: '#475569',
                swingLowColor: '#475569',
                eqhLine: '#d97706',
                fvgBullFill: 'rgba(14, 165, 233, 0.12)',
                fvgBullBorder: 'rgba(2, 132, 199, 0.45)',
                fvgBearFill: 'rgba(249, 115, 22, 0.12)',
                fvgBearBorder: 'rgba(234, 88, 12, 0.45)',
            };
        }
        else {
            return {
                // Levels
                hlColor: '#f8fafc',
                yhlColor: '#94a3b8',
                vwapColor: '#e2e8f0',
                vwapBandColor: '#94a3b8',
                dpocColor: '#ff00ff',
                wpocColor: '#d946ef',
                mpocColor: '#c026d3',
                adrColor: '#06b6d4',
                rsiObColor: '#f43f5e',
                rsiOsColor: '#10b981',
                htfObColor: '#fb7185',
                htfOsColor: '#34d399',
                wilsonBase: '#38bdf8',
                wilsonUpper: '#f43f5e',
                wilsonLower: '#10b981',
                bullMarker: '#22c55e',
                bearMarker: '#ef4444',
                // SMC Pro Palette (Dark Mode)
                obBullFill: 'rgba(34, 197, 94, 0.16)',
                obBullBorder: 'rgba(34, 197, 94, 0.65)',
                obBullText: '#4ade80',
                obBearFill: 'rgba(244, 63, 94, 0.16)',
                obBearBorder: 'rgba(244, 63, 94, 0.65)',
                obBearText: '#fb7185',
                bosBull: '#10b981',
                bosBear: '#f43f5e',
                chochBull: '#06b6d4',
                chochBear: '#fb923c',
                badgeBg: 'rgba(15, 23, 42, 0.90)',
                swingHighColor: '#94a3b8',
                swingLowColor: '#94a3b8',
                eqhLine: '#fbbf24',
                fvgBullFill: 'rgba(56, 189, 248, 0.14)',
                fvgBullBorder: 'rgba(56, 189, 248, 0.45)',
                fvgBearFill: 'rgba(251, 146, 60, 0.14)',
                fvgBearBorder: 'rgba(251, 146, 60, 0.45)',
            };
        }
    }
    _getBarTimeSec(time) {
        if (typeof time === 'number') {
            return time > 1e11 ? Math.floor(time / 1000) : time;
        }
        return Math.floor(new Date(time).getTime() / 1000);
    }
    _getAdjustedDate(sec) {
        let offsetSec = 0;
        if (this.params.sessionMode === 'forex_gold') {
            offsetSec = 2 * 3600;
        }
        else if (this.params.sessionMode === 'bkk') {
            offsetSec = 7 * 3600;
        }
        else if (this.params.sessionMode === 'utc') {
            offsetSec = 0;
        }
        else {
            offsetSec = (this.params.customOffsetHours || 0) * 3600;
        }
        return new Date((sec + offsetSec) * 1000);
    }
    _calculateRSI(closes, length) {
        const n = closes.length;
        const rsi = new Array(n).fill(50);
        const rmaUp = new Array(n).fill(0);
        const rmaDown = new Array(n).fill(0);
        if (n < length + 1)
            return { rsi, rmaUp, rmaDown };
        let sumUp = 0;
        let sumDown = 0;
        for (let i = 1; i <= length; i++) {
            const diff = closes[i] - closes[i - 1];
            if (diff > 0)
                sumUp += diff;
            else
                sumDown += -diff;
        }
        rmaUp[length] = sumUp / length;
        rmaDown[length] = sumDown / length;
        const rs = rmaDown[length] === 0 ? 100 : rmaUp[length] / rmaDown[length];
        rsi[length] = 100 - 100 / (1 + rs);
        for (let i = length + 1; i < n; i++) {
            const diff = closes[i] - closes[i - 1];
            const up = diff > 0 ? diff : 0;
            const down = diff < 0 ? -diff : 0;
            rmaUp[i] = (rmaUp[i - 1] * (length - 1) + up) / length;
            rmaDown[i] = (rmaDown[i - 1] * (length - 1) + down) / length;
            if (rmaDown[i] === 0) {
                rsi[i] = 100;
            }
            else {
                const curRs = rmaUp[i] / rmaDown[i];
                rsi[i] = 100 - 100 / (1 + curRs);
            }
        }
        return { rsi, rmaUp, rmaDown };
    }
    _predictRsiPrice(target, close, prevUp, prevDown, length) {
        if (prevDown <= 0 && prevUp <= 0)
            return close;
        const rsTarget = target / (100.0 - target);
        const nextUp = rsTarget * prevDown * (length - 1) - prevUp * (length - 1);
        const nextDown = (prevUp * (length - 1)) / rsTarget - prevDown * (length - 1);
        return target >= 50 ? close + nextUp : close - nextDown;
    }
    _resampleCloses(bars, minutes) {
        const intervalSec = minutes * 60;
        const htfCloses = [];
        let currentBucket = -1;
        for (let i = 0; i < bars.length; i++) {
            const sec = this._getBarTimeSec(bars[i].time);
            const bucket = Math.floor(sec / intervalSec) * intervalSec;
            if (bucket !== currentBucket) {
                currentBucket = bucket;
                htfCloses.push(bars[i].close);
            }
            else {
                htfCloses[htfCloses.length - 1] = bars[i].close;
            }
        }
        return htfCloses;
    }
    _refreshRealtimeLevels() {
        const bars = this._rawBars;
        if (!bars || bars.length < 35)
            return;
        const n = bars.length;
        const lastBar = bars[n - 1];
        const closes = bars.map((b) => b.close);
        const tc = this._getThemeColors();
        const levels = [];
        // 1. Session-Anchored VWAP
        if (this.params.showVwapLevels === 1) {
            const lastSec = this._getBarTimeSec(lastBar.time);
            const lastDate = this._getAdjustedDate(lastSec);
            const todayKey = `${lastDate.getUTCFullYear()}-${lastDate.getUTCMonth() + 1}-${lastDate.getUTCDate()}`;
            let todayStartIdx = n - 1;
            while (todayStartIdx > 0) {
                const prevSec = this._getBarTimeSec(bars[todayStartIdx - 1].time);
                const prevDate = this._getAdjustedDate(prevSec);
                const prevKey = `${prevDate.getUTCFullYear()}-${prevDate.getUTCMonth() + 1}-${prevDate.getUTCDate()}`;
                if (prevKey !== todayKey)
                    break;
                todayStartIdx--;
            }
            let cumVol = 0;
            let cumCloseVol = 0;
            for (let i = todayStartIdx; i < n; i++) {
                const v = bars[i].volume && bars[i].volume > 0 ? bars[i].volume : 1;
                cumVol += v;
                cumCloseVol += bars[i].close * v;
            }
            const vwapBasis = cumVol > 0 ? cumCloseVol / cumVol : closes[n - 1];
            let devSqVol = 0;
            for (let i = todayStartIdx; i < n; i++) {
                const v = bars[i].volume && bars[i].volume > 0 ? bars[i].volume : 1;
                devSqVol += Math.pow(bars[i].close - vwapBasis, 2) * v;
            }
            const vwapStdev = cumVol > 0 ? Math.sqrt(devSqVol / cumVol) : 0;
            levels.push({ label: 'VWAP', price: vwapBasis, color: tc.vwapColor, lineStyle: 0, lineWidth: 2 });
            levels.push({ label: 'VWAP +2σ', price: vwapBasis + vwapStdev * 2, color: tc.vwapBandColor, lineStyle: 2, lineWidth: 1 });
            levels.push({ label: 'VWAP -2σ', price: vwapBasis - vwapStdev * 2, color: tc.vwapBandColor, lineStyle: 2, lineWidth: 1 });
        }
        // 2. Day Structure (H, L, YH, YL, O, ADR)
        const st = this._staticLevels;
        if (this.params.showDayLevels === 1 && st.todayOpen !== undefined) {
            const liveDayHigh = Math.max(st.todayHigh || -Infinity, lastBar.high);
            const liveDayLow = Math.min(st.todayLow || Infinity, lastBar.low);
            levels.push({ label: 'H', price: liveDayHigh, color: tc.hlColor, lineStyle: 2, lineWidth: 1.5 });
            levels.push({ label: 'L', price: liveDayLow, color: tc.hlColor, lineStyle: 2, lineWidth: 1.5 });
            if (st.yh !== undefined) {
                levels.push({ label: 'YH', price: st.yh, color: tc.yhlColor, lineStyle: 2, lineWidth: 1 });
                levels.push({ label: 'YL', price: st.yl, color: tc.yhlColor, lineStyle: 2, lineWidth: 1 });
            }
        }
        if (this.params.showPocLevels === 1 && st.dpoc) {
            levels.push({ label: 'DPOC', price: st.dpoc, color: tc.dpocColor, lineStyle: 0, lineWidth: 2 });
            levels.push({ label: 'WPOC', price: st.wpoc, color: tc.wpocColor, lineStyle: 0, lineWidth: 2 });
            levels.push({ label: 'MPOC', price: st.mpoc, color: tc.mpocColor, lineStyle: 0, lineWidth: 2 });
        }
        if (this.params.showAdrLevels === 1 && st.todayOpen !== undefined) {
            levels.push({ label: 'O', price: st.todayOpen, color: tc.adrColor, lineStyle: 2, lineWidth: 1 });
            if (st.adrVal) {
                levels.push({ label: 'ADR_H', price: st.todayOpen + st.adrVal, color: tc.adrColor, lineStyle: 2, lineWidth: 1 });
                levels.push({ label: 'ADR_L', price: st.todayOpen - st.adrVal, color: tc.adrColor, lineStyle: 2, lineWidth: 1 });
            }
        }
        // 3. RSI Predictor Realtime
        if (this.params.showRsiPredictor === 1 && this._rmaUp.length > 0) {
            const pUp = this._rmaUp[this._rmaUp.length - 1];
            const pDown = this._rmaDown[this._rmaDown.length - 1];
            const curClose = lastBar.close;
            const price70 = this._predictRsiPrice(this.params.obLevel, curClose, pUp, pDown, this.params.lenRSI);
            const price30 = this._predictRsiPrice(this.params.osLevel, curClose, pUp, pDown, this.params.lenRSI);
            levels.push({ label: `RSI ${this.params.obLevel}`, price: price70, color: tc.rsiObColor, lineStyle: 2, lineWidth: 1 });
            levels.push({ label: `RSI ${this.params.osLevel}`, price: price30, color: tc.rsiOsColor, lineStyle: 2, lineWidth: 1 });
            const checkHTFPredictor = (minutes, showFlag, label) => {
                if (showFlag === 1) {
                    const htfCloses = this._resampleCloses(bars, minutes);
                    if (htfCloses.length > this.params.lenRSI) {
                        const { rmaUp: htfUp, rmaDown: htfDown } = this._calculateRSI(htfCloses, this.params.lenRSI);
                        const hn = htfCloses.length - 1;
                        const htf70 = this._predictRsiPrice(this.params.obLevel, htfCloses[hn], htfUp[hn], htfDown[hn], this.params.lenRSI);
                        const htf30 = this._predictRsiPrice(this.params.osLevel, htfCloses[hn], htfUp[hn], htfDown[hn], this.params.lenRSI);
                        levels.push({ label: `${label} RSI${this.params.obLevel}`, price: htf70, color: tc.htfObColor, lineStyle: 2, lineWidth: 1 });
                        levels.push({ label: `${label} RSI${this.params.osLevel}`, price: htf30, color: tc.htfOsColor, lineStyle: 2, lineWidth: 1 });
                    }
                }
            };
            checkHTFPredictor(5, this.params.showM5Rsi, 'M5');
            checkHTFPredictor(15, this.params.showM15Rsi, 'M15');
            checkHTFPredictor(60, this.params.showH1Rsi, 'H1');
            checkHTFPredictor(240, this.params.showH4Rsi, 'H4');
        }
        this.computedLevels = levels;
    }
    calculate(bars) {
        const minWarmup = Math.max(this.params.lenEMA, this.params.lenRSI, 35);
        if (!bars || bars.length < minWarmup) {
            this.cachedData = [];
            this.cachedUpperData = [];
            this.cachedLowerData = [];
            this.cachedMarkers = [];
            this.computedLevels = [];
            this.computedStructures = [];
            this.computedOBs = [];
            this.computedFVGs = [];
            this.computedLiquidity = [];
            this.computedSwings = [];
            this.lastBar = null;
            this._rawBars = [];
            return [];
        }
        this._rawBars = bars;
        const n = bars.length;
        this.lastBar = bars[n - 1];
        const closes = bars.map((b) => b.close);
        const tc = this._getThemeColors();
        // ------------------------------------------------------------------------
        // 1. Wilson RPC & RSI
        // ------------------------------------------------------------------------
        const { rsi, rmaUp, rmaDown } = this._calculateRSI(closes, this.params.lenRSI);
        this._rmaUp = rmaUp;
        this._rmaDown = rmaDown;
        const baseEmaValues = new Array(n).fill(0);
        const upperBandValues = new Array(n).fill(0);
        const lowerBandValues = new Array(n).fill(0);
        const kEma = 2 / (this.params.lenEMA + 1);
        let initEmaSum = 0;
        for (let i = 0; i < n; i++) {
            if (i < this.params.lenEMA) {
                initEmaSum += closes[i];
                baseEmaValues[i] = initEmaSum / (i + 1);
            }
            else {
                baseEmaValues[i] = closes[i] * kEma + baseEmaValues[i - 1] * (1 - kEma);
            }
            if (i >= this.params.lenEMA - 1) {
                let sumC = 0;
                for (let j = i - this.params.lenEMA + 1; j <= i; j++)
                    sumC += closes[j];
                const mean = sumC / this.params.lenEMA;
                let sumSq = 0;
                for (let j = i - this.params.lenEMA + 1; j <= i; j++)
                    sumSq += Math.pow(closes[j] - mean, 2);
                const stdev = Math.sqrt(sumSq / Math.max(this.params.lenEMA - 1, 1));
                const basis = stdev * this.params.widthMult;
                const rsiBias = (rsi[i] - 50) / 50;
                upperBandValues[i] = baseEmaValues[i] + basis * (1 + rsiBias);
                lowerBandValues[i] = baseEmaValues[i] - basis * (1 - rsiBias);
            }
        }
        // ------------------------------------------------------------------------
        // 2. High-Precision SMC Engine (Swings, CHoCH, BOS, Order Blocks, Liquidity, FVG)
        // ------------------------------------------------------------------------
        const computedStructures = [];
        const computedOBs = [];
        const computedFVGs = [];
        const computedLiquidity = [];
        const computedSwings = [];
        const pivotLen = Math.max(2, Number(this.params.pivotLen) || 5);
        if (Number(this.params.showSmc) === 1) {
            // Step A: Detect Swing Highs and Lows
            const swingHighs = [];
            const swingLows = [];
            for (let i = pivotLen; i < n - pivotLen; i++) {
                let isH = true;
                let isL = true;
                const curH = bars[i].high;
                const curL = bars[i].low;
                for (let k = 1; k <= pivotLen; k++) {
                    if (bars[i - k].high >= curH || bars[i + k].high >= curH)
                        isH = false;
                    if (bars[i - k].low <= curL || bars[i + k].low <= curL)
                        isL = false;
                    if (!isH && !isL)
                        break;
                }
                if (isH) {
                    swingHighs.push({ idx: i, time: bars[i].time, price: curH, isHigh: true });
                }
                if (isL) {
                    swingLows.push({ idx: i, time: bars[i].time, price: curL, isHigh: false });
                }
            }
            // Step B: Classify Swings (HH, HL, LH, LL) and Equal Highs / Lows (EQH / EQL)
            const allSwings = [...swingHighs, ...swingLows].sort((a, b) => a.idx - b.idx);
            let prevHigh = null;
            let prevLow = null;
            for (const sw of allSwings) {
                if (sw.isHigh) {
                    if (prevHigh) {
                        const diffPct = Math.abs(sw.price - prevHigh.price) / prevHigh.price;
                        if (diffPct <= 0.0012) {
                            computedLiquidity.push({
                                type: 'EQH',
                                price: (sw.price + prevHigh.price) / 2,
                                idx1: prevHigh.idx,
                                time1: prevHigh.time,
                                idx2: sw.idx,
                                time2: sw.time,
                            });
                        }
                        if (sw.price > prevHigh.price) {
                            sw.label = 'HH';
                        }
                        else {
                            sw.label = 'LH';
                        }
                    }
                    else {
                        sw.label = 'H';
                    }
                    prevHigh = sw;
                    computedSwings.push(sw);
                }
                else {
                    if (prevLow) {
                        const diffPct = Math.abs(sw.price - prevLow.price) / prevLow.price;
                        if (diffPct <= 0.0012) {
                            computedLiquidity.push({
                                type: 'EQL',
                                price: (sw.price + prevLow.price) / 2,
                                idx1: prevLow.idx,
                                time1: prevLow.time,
                                idx2: sw.idx,
                                time2: sw.time,
                            });
                        }
                        if (sw.price < prevLow.price) {
                            sw.label = 'LL';
                        }
                        else {
                            sw.label = 'HL';
                        }
                    }
                    else {
                        sw.label = 'L';
                    }
                    prevLow = sw;
                    computedSwings.push(sw);
                }
            }
            // Step C: Trend Tracking, BOS vs CHoCH Breakout Lines & Order Block Generation
            let currentTrend = null; // 'bull' | 'bear'
            let activeHighLevel = null;
            let activeLowLevel = null;
            let nextSwingIdx = 0;
            const rawOBs = [];
            for (let i = 0; i < n; i++) {
                // Confirm swing when current bar >= swing.idx + pivotLen
                while (nextSwingIdx < allSwings.length && allSwings[nextSwingIdx].idx + pivotLen <= i) {
                    const sw = allSwings[nextSwingIdx];
                    if (sw.isHigh) {
                        activeHighLevel = sw;
                    }
                    else {
                        activeLowLevel = sw;
                    }
                    nextSwingIdx++;
                }
                // Bullish Breakout (Price breaks activeHighLevel)
                if (activeHighLevel && bars[i].close > activeHighLevel.price && bars[i - 1]?.close <= activeHighLevel.price) {
                    const isChoch = currentTrend === 'bear';
                    const type = isChoch ? 'CHoCH' : 'BOS';
                    currentTrend = 'bull';
                    computedStructures.push({
                        type,
                        isBull: true,
                        price: activeHighLevel.price,
                        pivotIdx: activeHighLevel.idx,
                        pivotTime: activeHighLevel.time,
                        breakIdx: i,
                        breakTime: bars[i].time,
                    });
                    // Order Block: Last down candle before the breakout impulse
                    let obIdx = -1;
                    for (let j = i - 1; j >= Math.max(0, activeHighLevel.idx - 2); j--) {
                        if (bars[j].close < bars[j].open) {
                            obIdx = j;
                            break;
                        }
                    }
                    if (obIdx !== -1) {
                        rawOBs.push({
                            isBull: true,
                            top: bars[obIdx].high,
                            bottom: bars[obIdx].low,
                            startIdx: obIdx,
                            startTime: bars[obIdx].time,
                            createdIdx: i,
                        });
                    }
                    activeHighLevel = null; // Breakout completed
                }
                // Bearish Breakout (Price breaks activeLowLevel)
                if (activeLowLevel && bars[i].close < activeLowLevel.price && bars[i - 1]?.close >= activeLowLevel.price) {
                    const isChoch = currentTrend === 'bull';
                    const type = isChoch ? 'CHoCH' : 'BOS';
                    currentTrend = 'bear';
                    computedStructures.push({
                        type,
                        isBull: false,
                        price: activeLowLevel.price,
                        pivotIdx: activeLowLevel.idx,
                        pivotTime: activeLowLevel.time,
                        breakIdx: i,
                        breakTime: bars[i].time,
                    });
                    // Order Block: Last up candle before the breakdown impulse
                    let obIdx = -1;
                    for (let j = i - 1; j >= Math.max(0, activeLowLevel.idx - 2); j--) {
                        if (bars[j].close > bars[j].open) {
                            obIdx = j;
                            break;
                        }
                    }
                    if (obIdx !== -1) {
                        rawOBs.push({
                            isBull: false,
                            top: bars[obIdx].high,
                            bottom: bars[obIdx].low,
                            startIdx: obIdx,
                            startTime: bars[obIdx].time,
                            createdIdx: i,
                        });
                    }
                    activeLowLevel = null; // Breakout completed
                }
            }
            // Step D: Order Block Mitigation Tracking
            for (const ob of rawOBs) {
                let mitigated = false;
                let endIdx = n - 1;
                let endTime = bars[n - 1].time;
                for (let j = ob.createdIdx + 1; j < n; j++) {
                    const b = bars[j];
                    if (ob.isBull) {
                        if (b.close < ob.bottom) {
                            mitigated = true;
                            endIdx = j;
                            endTime = b.time;
                            break;
                        }
                    }
                    else {
                        if (b.close > ob.top) {
                            mitigated = true;
                            endIdx = j;
                            endTime = b.time;
                            break;
                        }
                    }
                }
                ob.mitigated = mitigated;
                ob.endIdx = endIdx;
                ob.endTime = endTime;
            }
            const maxOB = Math.max(1, Math.min(15, Number(this.params.maxActiveOb) || 5));
            const unmitigatedOBs = rawOBs.filter((o) => !o.mitigated).slice(-maxOB);
            const recentMitigated = rawOBs.filter((o) => o.mitigated).slice(-2);
            computedOBs.push(...recentMitigated, ...unmitigatedOBs);
            // Step E: Fair Value Gaps (FVG)
            if (Number(this.params.showFvg) === 1) {
                const rawFVGs = [];
                for (let i = 2; i < n; i++) {
                    if (bars[i].low > bars[i - 2].high && bars[i - 1].close > bars[i - 1].open) {
                        rawFVGs.push({
                            isBull: true,
                            top: bars[i].low,
                            bottom: bars[i - 2].high,
                            startIdx: i - 1,
                            startTime: bars[i - 1].time,
                            createdIdx: i,
                        });
                    }
                    if (bars[i].high < bars[i - 2].low && bars[i - 1].close < bars[i - 1].open) {
                        rawFVGs.push({
                            isBull: false,
                            top: bars[i - 2].low,
                            bottom: bars[i].high,
                            startIdx: i - 1,
                            startTime: bars[i - 1].time,
                            createdIdx: i,
                        });
                    }
                }
                for (const fvg of rawFVGs) {
                    let mitigated = false;
                    let endIdx = n - 1;
                    let endTime = bars[n - 1].time;
                    for (let j = fvg.createdIdx + 1; j < n; j++) {
                        const b = bars[j];
                        if (fvg.isBull) {
                            if (b.low <= fvg.bottom) {
                                mitigated = true;
                                endIdx = j;
                                endTime = b.time;
                                break;
                            }
                        }
                        else {
                            if (b.high >= fvg.top) {
                                mitigated = true;
                                endIdx = j;
                                endTime = b.time;
                                break;
                            }
                        }
                    }
                    fvg.mitigated = mitigated;
                    fvg.endIdx = endIdx;
                    fvg.endTime = endTime;
                }
                const activeFVGs = rawFVGs.filter((f) => !f.mitigated).slice(-5);
                computedFVGs.push(...activeFVGs);
            }
        }
        this.computedStructures = computedStructures;
        this.computedOBs = computedOBs;
        this.computedFVGs = computedFVGs;
        this.computedLiquidity = computedLiquidity;
        this.computedSwings = computedSwings;
        // ------------------------------------------------------------------------
        // 3. RSI Divergence Markers (Discrete subtle arrows, NO blocking square glyphs)
        // ------------------------------------------------------------------------
        const divMarkers = [];
        const lbL = this.params.lbLeft;
        const lbR = this.params.lbRight;
        if (Number(this.params.showDivRsi) === 1) {
            let prevPlLow = null;
            let prevPlRsi = null;
            let prevPhHigh = null;
            let prevPhRsi = null;
            for (let i = lbL + lbR; i < n; i++) {
                const pivotIdx = i - lbR;
                const pivotRsi = rsi[pivotIdx];
                let isPh = true;
                let isPl = true;
                for (let k = pivotIdx - lbL; k <= pivotIdx + lbR; k++) {
                    if (k !== pivotIdx) {
                        if (rsi[k] >= pivotRsi)
                            isPh = false;
                        if (rsi[k] <= pivotRsi)
                            isPl = false;
                    }
                }
                const pivotTime = bars[pivotIdx].time;
                const pivotLow = bars[pivotIdx].low;
                const pivotHigh = bars[pivotIdx].high;
                if (isPl) {
                    if (prevPlLow !== null && prevPlRsi !== null) {
                        if (pivotLow < prevPlLow && pivotRsi > prevPlRsi) {
                            divMarkers.push({
                                time: pivotTime,
                                position: 'belowBar',
                                color: tc.bullMarker,
                                shape: 'arrowUp',
                                text: 'R-Div',
                            });
                        }
                        else if (pivotLow > prevPlLow && pivotRsi < prevPlRsi) {
                            divMarkers.push({
                                time: pivotTime,
                                position: 'belowBar',
                                color: tc.bullMarker,
                                shape: 'arrowUp',
                                text: 'H-Div',
                            });
                        }
                    }
                    prevPlLow = pivotLow;
                    prevPlRsi = pivotRsi;
                }
                if (isPh) {
                    if (prevPhHigh !== null && prevPhRsi !== null) {
                        if (pivotHigh > prevPhHigh && pivotRsi < prevPhRsi) {
                            divMarkers.push({
                                time: pivotTime,
                                position: 'aboveBar',
                                color: tc.bearMarker,
                                shape: 'arrowDown',
                                text: 'R-Div',
                            });
                        }
                        else if (pivotHigh < prevPhHigh && pivotRsi > prevPhRsi) {
                            divMarkers.push({
                                time: pivotTime,
                                position: 'aboveBar',
                                color: tc.bearMarker,
                                shape: 'arrowDown',
                                text: 'H-Div',
                            });
                        }
                    }
                    prevPhHigh = pivotHigh;
                    prevPhRsi = pivotRsi;
                }
            }
        }
        // ------------------------------------------------------------------------
        // 4. Timezone-Adjusted HTF Buckets for Precision Session Levels
        // ------------------------------------------------------------------------
        const daysMap = new Map();
        const weeksMap = new Map();
        const monthsMap = new Map();
        for (let i = 0; i < n; i++) {
            const sec = this._getBarTimeSec(bars[i].time);
            const d = this._getAdjustedDate(sec);
            const dayKey = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
            if (!daysMap.has(dayKey)) {
                daysMap.set(dayKey, { open: bars[i].open, high: bars[i].high, low: bars[i].low, close: bars[i].close });
            }
            else {
                const item = daysMap.get(dayKey);
                item.high = Math.max(item.high, bars[i].high);
                item.low = Math.min(item.low, bars[i].low);
                item.close = bars[i].close;
            }
            const dayNum = d.getUTCDay() || 7;
            const mondaySec = sec - (dayNum - 1) * 86400;
            const monDate = this._getAdjustedDate(mondaySec);
            const weekKey = `${monDate.getUTCFullYear()}-W${String(monDate.getUTCMonth() + 1).padStart(2, '0')}-${String(monDate.getUTCDate()).padStart(2, '0')}`;
            if (!weeksMap.has(weekKey)) {
                weeksMap.set(weekKey, { high: bars[i].high, low: bars[i].low, close: bars[i].close });
            }
            else {
                const w = weeksMap.get(weekKey);
                w.high = Math.max(w.high, bars[i].high);
                w.low = Math.min(w.low, bars[i].low);
                w.close = bars[i].close;
            }
            const monthKey = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
            if (!monthsMap.has(monthKey)) {
                monthsMap.set(monthKey, { high: bars[i].high, low: bars[i].low, close: bars[i].close });
            }
            else {
                const m = monthsMap.get(monthKey);
                m.high = Math.max(m.high, bars[i].high);
                m.low = Math.min(m.low, bars[i].low);
                m.close = bars[i].close;
            }
        }
        const days = Array.from(daysMap.values());
        const weeks = Array.from(weeksMap.values());
        const months = Array.from(monthsMap.values());
        const today = days[days.length - 1];
        const yesterday = days.length >= 2 ? days[days.length - 2] : today;
        const prevWeek = weeks.length >= 2 ? weeks[weeks.length - 2] : weeks[0];
        const prevMonth = months.length >= 2 ? months[months.length - 2] : months[0];
        let sumRange = 0;
        let cnt = 0;
        for (let i = days.length - 2; i >= 0 && cnt < 14; i--) {
            sumRange += days[i].high - days[i].low;
            cnt++;
        }
        const adrVal = cnt > 0 ? sumRange / cnt : today.high - today.low;
        this._staticLevels = {
            todayOpen: today.open,
            todayHigh: today.high,
            todayLow: today.low,
            yh: days.length >= 2 ? yesterday.high : undefined,
            yl: days.length >= 2 ? yesterday.low : undefined,
            dpoc: (yesterday.high + yesterday.low + yesterday.close) / 3.0,
            wpoc: (prevWeek.high + prevWeek.low + prevWeek.close) / 3.0,
            mpoc: (prevMonth.high + prevMonth.low + prevMonth.close) / 3.0,
            adrVal: adrVal,
        };
        this._refreshRealtimeLevels();
        // ------------------------------------------------------------------------
        // 5. Prepare Wilson Series Data
        // ------------------------------------------------------------------------
        const baseData = [];
        const upperData = [];
        const lowerData = [];
        for (let i = minWarmup; i < n; i++) {
            const time = bars[i].time;
            if (this.params.showWilson === 1) {
                if (!isNaN(baseEmaValues[i]) && isFinite(baseEmaValues[i])) {
                    baseData.push({ time, value: Number(baseEmaValues[i].toFixed(2)) });
                }
                if (!isNaN(upperBandValues[i]) && isFinite(upperBandValues[i])) {
                    upperData.push({ time, value: Number(upperBandValues[i].toFixed(2)) });
                }
                if (!isNaN(lowerBandValues[i]) && isFinite(lowerBandValues[i])) {
                    lowerData.push({ time, value: Number(lowerBandValues[i].toFixed(2)) });
                }
            }
        }
        this.cachedData = baseData;
        this.cachedUpperData = upperData;
        this.cachedLowerData = lowerData;
        this.cachedMarkers = divMarkers;
        return baseData;
    }
    _getActivePriceScaleId() {
        if (!this.engine)
            return 'right';
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries && typeof mainSeries.priceScale === 'function') {
            try {
                const id = mainSeries.priceScale().id();
                if (id)
                    return id;
            }
            catch (e) { }
        }
        return typeof this.engine.getPriceScalePosition === 'function'
            ? this.engine.getPriceScalePosition()
            : 'right';
    }
    _syncPriceScale() {
        const activeScale = this._getActivePriceScaleId();
        this._lastKnownScale = activeScale;
        if (this.baseSeries)
            this.baseSeries.applyOptions({ priceScaleId: activeScale });
        if (this.upperSeries)
            this.upperSeries.applyOptions({ priceScaleId: activeScale });
        if (this.lowerSeries)
            this.lowerSeries.applyOptions({ priceScaleId: activeScale });
    }
    _ensureAttached(targetSeries) {
        const s = targetSeries || (this.engine ? this.engine.getMainSeries() : null);
        if (!s || typeof s.attachPrimitive !== 'function')
            return;
        if (this._primitive._series !== s) {
            try {
                s.attachPrimitive(this._primitive);
            }
            catch (e) { }
        }
    }
    _onPrimitiveDetached() {
        if (this._isDestroyed)
            return;
        if (this._reattachTimer)
            clearTimeout(this._reattachTimer);
        this._reattachTimer = setTimeout(() => {
            if (this._isDestroyed || !this.engine)
                return;
            this._syncPriceScale();
            const mainSeries = this.engine.getMainSeries();
            if (mainSeries) {
                this._ensureAttached(mainSeries);
                if (this.isVisible !== false && Number(this.params.showDivRsi) === 1) {
                    this._applyMarkers();
                }
                this._primitive.requestUpdate();
            }
        }, 40);
    }
    _checkScaleAndAttach() {
        if (this._isDestroyed || !this.engine)
            return;
        const mainSeries = this.engine.getMainSeries();
        if (!mainSeries)
            return;
        const currentScale = this._getActivePriceScaleId();
        let needUpdate = false;
        if (currentScale !== this._lastKnownScale) {
            this._syncPriceScale();
            needUpdate = true;
        }
        if (!this._primitive._series || this._primitive._series !== mainSeries) {
            this._ensureAttached(mainSeries);
            if (this.isVisible !== false && Number(this.params.showDivRsi) === 1) {
                this._applyMarkers();
            }
            needUpdate = true;
        }
        if (needUpdate) {
            this._primitive.requestUpdate();
        }
    }
    render(engine, onSettings, onClose) {
        this.engine = engine;
        this._isDestroyed = false;
        const scalePos = this._getActivePriceScaleId();
        this._lastKnownScale = scalePos;
        const tc = this._getThemeColors();
        if (engine.chart && typeof engine.chart.timeScale === 'function') {
            try {
                const ts = engine.chart.timeScale();
                ts.applyOptions({ rightOffset: 16 });
                if (typeof ts.subscribeVisibleLogicalRangeChange === 'function') {
                    this._rangeHandler = () => {
                        this._checkScaleAndAttach();
                    };
                    ts.subscribeVisibleLogicalRangeChange(this._rangeHandler);
                }
            }
            catch (e) { }
            if (typeof engine.chart.subscribeCrosshairMove === 'function') {
                this._crosshairHandler = () => {
                    this._checkScaleAndAttach();
                };
                engine.chart.subscribeCrosshairMove(this._crosshairHandler);
            }
        }
        const showWilson = this.isVisible !== false && this.params.showWilson === 1;
        this.baseSeries = engine.chart.addLineSeries({
            color: tc.wilsonBase,
            lineWidth: this.params.lineWidth,
            lineStyle: 0,
            priceScaleId: scalePos,
            title: '',
            lastValueVisible: false,
            priceLineVisible: false,
            visible: showWilson,
        });
        this.upperSeries = engine.chart.addLineSeries({
            color: tc.wilsonUpper,
            lineWidth: 1,
            lineStyle: 1,
            priceScaleId: scalePos,
            title: '',
            lastValueVisible: false,
            priceLineVisible: false,
            visible: showWilson,
        });
        this.lowerSeries = engine.chart.addLineSeries({
            color: tc.wilsonLower,
            lineWidth: 1,
            lineStyle: 1,
            priceScaleId: scalePos,
            title: '',
            lastValueVisible: false,
            priceLineVisible: false,
            visible: showWilson,
        });
        const mainSeries = engine.getMainSeries();
        if (mainSeries) {
            this._ensureAttached(mainSeries);
        }
        if (this._watchdogTimer)
            clearInterval(this._watchdogTimer);
        this._watchdogTimer = setInterval(() => {
            this._checkScaleAndAttach();
        }, 300);
        if (this._rawBars.length > 0 || this.cachedData.length > 0 || this.cachedMarkers.length > 0) {
            this.baseSeries.setData(this.cachedData);
            this.upperSeries.setData(this.cachedUpperData);
            this.lowerSeries.setData(this.cachedLowerData);
            if (this.isVisible !== false && Number(this.params.showDivRsi) === 1) {
                this._applyMarkers();
            }
            else {
                this._clearMarkers();
            }
            this._primitive.requestUpdate();
        }
    }
    update(bar) {
        if (!bar)
            return;
        if (this._rawBars.length > 0) {
            const last = this._rawBars[this._rawBars.length - 1];
            if (last.time === bar.time) {
                this._rawBars[this._rawBars.length - 1] = bar;
            }
            else {
                this._rawBars.push(bar);
            }
            this.lastBar = bar;
            this._refreshRealtimeLevels();
            this._primitive.requestUpdate();
        }
    }
    setData(data) {
        this._syncPriceScale();
        this._ensureAttached();
        if (this.baseSeries && Array.isArray(data)) {
            this.baseSeries.setData(data);
            if (this.upperSeries)
                this.upperSeries.setData(this.cachedUpperData);
            if (this.lowerSeries)
                this.lowerSeries.setData(this.cachedLowerData);
            if (this.isVisible !== false && Number(this.params.showDivRsi) === 1) {
                this._applyMarkers();
            }
            else {
                this._clearMarkers();
            }
            this._primitive.requestUpdate();
        }
    }
    updateParams(newParams, engine) {
        this.params = { ...this.params, ...newParams };
        this._syncPriceScale();
        this._ensureAttached();
        const tc = this._getThemeColors();
        const showWilson = this.isVisible !== false && this.params.showWilson === 1;
        if (this.baseSeries) {
            this.baseSeries.applyOptions({
                color: tc.wilsonBase,
                lineWidth: this.params.lineWidth,
                title: '',
                lastValueVisible: false,
                priceLineVisible: false,
                visible: showWilson,
            });
        }
        if (this.upperSeries) {
            this.upperSeries.applyOptions({
                color: tc.wilsonUpper,
                title: '',
                lastValueVisible: false,
                priceLineVisible: false,
                visible: showWilson,
            });
        }
        if (this.lowerSeries) {
            this.lowerSeries.applyOptions({
                color: tc.wilsonLower,
                title: '',
                lastValueVisible: false,
                priceLineVisible: false,
                visible: showWilson,
            });
        }
        const bars = (engine && engine.allBars && engine.allBars.length > 0) ? engine.allBars : this._rawBars;
        if (bars.length > 0) {
            const newData = this.calculate(bars);
            this.setData(newData);
        }
        if (this.isVisible !== false && Number(this.params.showDivRsi) === 1) {
            this._applyMarkers();
        }
        else {
            this._clearMarkers();
        }
        this._primitive.requestUpdate();
    }
    setVisible(visible) {
        this.isVisible = visible !== false;
        const showWilson = this.isVisible && this.params.showWilson === 1;
        if (this.baseSeries && typeof this.baseSeries.applyOptions === 'function') {
            this.baseSeries.applyOptions({ visible: showWilson });
        }
        if (this.upperSeries && typeof this.upperSeries.applyOptions === 'function') {
            this.upperSeries.applyOptions({ visible: showWilson });
        }
        if (this.lowerSeries && typeof this.lowerSeries.applyOptions === 'function') {
            this.lowerSeries.applyOptions({ visible: showWilson });
        }
        if (!this.isVisible) {
            this._clearMarkers();
        }
        else if (Number(this.params.showDivRsi) === 1) {
            this._applyMarkers();
        }
        if (this._primitive && typeof this._primitive.requestUpdate === 'function') {
            this._primitive.requestUpdate();
        }
    }
    destroy(engine) {
        this._isDestroyed = true;
        this._clearMarkers();
        if (this._reattachTimer)
            clearTimeout(this._reattachTimer);
        if (this._watchdogTimer)
            clearInterval(this._watchdogTimer);
        if (engine.chart && typeof engine.chart.timeScale === 'function' && this._rangeHandler) {
            try {
                engine.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this._rangeHandler);
            }
            catch (e) { }
        }
        if (engine.chart && this._crosshairHandler) {
            try {
                engine.chart.unsubscribeCrosshairMove(this._crosshairHandler);
            }
            catch (e) { }
        }
        const mainSeries = engine.getMainSeries();
        if (mainSeries && typeof mainSeries.detachPrimitive === 'function') {
            try {
                mainSeries.detachPrimitive(this._primitive);
            }
            catch (e) { }
        }
        if (this.baseSeries)
            engine.chart.removeSeries(this.baseSeries);
        if (this.upperSeries)
            engine.chart.removeSeries(this.upperSeries);
        if (this.lowerSeries)
            engine.chart.removeSeries(this.lowerSeries);
        this.cachedData = [];
        this.cachedUpperData = [];
        this.cachedLowerData = [];
        this.cachedMarkers = [];
        this.computedLevels = [];
        this.computedStructures = [];
        this.computedOBs = [];
        this.computedFVGs = [];
        this.computedLiquidity = [];
        this.computedSwings = [];
        this._rawBars = [];
        this.baseSeries = null;
        this.upperSeries = null;
        this.lowerSeries = null;
        this.engine = null;
        this.lastBar = null;
    }
    _applyMarkers() {
        if (!this.engine || this.isVisible === false)
            return;
        if (typeof this.engine.setIndicatorMarkers === 'function') {
            this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries) {
            try {
                mainSeries.setMarkers(this.cachedMarkers || []);
            }
            catch (e) { }
        }
    }
    _clearMarkers() {
        if (!this.engine)
            return;
        if (typeof this.engine.clearIndicatorMarkers === 'function') {
            this.engine.clearIndicatorMarkers(this.id);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries) {
            try {
                mainSeries.setMarkers([]);
            }
            catch (e) { }
        }
    }
}
export default SmcWilsonRsiIndicator;

