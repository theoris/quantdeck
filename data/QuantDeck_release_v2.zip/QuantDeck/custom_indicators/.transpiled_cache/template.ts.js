// @ts-sha256: d4e7d2a146b63d5fb618c04817a838b27ca2575be2a40371b97410ac5f2d6ccc
/**
 * QuantDeck Custom Indicator TypeScript Template
 * You can save this file as `.ts` or `.js` in `F:\GIT\App28_bot\chart\custom_indicators\`
 */
const template = {
    name: "MyCustomIndicator",
    pane: "main", // Use "main" for price overlays, or "sub" for lower oscillator pane
    description: "Custom mathematical indicator algorithm",
    params: {
        period: 20,
        color: "#00bcd4",
        lineWidth: 2
    },
    paramDefs: [
        { key: "period", label: "Period", type: "number", default: 20, min: 1, max: 200 },
        { key: "color", label: "Line Color", type: "color", default: "#00bcd4" },
        {
            key: "lineWidth",
            label: "Line Width",
            type: "select",
            default: 2,
            options: [
                { label: "1px", value: 1 },
                { label: "2px", value: 2 },
                { label: "3px", value: 3 }
            ]
        }
    ],
    calculate(bars, params) {
        const period = params.period || 20;
        if (!bars || bars.length < period)
            return [];
        const result = [];
        for (let i = period - 1; i < bars.length; i++) {
            let sum = 0;
            for (let j = i - period + 1; j <= i; j++) {
                sum += bars[j].close;
            }
            result.push({
                time: bars[i].time,
                value: sum / period
            });
        }
        return result;
    }
};
export default template;

