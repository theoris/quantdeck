// @ts-sha256: 97178276c77abce69e0683f0dc0375c38289554363298964ae22cfa12d8ec820
/**
 * QuantDeck Custom Indicator: 3-Layer Smart Money Concepts (H4 -> H1 -> M15) + Precision Right Levels & RSI Divergence
 * File: SMC_3Layer_Levels_RSI.ts
 * Placement: custom_indicators/
 *
 * Integrated Features:
 * 1. 3-Layer SMC Decision Pipeline (H4 Bias & P/D, H1 OB/FVG Zones, M15 Sweep + CHoCH Triggers, 7-State Engine)
 * 2. Precision Right Levels (H, L, YH, YL, VWAP ±2σ, DPOC/WPOC/MPOC, O/ADR_H/ADR_L, RSI 70/30 Target)
 * 3. RSI Regular & Hidden Divergence Markers (R-Div, H-Div) with configurable lookback
 * 4. Full Show/Hide UI Parameters for Levels & RSI Divergence
 * 5. Asset Precision Auto-Detection (Digits) & Light/Dark Theme Support with High-Contrast Canvas Overlay
 * 6. Zero Runtime Imports, Strict Blob-URL Safe, Centralized Marker Registry Rule
 */
// ============================================================================
// 1. MATH, SESSION, THEME & PRECISION UTILS
// ============================================================================
class MathUtils {
    static computeATR(bars, period = 14) {
        const n = bars.length;
        if (n === 0)
            return [];
        const tr = new Array(n).fill(0);
        const atr = new Array(n).fill(0);
        for (let i = 0; i < n; i++) {
            const high = bars[i].high;
            const low = bars[i].low;
            if (i === 0) {
                tr[i] = Math.max(high - low, 1e-8);
            }
            else {
                const prevClose = bars[i - 1].close;
                tr[i] = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose), 1e-8);
            }
        }
        let sum = 0;
        for (let i = 0; i < n; i++) {
            if (i < period) {
                sum += tr[i];
                atr[i] = sum / (i + 1);
            }
            else {
                atr[i] = (atr[i - 1] * (period - 1) + tr[i]) / period;
            }
        }
        return atr;
    }
    static resampleBars(bars, periodSeconds) {
        if (!bars || bars.length === 0)
            return [];
        const result = [];
        let currentBucket = null;
        for (let i = 0; i < bars.length; i++) {
            const b = bars[i];
            const bucketTime = Math.floor(b.time / periodSeconds) * periodSeconds;
            if (!currentBucket || currentBucket.time !== bucketTime) {
                if (currentBucket)
                    result.push(currentBucket);
                currentBucket = {
                    time: bucketTime,
                    open: b.open,
                    high: b.high,
                    low: b.low,
                    close: b.close,
                    volume: b.volume || 0,
                };
            }
            else {
                if (b.high > currentBucket.high)
                    currentBucket.high = b.high;
                if (b.low < currentBucket.low)
                    currentBucket.low = b.low;
                currentBucket.close = b.close;
                currentBucket.volume = (currentBucket.volume || 0) + (b.volume || 0);
            }
        }
        if (currentBucket)
            result.push(currentBucket);
        return result;
    }
    static hexToRgba(hex, alpha) {
        const cleaned = (hex || '#2962ff').replace('#', '').trim();
        let r = 41, g = 98, b = 255;
        if (cleaned.length === 3) {
            r = parseInt(cleaned[0] + cleaned[0], 16);
            g = parseInt(cleaned[1] + cleaned[1], 16);
            b = parseInt(cleaned[2] + cleaned[2], 16);
        }
        else if (cleaned.length >= 6) {
            r = parseInt(cleaned.substring(0, 2), 16);
            g = parseInt(cleaned.substring(2, 4), 16);
            b = parseInt(cleaned.substring(4, 6), 16);
        }
        const clampedAlpha = Math.max(0, Math.min(1, isFinite(alpha) ? alpha : 0.2));
        return `rgba(${isNaN(r) ? 41 : r}, ${isNaN(g) ? 98 : g}, ${isNaN(b) ? 255 : b}, ${clampedAlpha.toFixed(3)})`;
    }
    static getBarTimeSec(time) {
        if (typeof time === 'number') {
            return time > 1e11 ? Math.floor(time / 1000) : time;
        }
        return Math.floor(new Date(time).getTime() / 1000);
    }
    static getAdjustedDate(sec, sessionMode = 'forex_gold', customOffsetHours = 2) {
        let offsetSec = 0;
        if (sessionMode === 'forex_gold') {
            offsetSec = 2 * 3600;
        }
        else if (sessionMode === 'bkk') {
            offsetSec = 7 * 3600;
        }
        else if (sessionMode === 'utc') {
            offsetSec = 0;
        }
        else {
            offsetSec = (Number(customOffsetHours) || 0) * 3600;
        }
        return new Date((sec + offsetSec) * 1000);
    }
    static calculateRSI(closes, length = 14) {
        const n = closes.length;
        const rsi = new Array(n).fill(50);
        const rmaUp = new Array(n).fill(0);
        const rmaDown = new Array(n).fill(0);
        if (n < length + 1)
            return { rsi, rmaUp, rmaDown };
        let sumUp = 0;
        let sumDown = 0;
        for (let i = 1; i <= length; i++) {
            const diff = closes[i] - closes[i - 1];
            if (diff > 0)
                sumUp += diff;
            else
                sumDown += -diff;
        }
        rmaUp[length] = sumUp / length;
        rmaDown[length] = sumDown / length;
        const rs = rmaDown[length] === 0 ? 100 : rmaUp[length] / rmaDown[length];
        rsi[length] = 100 - 100 / (1 + rs);
        for (let i = length + 1; i < n; i++) {
            const diff = closes[i] - closes[i - 1];
            const up = diff > 0 ? diff : 0;
            const down = diff < 0 ? -diff : 0;
            rmaUp[i] = (rmaUp[i - 1] * (length - 1) + up) / length;
            rmaDown[i] = (rmaDown[i - 1] * (length - 1) + down) / length;
            if (rmaDown[i] === 0) {
                rsi[i] = 100;
            }
            else {
                const curRs = rmaUp[i] / rmaDown[i];
                rsi[i] = 100 - 100 / (1 + curRs);
            }
        }
        return { rsi, rmaUp, rmaDown };
    }
    static predictRsiPrice(target, close, prevUp, prevDown, length) {
        if (prevDown <= 0 && prevUp <= 0)
            return close;
        const rsTarget = target / (100.0 - target);
        const nextUp = rsTarget * prevDown * (length - 1) - prevUp * (length - 1);
        const nextDown = (prevUp * (length - 1)) / rsTarget - prevDown * (length - 1);
        return target >= 50 ? close + nextUp : close - nextDown;
    }
    static detectPricePrecision(bars, symbol = '', manualDigits = -1, engine) {
        if (manualDigits !== undefined && manualDigits !== null && Number(manualDigits) >= 0) {
            return Math.min(8, Math.max(0, Math.floor(Number(manualDigits))));
        }
        if (engine) {
            if (typeof engine.getPricePrecision === 'function') {
                const p = engine.getPricePrecision();
                if (typeof p === 'number' && isFinite(p) && p >= 0 && p <= 8)
                    return p;
            }
            if (typeof engine.decimals === 'number' && engine.decimals >= 0) {
                return engine.decimals;
            }
            if (typeof engine.getMainSeries === 'function') {
                try {
                    const mainSeries = engine.getMainSeries();
                    const opts = mainSeries && typeof mainSeries.options === 'function' ? mainSeries.options() : null;
                    if (opts && opts.priceFormat) {
                        if (typeof opts.priceFormat.precision === 'number' && opts.priceFormat.precision >= 0) {
                            return opts.priceFormat.precision;
                        }
                        if (typeof opts.priceFormat.minMove === 'number' && opts.priceFormat.minMove > 0) {
                            const mm = opts.priceFormat.minMove;
                            const digitsFromMinMove = Math.max(0, Math.round(-Math.log10(mm)));
                            if (isFinite(digitsFromMinMove) && digitsFromMinMove <= 8) {
                                return digitsFromMinMove;
                            }
                        }
                    }
                }
                catch (_e) { }
            }
        }
        const sym = (symbol || '').toUpperCase();
        if (sym) {
            if (sym.includes('JPY')) {
                return 3;
            }
            else if (/^(EUR|GBP|AUD|NZD|USD|CAD|CHF)(EUR|GBP|AUD|NZD|USD|CAD|CHF)$/.test(sym.replace(/[^A-Z]/g, '').substring(0, 6))) {
                return 5;
            }
        }
        let maxDecimals = 0;
        const sampleStart = Math.max(0, bars.length - 100);
        for (let i = sampleStart; i < bars.length; i++) {
            const b = bars[i];
            if (!b)
                continue;
            const vals = [b.open, b.high, b.low, b.close];
            for (const v of vals) {
                if (!isFinite(v))
                    continue;
                const s = v.toFixed(8).replace(/0+$/, '');
                const dotIdx = s.indexOf('.');
                if (dotIdx !== -1) {
                    const decLen = s.length - dotIdx - 1;
                    if (decLen > maxDecimals)
                        maxDecimals = decLen;
                }
            }
        }
        if (maxDecimals > 0) {
            const lastClose = bars.length > 0 ? Math.abs(bars[bars.length - 1].close) : 100;
            if (lastClose > 0.3 && lastClose < 3.0 && maxDecimals >= 4) {
                return Math.max(5, maxDecimals);
            }
            return Math.min(8, maxDecimals);
        }
        const refPrice = bars.length > 0 ? Math.abs(bars[bars.length - 1].close) : 100;
        if (refPrice === 0)
            return 2;
        if (refPrice < 0.01)
            return 6;
        if (refPrice < 3.0)
            return 5;
        if (refPrice < 200.0 && sym.includes('JPY'))
            return 3;
        return 2;
    }
    static formatPrice(price, digits) {
        if (price === null || price === undefined || !isFinite(price))
            return '—';
        const d = Math.max(0, Math.min(8, Math.floor(digits)));
        return price.toFixed(d);
    }
    static getThemePalette(themeMode) {
        const isLight = String(themeMode).toLowerCase() === 'light';
        if (isLight) {
            return {
                isLight: true,
                panelBg: 'rgba(255, 255, 255, 0.96)',
                panelHeaderBgAlpha: 0.18,
                panelBorder: '#cbd5e1',
                rowAltBg: 'rgba(15, 23, 42, 0.04)',
                textPrimary: '#0f172a',
                textSecondary: '#334155',
                textMuted: '#64748b',
                pillBg: 'rgba(255, 255, 255, 0.95)',
                pillText: '#0f172a',
                zoneLabelBg: 'rgba(255, 255, 255, 0.88)',
                zoneLabelText: '#0f172a',
                zoneMitigatedText: '#64748b',
                eqLineStroke: 'rgba(126, 34, 206, 0.75)',
                eqText: '#6b21a8',
                bullText: '#047857',
                bearText: '#b91c1c',
                neutralText: '#475569',
                warnText: '#991b1b',
                accentGold: '#b45309',
                accentCyan: '#0369a1',
                tp2Color: '#0284c7',
                hlColor: '#0f172a',
                yhlColor: '#475569',
                vwapColor: '#1e293b',
                vwapBandColor: '#64748b',
                dpocColor: '#a21caf',
                wpocColor: '#86198f',
                mpocColor: '#701a75',
                adrColor: '#0369a1',
                rsiObColor: '#b91c1c',
                rsiOsColor: '#15803d',
            };
        }
        return {
            isLight: false,
            panelBg: 'rgba(15, 23, 42, 0.94)',
            panelHeaderBgAlpha: 0.28,
            panelBorder: '#334155',
            rowAltBg: 'rgba(255, 255, 255, 0.04)',
            textPrimary: '#f8fafc',
            textSecondary: '#cbd5e1',
            textMuted: '#94a3b8',
            pillBg: 'rgba(15, 23, 42, 0.92)',
            pillText: '#f8fafc',
            zoneLabelBg: 'rgba(15, 23, 42, 0.82)',
            zoneLabelText: '#f8fafc',
            zoneMitigatedText: '#94a3b8',
            eqLineStroke: 'rgba(192, 132, 252, 0.70)',
            eqText: '#e9d5ff',
            bullText: '#34d399',
            bearText: '#f87171',
            neutralText: '#94a3b8',
            warnText: '#fca5a5',
            accentGold: '#fbbf24',
            accentCyan: '#38bdf8',
            tp2Color: '#38bdf8',
            hlColor: '#f8fafc',
            yhlColor: '#94a3b8',
            vwapColor: '#e2e8f0',
            vwapBandColor: '#94a3b8',
            dpocColor: '#ff00ff',
            wpocColor: '#d946ef',
            mpocColor: '#c026d3',
            adrColor: '#06b6d4',
            rsiObColor: '#f43f5e',
            rsiOsColor: '#10b981',
        };
    }
}
// ============================================================================
// 2. SMC 3-LAYER DETECTION MODULES
// ============================================================================
class StructureDetector {
    static detectConfirmedSwings(bars, swingLength) {
        const len = Math.max(3, Math.floor(swingLength || 5));
        const swings = [];
        const lastClosedIdx = bars.length - 2;
        if (lastClosedIdx < len * 2)
            return swings;
        for (let confirmIdx = len * 2; confirmIdx <= lastClosedIdx; confirmIdx++) {
            const pivotIdx = confirmIdx - len;
            const candidateHigh = bars[pivotIdx].high;
            const candidateLow = bars[pivotIdx].low;
            let isSwingHigh = true;
            let isSwingLow = true;
            for (let k = pivotIdx - len; k <= pivotIdx + len; k++) {
                if (k === pivotIdx)
                    continue;
                if (bars[k].high > candidateHigh)
                    isSwingHigh = false;
                if (bars[k].low < candidateLow)
                    isSwingLow = false;
                if (!isSwingHigh && !isSwingLow)
                    break;
            }
            if (isSwingHigh) {
                swings.push({
                    index: pivotIdx,
                    ConfirmIndex: confirmIdx,
                    time: bars[pivotIdx].time,
                    confirmTime: bars[confirmIdx].time,
                    price: candidateHigh,
                    type: 'HIGH',
                });
            }
            if (isSwingLow) {
                swings.push({
                    index: pivotIdx,
                    ConfirmIndex: confirmIdx,
                    time: bars[pivotIdx].time,
                    confirmTime: bars[confirmIdx].time,
                    price: candidateLow,
                    type: 'LOW',
                });
            }
        }
        return swings;
    }
    static evaluateStructure(bars, swingLength, sweepMinAtr, upToTimestamp) {
        const len = Math.max(3, Math.floor(swingLength || 5));
        const atr = MathUtils.computeATR(bars, 14);
        const events = [];
        const sweeps = [];
        let bias = 'NEUTRAL';
        let activeSwingHigh = null;
        let activeSwingLow = null;
        let brokenHighIdx = -1;
        let brokenLowIdx = -1;
        let recentBearishSweep = false;
        let recentBullishSweep = false;
        const maxIdx = bars.length - 2;
        for (let i = len * 2; i <= maxIdx; i++) {
            const bar = bars[i];
            if (upToTimestamp !== undefined && bar.time > upToTimestamp)
                break;
            const pivotIdx = i - len;
            let isHigh = true;
            let isLow = true;
            for (let k = pivotIdx - len; k <= pivotIdx + len; k++) {
                if (k === pivotIdx)
                    continue;
                if (bars[k].high > bars[pivotIdx].high)
                    isHigh = false;
                if (bars[k].low < bars[pivotIdx].low)
                    isLow = false;
            }
            if (isHigh) {
                activeSwingHigh = {
                    index: pivotIdx,
                    ConfirmIndex: i,
                    time: bars[pivotIdx].time,
                    confirmTime: bar.time,
                    price: bars[pivotIdx].high,
                    type: 'HIGH',
                };
            }
            if (isLow) {
                activeSwingLow = {
                    index: pivotIdx,
                    ConfirmIndex: i,
                    time: bars[pivotIdx].time,
                    confirmTime: bar.time,
                    price: bars[pivotIdx].low,
                    type: 'LOW',
                };
            }
            const curAtr = atr[i] || 1e-8;
            if (activeSwingHigh && activeSwingHigh.index !== brokenHighIdx) {
                const pen = bar.high - activeSwingHigh.price;
                if (pen >= sweepMinAtr * curAtr && bar.close <= activeSwingHigh.price) {
                    sweeps.push({
                        time: bar.time,
                        barIndex: i,
                        direction: 'BEARISH',
                        swingPrice: activeSwingHigh.price,
                        wickExtreme: bar.high,
                        penetrationAtr: pen / curAtr,
                    });
                    recentBearishSweep = true;
                }
            }
            if (activeSwingLow && activeSwingLow.index !== brokenLowIdx) {
                const pen = activeSwingLow.price - bar.low;
                if (pen >= sweepMinAtr * curAtr && bar.close >= activeSwingLow.price) {
                    sweeps.push({
                        time: bar.time,
                        barIndex: i,
                        direction: 'BULLISH',
                        swingPrice: activeSwingLow.price,
                        wickExtreme: bar.low,
                        penetrationAtr: pen / curAtr,
                    });
                    recentBullishSweep = true;
                }
            }
            if (activeSwingHigh &&
                activeSwingHigh.index !== brokenHighIdx &&
                bar.close > activeSwingHigh.price) {
                const type = bias === 'BULLISH' ? 'BOS' : 'CHOCH';
                events.push({
                    time: bar.time,
                    barIndex: i,
                    type,
                    direction: 'BULLISH',
                    level: activeSwingHigh.price,
                    sweptPrior: recentBullishSweep,
                });
                bias = 'BULLISH';
                brokenHighIdx = activeSwingHigh.index;
                recentBullishSweep = false;
            }
            else if (activeSwingLow &&
                activeSwingLow.index !== brokenLowIdx &&
                bar.close < activeSwingLow.price) {
                const type = bias === 'BEARISH' ? 'BOS' : 'CHOCH';
                events.push({
                    time: bar.time,
                    barIndex: i,
                    type,
                    direction: 'BEARISH',
                    level: activeSwingLow.price,
                    sweptPrior: recentBearishSweep,
                });
                bias = 'BEARISH';
                brokenLowIdx = activeSwingLow.index;
                recentBearishSweep = false;
            }
        }
        return {
            bias,
            events,
            sweeps,
            lastSwingHigh: activeSwingHigh,
            lastSwingLow: activeSwingLow,
        };
    }
}
class ZoneDetector {
    static detectH1Zones(h1Bars, params) {
        const n = h1Bars.length;
        if (n < 5)
            return { activeZones: [], recentlyMitigatedZones: [], h1Atr: 0 };
        const atr = MathUtils.computeATR(h1Bars, 14);
        const allZones = [];
        const lastClosedIdx = n - 2;
        for (let i = 2; i <= lastClosedIdx; i++) {
            const curAtr = atr[i] || 1e-8;
            const b0 = h1Bars[i];
            const b1 = h1Bars[i - 1];
            const b2 = h1Bars[i - 2];
            if (params.showFVG) {
                const body1 = Math.abs(b1.close - b1.open);
                if (b0.low > b2.high && b1.close > b1.open && body1 >= params.dispMinAtr * curAtr) {
                    const top = b0.low;
                    const bottom = b2.high;
                    const sizeAtr = (top - bottom) / curAtr;
                    if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                        allZones.push({
                            id: `FVG_BULL_${b1.time}`,
                            type: 'FVG',
                            direction: 'BULLISH',
                            top,
                            bottom,
                            entryEdge: top,
                            farSide: bottom,
                            createdTime: b1.time,
                            confirmedTime: b0.time,
                            createdH1Index: i,
                            mitigated: false,
                            sizeAtr,
                            qualityScore: Math.min(100, Math.round((body1 / curAtr) * 50)),
                        });
                    }
                }
                if (b0.high < b2.low && b1.close < b1.open && body1 >= params.dispMinAtr * curAtr) {
                    const top = b2.low;
                    const bottom = b0.high;
                    const sizeAtr = (top - bottom) / curAtr;
                    if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                        allZones.push({
                            id: `FVG_BEAR_${b1.time}`,
                            type: 'FVG',
                            direction: 'BEARISH',
                            top,
                            bottom,
                            entryEdge: bottom,
                            farSide: top,
                            createdTime: b1.time,
                            confirmedTime: b0.time,
                            createdH1Index: i,
                            mitigated: false,
                            sizeAtr,
                            qualityScore: Math.min(100, Math.round((body1 / curAtr) * 50)),
                        });
                    }
                }
            }
            if (params.showOB) {
                const dispBody = Math.abs(b0.close - b0.open);
                const isBullDisp = b0.close > b0.open && dispBody >= params.dispMinAtr * curAtr && b0.close > b1.high;
                const isBearDisp = b0.close < b0.open && dispBody >= params.dispMinAtr * curAtr && b0.close < b1.low;
                if (isBullDisp) {
                    let obCandle = null;
                    for (let lookback = 1; lookback <= 3 && i - lookback >= 0; lookback++) {
                        const cand = h1Bars[i - lookback];
                        if (cand.close < cand.open) {
                            obCandle = cand;
                            break;
                        }
                    }
                    if (obCandle) {
                        const top = obCandle.high;
                        const bottom = obCandle.low;
                        const sizeAtr = (top - bottom) / curAtr;
                        if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                            allZones.push({
                                id: `OB_BULL_${obCandle.time}`,
                                type: 'OB',
                                direction: 'BULLISH',
                                top,
                                bottom,
                                entryEdge: top,
                                farSide: bottom,
                                createdTime: obCandle.time,
                                confirmedTime: b0.time,
                                createdH1Index: i,
                                mitigated: false,
                                sizeAtr,
                                qualityScore: Math.min(100, Math.round((dispBody / curAtr) * 60)),
                            });
                        }
                    }
                }
                if (isBearDisp) {
                    let obCandle = null;
                    for (let lookback = 1; lookback <= 3 && i - lookback >= 0; lookback++) {
                        const cand = h1Bars[i - lookback];
                        if (cand.close > cand.open) {
                            obCandle = cand;
                            break;
                        }
                    }
                    if (obCandle) {
                        const top = obCandle.high;
                        const bottom = obCandle.low;
                        const sizeAtr = (top - bottom) / curAtr;
                        if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                            allZones.push({
                                id: `OB_BEAR_${obCandle.time}`,
                                type: 'OB',
                                direction: 'BEARISH',
                                top,
                                bottom,
                                entryEdge: bottom,
                                farSide: top,
                                createdTime: obCandle.time,
                                confirmedTime: b0.time,
                                createdH1Index: i,
                                mitigated: false,
                                sizeAtr,
                                qualityScore: Math.min(100, Math.round((dispBody / curAtr) * 60)),
                            });
                        }
                    }
                }
            }
            for (const z of allZones) {
                if (z.mitigated || i <= z.createdH1Index)
                    continue;
                if (z.direction === 'BULLISH' && b0.close < z.farSide) {
                    z.mitigated = true;
                    z.mitigatedTime = b0.time;
                }
                else if (z.direction === 'BEARISH' && b0.close > z.farSide) {
                    z.mitigated = true;
                    z.mitigatedTime = b0.time;
                }
            }
        }
        const activeZones = [];
        const recentlyMitigatedZones = [];
        for (const z of allZones) {
            const ageBars = lastClosedIdx - z.createdH1Index;
            if (!z.mitigated && ageBars <= params.zMaxAge) {
                activeZones.push(z);
            }
            else if (z.mitigated && ageBars <= Math.min(12, params.zMaxAge)) {
                recentlyMitigatedZones.push(z);
            }
        }
        return {
            activeZones,
            recentlyMitigatedZones,
            h1Atr: atr[lastClosedIdx] || atr[atr.length - 1] || 0,
        };
    }
}
class TriggerDetector {
    static evaluateM15Triggers(m15Bars, bias, primaryZone, swingLength, sweepMinAtr, dispMinAtr) {
        const struct = StructureDetector.evaluateStructure(m15Bars, swingLength, sweepMinAtr);
        const atrArr = MathUtils.computeATR(m15Bars, 14);
        const lastClosedIdx = Math.max(0, m15Bars.length - 2);
        const m15Atr = atrArr[lastClosedIdx] || 1e-8;
        let latestValidSweep = null;
        let latestTriggerChoch = null;
        let strongDisplacementAfterZone = false;
        const targetDir = bias === 'BULLISH' ? 'BULLISH' : bias === 'BEARISH' ? 'BEARISH' : null;
        if (!targetDir) {
            return {
                events: struct.events,
                sweeps: struct.sweeps,
                latestValidSweep: null,
                latestTriggerChoch: null,
                strongDisplacementAfterZone: false,
                m15Atr,
            };
        }
        const lookbackStartIdx = Math.max(0, lastClosedIdx - 15);
        const lookbackStartTime = m15Bars[lookbackStartIdx]?.time || 0;
        for (let i = struct.sweeps.length - 1; i >= 0; i--) {
            const sw = struct.sweeps[i];
            if (sw.time < lookbackStartTime)
                break;
            if (sw.direction === targetDir) {
                latestValidSweep = sw;
                break;
            }
        }
        for (let i = struct.events.length - 1; i >= 0; i--) {
            const ev = struct.events[i];
            if (ev.time < lookbackStartTime)
                break;
            if (ev.direction === targetDir && (ev.type === 'CHOCH' || ev.sweptPrior)) {
                if (latestValidSweep && ev.barIndex >= latestValidSweep.barIndex) {
                    latestTriggerChoch = ev;
                    break;
                }
                else if (ev.sweptPrior) {
                    latestTriggerChoch = ev;
                    break;
                }
            }
        }
        if (primaryZone) {
            for (let i = Math.max(1, lastClosedIdx - 2); i <= lastClosedIdx; i++) {
                const b = m15Bars[i];
                const prev = m15Bars[i - 1];
                const body = Math.abs(b.close - b.open);
                const curAtr = atrArr[i] || m15Atr;
                if (targetDir === 'BULLISH' &&
                    (b.low <= primaryZone.top || prev.low <= primaryZone.top) &&
                    b.close > b.open &&
                    body >= dispMinAtr * curAtr * 1.25) {
                    strongDisplacementAfterZone = true;
                }
                else if (targetDir === 'BEARISH' &&
                    (b.high >= primaryZone.bottom || prev.high >= primaryZone.bottom) &&
                    b.close < b.open &&
                    body >= dispMinAtr * curAtr * 1.25) {
                    strongDisplacementAfterZone = true;
                }
            }
        }
        return {
            events: struct.events,
            sweeps: struct.sweeps,
            latestValidSweep,
            latestTriggerChoch,
            strongDisplacementAfterZone,
            m15Atr,
        };
    }
}
class StateManager {
    static evaluateMarketState(m15Bars, h4Bars, h1Bars, params, digits, previousSnapshot) {
        const swingLength = Number(params.Swing_Length) || 5;
        const sweepMinAtr = Number(params.Sweep_min_atr) || 0.15;
        const dispMinAtr = Number(params.Disp_min_atr) || 0.5;
        const zMaxAge = Number(params.Z_max_age) || 40;
        const zMaxSizeAtr = Number(params.Z_max_size_atr) || 1.5;
        const showFVG = Number(params.Show_FVG) !== 0;
        const showOB = Number(params.Show_OB) !== 0;
        const bufferAtrMult = Number(params.buffer_atr_mult) || 0.3;
        const rrMin = Number(params.RR_min) || 1.5;
        const isLight = String(params.Theme_Mode || 'dark').toLowerCase() === 'light';
        const lastClosedM15Idx = Math.max(0, m15Bars.length - 2);
        const currentBar = m15Bars[lastClosedM15Idx] || m15Bars[m15Bars.length - 1];
        const currentPrice = currentBar ? currentBar.close : 0;
        const currentTime = currentBar ? currentBar.time : 0;
        const h4Struct = StructureDetector.evaluateStructure(h4Bars, swingLength, sweepMinAtr);
        const h4Bias = h4Struct.bias;
        const h4High = h4Struct.lastSwingHigh ? h4Struct.lastSwingHigh.price : null;
        const h4Low = h4Struct.lastSwingLow ? h4Struct.lastSwingLow.price : null;
        let h4Equilibrium = null;
        let pdZone = 'NA';
        let pdPercent = 50;
        if (h4High !== null && h4Low !== null && h4High > h4Low) {
            h4Equilibrium = (h4High + h4Low) * 0.5;
            pdPercent = ((currentPrice - h4Low) / (h4High - h4Low)) * 100;
            if (pdPercent >= 47.5 && pdPercent <= 52.5) {
                pdZone = 'EQUILIBRIUM';
            }
            else if (pdPercent < 47.5) {
                pdZone = 'DISCOUNT';
            }
            else {
                pdZone = 'PREMIUM';
            }
        }
        const h1ZoneResult = ZoneDetector.detectH1Zones(h1Bars, {
            dispMinAtr,
            zMaxAge,
            zMaxSizeAtr,
            showFVG,
            showOB,
        });
        const alignedZones = h1ZoneResult.activeZones.filter((z) => (h4Bias === 'BULLISH' && z.direction === 'BULLISH') ||
            (h4Bias === 'BEARISH' && z.direction === 'BEARISH'));
        alignedZones.sort((a, b) => {
            const distA = currentPrice >= a.bottom && currentPrice <= a.top
                ? 0
                : Math.min(Math.abs(currentPrice - a.top), Math.abs(currentPrice - a.bottom));
            const distB = currentPrice >= b.bottom && currentPrice <= b.top
                ? 0
                : Math.min(Math.abs(currentPrice - b.top), Math.abs(currentPrice - b.bottom));
            return distA - distB;
        });
        const primaryZone = alignedZones.length > 0 ? alignedZones[0] : null;
        let isPriceInZone = false;
        let touchedZoneRecently = false;
        if (primaryZone) {
            isPriceInZone = currentPrice >= primaryZone.bottom && currentPrice <= primaryZone.top;
            for (let k = Math.max(0, lastClosedM15Idx - 6); k <= lastClosedM15Idx; k++) {
                const b = m15Bars[k];
                if (b && b.low <= primaryZone.top && b.high >= primaryZone.bottom) {
                    touchedZoneRecently = true;
                    break;
                }
            }
        }
        const m15Trig = TriggerDetector.evaluateM15Triggers(m15Bars, h4Bias, primaryZone, swingLength, sweepMinAtr, dispMinAtr);
        const warnings = [];
        const m15AtrArr = MathUtils.computeATR(m15Bars, 14);
        const recentAtr = m15AtrArr[lastClosedM15Idx] || 0;
        let avgAtr50 = 0;
        const startAtrIdx = Math.max(0, lastClosedM15Idx - 50);
        const countAtr = lastClosedM15Idx - startAtrIdx + 1;
        for (let k = startAtrIdx; k <= lastClosedM15Idx; k++) {
            avgAtr50 += m15AtrArr[k] || 0;
        }
        avgAtr50 = countAtr > 0 ? avgAtr50 / countAtr : recentAtr;
        if (avgAtr50 > 0 && recentAtr < avgAtr50 * 0.45) {
            warnings.push('Low Volatility (ATR Compression)');
        }
        const utcHour = new Date(currentTime * 1000).getUTCHours();
        if (utcHour === 21 || utcHour === 22) {
            warnings.push('Session End / Rollover Window');
        }
        const latestH1ClosedTime = h1Bars.length >= 2 ? h1Bars[h1Bars.length - 2].time : 0;
        const justMitigatedZone = h1ZoneResult.recentlyMitigatedZones.find((z) => z.mitigatedTime === latestH1ClosedTime &&
            ((h4Bias === 'BULLISH' && z.direction === 'BULLISH') ||
                (h4Bias === 'BEARISH' && z.direction === 'BEARISH')));
        let suggestedEntry = null;
        let suggestedSL = null;
        let suggestedTP1 = null;
        let suggestedTP2 = null;
        let currentRR = null;
        const riskAtr = h1ZoneResult.h1Atr > 0 ? h1ZoneResult.h1Atr : recentAtr * 2;
        if (primaryZone && h4Bias !== 'NEUTRAL') {
            const isTriggerConfirmed = Boolean(m15Trig.latestTriggerChoch && (isPriceInZone || touchedZoneRecently));
            suggestedEntry = isTriggerConfirmed ? currentPrice : primaryZone.entryEdge;
            if (h4Bias === 'BULLISH') {
                const slBase = m15Trig.latestValidSweep
                    ? Math.min(primaryZone.farSide, m15Trig.latestValidSweep.wickExtreme)
                    : primaryZone.farSide;
                suggestedSL = slBase - bufferAtrMult * riskAtr;
                const risk = Math.max(Math.abs(suggestedEntry - suggestedSL), 1e-8);
                suggestedTP1 =
                    h4High && h4High > suggestedEntry + risk * rrMin
                        ? h4High
                        : suggestedEntry + risk * rrMin;
                suggestedTP2 = suggestedEntry + risk * Math.max(rrMin * 1.6, 2.5);
                currentRR = (suggestedTP1 - suggestedEntry) / risk;
            }
            else if (h4Bias === 'BEARISH') {
                const slBase = m15Trig.latestValidSweep
                    ? Math.max(primaryZone.farSide, m15Trig.latestValidSweep.wickExtreme)
                    : primaryZone.farSide;
                suggestedSL = slBase + bufferAtrMult * riskAtr;
                const risk = Math.max(Math.abs(suggestedSL - suggestedEntry), 1e-8);
                suggestedTP1 =
                    h4Low && h4Low < suggestedEntry - risk * rrMin
                        ? h4Low
                        : suggestedEntry - risk * rrMin;
                suggestedTP2 = suggestedEntry - risk * Math.max(rrMin * 1.6, 2.5);
                currentRR = (suggestedEntry - suggestedTP1) / risk;
            }
        }
        let state = 'NO_TRADE';
        let stateMessage = 'NO TRADE - Neutral Bias';
        let stateColor = isLight ? '#475569' : '#94a3b8';
        let actionGuidance = 'Stay out';
        let entryGuidance = 'No Trade';
        const hasValidTrigger = Boolean(m15Trig.latestTriggerChoch && (isPriceInZone || touchedZoneRecently));
        if (h4Bias === 'NEUTRAL') {
            state = 'NO_TRADE';
            stateMessage = 'NO TRADE - Neutral Bias';
            stateColor = isLight ? '#475569' : '#94a3b8';
            actionGuidance = 'Stay out';
            entryGuidance = 'No Trade';
        }
        else if (justMitigatedZone && !primaryZone) {
            state = 'INVALID';
            stateMessage = 'INVALID - Zone Mitigated';
            stateColor = isLight ? '#dc2626' : '#f87171';
            actionGuidance = 'Cancel pending orders';
            entryGuidance = 'No Trade';
        }
        else if (warnings.length > 0 && !hasValidTrigger) {
            state = 'WARNING';
            stateMessage = 'WARNING - Poor Conditions';
            stateColor = isLight ? '#991b1b' : '#ef4444';
            actionGuidance = 'Avoid new entries';
            entryGuidance = warnings[0];
        }
        else if (!primaryZone) {
            state = 'BIAS_ONLY';
            stateMessage = 'BIAS ONLY - Waiting for Zone';
            stateColor = isLight ? '#1d4ed8' : '#60a5fa';
            actionGuidance = 'Monitor for new POI';
            entryGuidance = 'No Trade';
        }
        else if (hasValidTrigger) {
            state = 'TRIGGER_READY';
            stateMessage = 'TRIGGER - Confirm Entry';
            stateColor = isLight ? '#047857' : '#34d399';
            actionGuidance = 'Enter market (or confirm limit)';
            if (currentRR !== null && currentRR < rrMin) {
                entryGuidance = 'RR too low - Skip';
            }
            else {
                entryGuidance = 'Valid Trigger - Consider Market Entry';
            }
        }
        else if (isPriceInZone) {
            state = 'IN_ZONE';
            stateMessage = 'IN ZONE - Waiting for Trigger';
            stateColor = isLight ? '#c2410c' : '#fb923c';
            actionGuidance = 'Watch for Sweep + CHoCH';
            if (m15Trig.strongDisplacementAfterZone) {
                entryGuidance = 'Momentum Play - Consider Stop Entry';
            }
            else {
                entryGuidance = 'Wait for Sweep + CHoCH close';
            }
        }
        else {
            state = 'ARMED';
            stateMessage = 'ARMED - Limit Zone Ready';
            stateColor = isLight ? '#b45309' : '#fbbf24';
            actionGuidance = 'Prepare limit order at zone edge';
            if (currentRR !== null && currentRR < rrMin) {
                entryGuidance = 'RR too low - Skip';
            }
            else if (m15Trig.strongDisplacementAfterZone && touchedZoneRecently) {
                entryGuidance = 'Momentum Play - Consider Stop Entry';
            }
            else {
                entryGuidance = 'Consider Limit at zone edge';
            }
        }
        const alertsFired = [];
        if (previousSnapshot) {
            if (previousSnapshot.h4Bias !== h4Bias) {
                alertsFired.push(`Bias Flip: H4 Bias changed to ${h4Bias}`);
            }
            if (primaryZone &&
                (!previousSnapshot.primaryZone || previousSnapshot.primaryZone.id !== primaryZone.id)) {
                alertsFired.push(`New Valid Zone Detected: H1 ${primaryZone.direction} ${primaryZone.type} (${MathUtils.formatPrice(primaryZone.bottom, digits)} - ${MathUtils.formatPrice(primaryZone.top, digits)})`);
            }
            if (state === 'IN_ZONE' && previousSnapshot.state !== 'IN_ZONE') {
                alertsFired.push(`Price Entered H1 ${primaryZone?.direction || ''} ${primaryZone?.type || 'Zone'}`);
            }
            if (state === 'TRIGGER_READY' && previousSnapshot.state !== 'TRIGGER_READY') {
                alertsFired.push(`Valid Trigger Confirmed: M15 Sweep + CHoCH (${h4Bias})`);
            }
            if (state === 'INVALID' && previousSnapshot.state !== 'INVALID') {
                alertsFired.push(`Zone Mitigated / Invalidated`);
            }
            if (state === 'WARNING' && previousSnapshot.state !== 'WARNING') {
                alertsFired.push(`Warning Condition: ${warnings.join(', ')}`);
            }
        }
        return {
            time: currentTime,
            close: currentPrice,
            digits,
            h4Bias,
            h4SwingHigh: h4High,
            h4SwingLow: h4Low,
            h4Equilibrium,
            pdZone,
            pdPercent,
            activeZones: h1ZoneResult.activeZones,
            mitigatedZones: h1ZoneResult.recentlyMitigatedZones.slice(-4),
            primaryZone,
            m15Sweep: m15Trig.latestValidSweep,
            m15TriggerEvent: m15Trig.latestTriggerChoch,
            strongDisplacementAfterZone: m15Trig.strongDisplacementAfterZone,
            state,
            stateMessage,
            stateColor,
            actionGuidance,
            entryGuidance,
            suggestedEntry,
            suggestedSL,
            suggestedTP1,
            suggestedTP2,
            currentRR,
            warnings,
            alertsFired,
        };
    }
}
// ============================================================================
// 3. CANVAS PRIMITIVE: DRAWING ZONES, SL/TP, DASHBOARD & PRECISION LEVELS
// ============================================================================
class SMCCanvasPrimitive {
    constructor(indicator) {
        this._chart = null;
        this._series = null;
        this.indicator = indicator;
    }
    attached(param) {
        this._chart = param.chart;
        this._series = param.series;
        this._requestUpdate = param.requestUpdate;
    }
    detached() {
        this._chart = null;
        this._series = null;
        this._requestUpdate = undefined;
    }
    requestUpdate() {
        if (typeof this._requestUpdate === 'function') {
            this._requestUpdate();
        }
    }
    paneViews() {
        if (!this.indicator.isVisible)
            return [];
        const self = this;
        return [
            {
                zOrder() {
                    return 'normal';
                },
                renderer() {
                    return {
                        draw(target) {
                            if (typeof target.useMediaCoordinateSpace === 'function') {
                                target.useMediaCoordinateSpace(({ context, mediaSize }) => {
                                    self.drawOverlay(context, mediaSize.width, mediaSize.height, 1, 1);
                                });
                            }
                            else if (typeof target.useBitmapCoordinateSpace === 'function') {
                                target.useBitmapCoordinateSpace(({ context, bitmapSize, horizontalPixelRatio, verticalPixelRatio, }) => {
                                    self.drawOverlay(context, bitmapSize.width, bitmapSize.height, horizontalPixelRatio || 1, verticalPixelRatio || 1);
                                });
                            }
                        },
                    };
                },
            },
        ];
    }
    timeToX(time, fallbackRightEdge) {
        if (!this._chart)
            return null;
        const ts = this._chart.timeScale();
        if (!ts)
            return null;
        if (typeof ts.timeToCoordinate === 'function') {
            const coord = ts.timeToCoordinate(time);
            if (coord !== null && coord !== undefined && isFinite(coord))
                return Number(coord);
        }
        const bars = this.indicator.getRawBars();
        if (bars.length > 0 && typeof ts.logicalToCoordinate === 'function') {
            if (time <= bars[0].time) {
                const c0 = ts.logicalToCoordinate(0);
                if (c0 !== null && c0 !== undefined)
                    return Number(c0);
            }
            if (time >= bars[bars.length - 1].time) {
                const cLast = ts.logicalToCoordinate(bars.length - 1);
                if (cLast !== null && cLast !== undefined)
                    return Number(cLast);
                return fallbackRightEdge;
            }
            let lo = 0, hi = bars.length - 1;
            while (lo <= hi) {
                const mid = (lo + hi) >> 1;
                if (bars[mid].time < time)
                    lo = mid + 1;
                else
                    hi = mid - 1;
            }
            const coord = ts.logicalToCoordinate(lo);
            if (coord !== null && coord !== undefined && isFinite(coord))
                return Number(coord);
        }
        return null;
    }
    priceToY(price) {
        if (!this._series || typeof this._series.priceToCoordinate !== 'function')
            return null;
        const y = this._series.priceToCoordinate(price);
        if (y === null || y === undefined || !isFinite(y))
            return null;
        return Number(y);
    }
    drawTextTag(ctx, text, x, y, align, textColor, bgColor, borderColor, font = 'bold 10px sans-serif') {
        ctx.save();
        ctx.font = font;
        const padX = 6;
        const boxH = 16;
        const textW = ctx.measureText(text).width;
        const boxW = textW + padX * 2;
        const drawX = align === 'right' ? x - boxW : x;
        const drawY = y - boxH / 2;
        ctx.fillStyle = bgColor;
        ctx.beginPath();
        ctx.roundRect(drawX, drawY, boxW, boxH, 3);
        ctx.fill();
        if (borderColor) {
            ctx.strokeStyle = borderColor;
            ctx.lineWidth = 1;
            ctx.stroke();
        }
        ctx.fillStyle = textColor;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, drawX + padX, y);
        ctx.restore();
    }
    drawOverlay(ctx, width, height, hRatio, vRatio) {
        const snap = this.indicator.latestSnapshot;
        if (!snap || !this._series)
            return;
        ctx.save();
        if (hRatio !== 1 || vRatio !== 1) {
            ctx.scale(hRatio, vRatio);
            width = width / hRatio;
            height = height / vRatio;
        }
        const params = this.indicator.params;
        const palette = MathUtils.getThemePalette(String(params.Theme_Mode || 'dark'));
        const digits = snap.digits ?? 2;
        const transparency = Number(params.Zone_Transparency ?? 85);
        const baseAlpha = Math.max(0.06, Math.min(0.65, (100 - transparency) / 100));
        const fillAlpha = palette.isLight ? Math.min(0.65, baseAlpha * 1.25) : baseAlpha;
        const showLabels = Number(params.Show_Labels) !== 0;
        const showSLTP = Number(params.Show_SL_TP) !== 0;
        const showDashboard = Number(params.Show_Dashboard) !== 0;
        const bannerPos = String(params.Banner_Position || 'top-right');
        const dashboardPos = String(params.Dashboard_Position || 'bottom-right');
        const bars = this.indicator.getRawBars();
        const lastBarTime = bars.length > 0 ? bars[bars.length - 1].time : snap.time;
        const rawLastX = this.timeToX(lastBarTime, width - 80);
        const chartRightX = Math.min(width - 8, (rawLastX ?? width - 80) + 95);
        // 1. Draw H4 Equilibrium Line & Premium/Discount Reference
        if (snap.h4Equilibrium !== null &&
            snap.h4SwingHigh !== null &&
            snap.h4SwingLow !== null) {
            const yEq = this.priceToY(snap.h4Equilibrium);
            if (yEq !== null && yEq >= 0 && yEq <= height) {
                ctx.save();
                ctx.strokeStyle = palette.eqLineStroke;
                ctx.lineWidth = 1.25;
                ctx.setLineDash([4, 4]);
                ctx.beginPath();
                ctx.moveTo(Math.max(0, chartRightX - 280), yEq);
                ctx.lineTo(chartRightX, yEq);
                ctx.stroke();
                ctx.restore();
                if (showLabels) {
                    this.drawTextTag(ctx, `H4 EQ (50%): ${MathUtils.formatPrice(snap.h4Equilibrium, digits)} [${snap.pdZone}]`, chartRightX - 4, yEq - 10, 'right', palette.eqText, palette.zoneLabelBg, palette.eqLineStroke, 'bold 10px sans-serif');
                }
            }
        }
        // 2. Draw Active & Recently Mitigated H1 Zones (OB & FVG)
        const zonesToRender = [...snap.mitigatedZones, ...snap.activeZones];
        for (const z of zonesToRender) {
            const yTop = this.priceToY(z.top);
            const yBottom = this.priceToY(z.bottom);
            if (yTop === null || yBottom === null)
                continue;
            const xStartRaw = this.timeToX(z.createdTime, 40);
            const xStart = Math.max(0, xStartRaw !== null ? xStartRaw : 40);
            const xEnd = z.mitigated && z.mitigatedTime
                ? Math.min(chartRightX, this.timeToX(z.mitigatedTime, chartRightX) ?? chartRightX)
                : chartRightX;
            if (xEnd <= xStart)
                continue;
            const boxY = Math.min(yTop, yBottom);
            const boxH = Math.max(2, Math.abs(yBottom - yTop));
            const isPrimary = snap.primaryZone && snap.primaryZone.id === z.id;
            let baseColor = '#26a69a';
            if (z.direction === 'BULLISH') {
                baseColor =
                    z.type === 'OB'
                        ? String(params.Bull_OB_Color || '#00e676')
                        : String(params.Bull_FVG_Color || '#26a69a');
            }
            else {
                baseColor =
                    z.type === 'OB'
                        ? String(params.Bear_OB_Color || '#ff5252')
                        : String(params.Bear_FVG_Color || '#ef5350');
            }
            ctx.save();
            ctx.fillStyle = MathUtils.hexToRgba(baseColor, z.mitigated ? fillAlpha * 0.45 : isPrimary ? fillAlpha * 1.35 : fillAlpha);
            ctx.fillRect(xStart, boxY, xEnd - xStart, boxH);
            const strokeAlpha = z.mitigated ? 0.45 : isPrimary ? 0.95 : 0.75;
            ctx.strokeStyle = MathUtils.hexToRgba(baseColor, strokeAlpha);
            ctx.lineWidth = isPrimary ? 1.6 : 1.1;
            if (z.mitigated)
                ctx.setLineDash([3, 3]);
            ctx.strokeRect(xStart, boxY, xEnd - xStart, boxH);
            if (!z.mitigated && isPrimary) {
                const yEdge = this.priceToY(z.entryEdge);
                if (yEdge !== null) {
                    ctx.strokeStyle = palette.accentGold;
                    ctx.lineWidth = 2;
                    ctx.setLineDash([]);
                    ctx.beginPath();
                    ctx.moveTo(xStart, yEdge);
                    ctx.lineTo(xEnd, yEdge);
                    ctx.stroke();
                }
            }
            ctx.restore();
            if (showLabels && xEnd - xStart > 55) {
                const statusTag = z.mitigated
                    ? ' [MITIGATED]'
                    : isPrimary
                        ? ' [ACTIVE POI]'
                        : '';
                const labelText = `H1 ${z.direction === 'BULLISH' ? 'Bull' : 'Bear'} ${z.type} (${MathUtils.formatPrice(z.bottom, digits)}-${MathUtils.formatPrice(z.top, digits)})${statusTag}`;
                const labelColor = z.mitigated
                    ? palette.zoneMitigatedText
                    : z.direction === 'BULLISH'
                        ? palette.bullText
                        : palette.bearText;
                this.drawTextTag(ctx, labelText, xStart + 5, boxY + 11, 'left', labelColor, palette.zoneLabelBg, MathUtils.hexToRgba(baseColor, z.mitigated ? 0.35 : 0.7), isPrimary ? 'bold 10px sans-serif' : '10px sans-serif');
            }
        }
        // 3. Draw Suggested Entry, Stop Loss & Take Profit Lines
        if (showSLTP &&
            snap.suggestedEntry !== null &&
            snap.suggestedSL !== null &&
            snap.suggestedTP1 !== null &&
            (snap.state === 'ARMED' ||
                snap.state === 'IN_ZONE' ||
                snap.state === 'TRIGGER_READY')) {
            const lineStartX = Math.max(40, chartRightX - 225);
            const drawLevelLine = (price, color, dash, label) => {
                const y = this.priceToY(price);
                if (y === null || y < 0 || y > height)
                    return;
                ctx.save();
                ctx.strokeStyle = color;
                ctx.lineWidth = 1.75;
                ctx.setLineDash(dash);
                ctx.beginPath();
                ctx.moveTo(lineStartX, y);
                ctx.lineTo(chartRightX, y);
                ctx.stroke();
                ctx.restore();
                if (showLabels) {
                    this.drawTextTag(ctx, `${label}: ${MathUtils.formatPrice(price, digits)}`, chartRightX - 4, y - 10, 'right', color, palette.zoneLabelBg, color, 'bold 10px sans-serif');
                }
            };
            drawLevelLine(snap.suggestedEntry, palette.accentGold, [], 'ENTRY');
            drawLevelLine(snap.suggestedSL, palette.bearText, [4, 3], 'SL');
            drawLevelLine(snap.suggestedTP1, palette.bullText, [4, 3], `TP1 (${snap.currentRR !== null ? snap.currentRR.toFixed(2) + 'R' : ''})`);
            if (snap.suggestedTP2 !== null) {
                drawLevelLine(snap.suggestedTP2, palette.tp2Color, [2, 3], 'TP2');
            }
        }
        // 4. Draw Precision Right Levels (from SMC_RSI_level.ts: H, L, YH, YL, VWAP, DPOC, ADR, RSI 70/30)
        if (Number(params.showLevelLines) === 1 && rawLastX !== null && rawLastX > 0) {
            this.indicator.refreshRealtimeLevels();
            const levels = this.indicator.computedLevels;
            if (levels && levels.length > 0) {
                const startX = rawLastX + 12;
                const lineLength = 55;
                const endX = startX + lineLength;
                const validItems = [];
                for (const lvl of levels) {
                    if (isNaN(lvl.price) || !isFinite(lvl.price))
                        continue;
                    const y = this.priceToY(lvl.price);
                    if (y === null || y < 5 || y > height - 5)
                        continue;
                    validItems.push({
                        label: lvl.label,
                        price: lvl.price,
                        color: lvl.color,
                        lineStyle: lvl.lineStyle,
                        lineWidth: lvl.lineWidth || 1,
                        y: Math.round(y),
                    });
                }
                if (validItems.length > 0) {
                    validItems.sort((a, b) => (a.y || 0) - (b.y || 0));
                    let lastItemY = -999;
                    let currentOffsetCol = 0;
                    for (let i = 0; i < validItems.length; i++) {
                        const item = validItems[i];
                        const itemY = item.y || 0;
                        if (Math.abs(itemY - lastItemY) < 13) {
                            currentOffsetCol = (currentOffsetCol + 1) % 2;
                        }
                        else {
                            currentOffsetCol = 0;
                        }
                        item.textX = endX + 8 + currentOffsetCol * 52;
                        lastItemY = itemY;
                    }
                    ctx.font = 'bold 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                    ctx.textBaseline = 'middle';
                    ctx.textAlign = 'left';
                    for (const item of validItems) {
                        const itemY = item.y || 0;
                        const itemTextX = item.textX || endX + 8;
                        ctx.strokeStyle = item.color;
                        ctx.lineWidth = item.lineWidth;
                        if (item.lineStyle === 1 || item.lineStyle === 2) {
                            ctx.setLineDash([4, 3]);
                        }
                        else {
                            ctx.setLineDash([]);
                        }
                        ctx.beginPath();
                        ctx.moveTo(startX, itemY);
                        ctx.lineTo(endX, itemY);
                        ctx.stroke();
                        ctx.fillStyle = item.color;
                        ctx.fillText(item.label, itemTextX, itemY);
                    }
                }
            }
        }
        // 5. Draw H4 Bias Status Banner Pill (Configurable position, default Top-Right)
        let bannerBottomY = 0;
        let bannerTopY = height;
        if (showLabels && bannerPos !== 'hide') {
            ctx.save();
            const biasColors = {
                BULLISH: palette.bullText,
                BEARISH: palette.bearText,
                NEUTRAL: palette.neutralText,
            };
            const badgeText = `H4 BIAS: ${snap.h4Bias}  |  ZONE: ${snap.pdZone} (${snap.pdPercent.toFixed(0)}%)  |  STATE: ${snap.stateMessage}`;
            ctx.font = 'bold 11px sans-serif';
            const textWidth = ctx.measureText(badgeText).width;
            const pillW = textWidth + 24;
            const pillH = 26;
            const margin = 14;
            let pillX = width - pillW - margin;
            let pillY = margin;
            if (bannerPos === 'top-center') {
                pillX = Math.max(margin, (width - pillW) / 2);
                pillY = margin;
            }
            else if (bannerPos === 'top-left') {
                pillX = margin;
                pillY = margin;
            }
            else if (bannerPos === 'bottom-left') {
                pillX = margin;
                pillY = Math.max(margin, height - pillH - margin);
            }
            else if (bannerPos === 'bottom-right') {
                pillX = Math.max(margin, width - pillW - margin);
                pillY = Math.max(margin, height - pillH - margin);
            }
            else {
                pillX = Math.max(margin, width - pillW - margin);
                pillY = margin;
            }
            bannerBottomY = pillY + pillH;
            bannerTopY = pillY;
            ctx.fillStyle = palette.pillBg;
            ctx.strokeStyle = biasColors[snap.h4Bias];
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.roundRect(pillX, pillY, pillW, pillH, 6);
            ctx.fill();
            ctx.stroke();
            ctx.fillStyle = palette.pillText;
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(badgeText, pillX + 12, pillY + pillH / 2);
            ctx.restore();
        }
        // 6. Draw Compact SMC Decision Dashboard Table
        if (showDashboard) {
            this.drawDashboardTable(ctx, width, height, snap, palette, digits, Number(params.RR_min) || 1.5, dashboardPos, bannerPos, bannerBottomY, bannerTopY);
        }
        ctx.restore();
    }
    drawDashboardTable(ctx, width, height, snap, palette, digits, rrMin, dashboardPos, bannerPos, bannerBottomY, bannerTopY) {
        const tableW = 305;
        const rowH = 20;
        const headerH = 26;
        const rows = [
            {
                label: 'Current Bias (H4)',
                value: `${snap.h4Bias} (${snap.pdZone})`,
                color: snap.h4Bias === 'BULLISH'
                    ? palette.bullText
                    : snap.h4Bias === 'BEARISH'
                        ? palette.bearText
                        : palette.neutralText,
            },
            {
                label: 'Active Zone (H1)',
                value: snap.primaryZone
                    ? `${snap.primaryZone.direction} ${snap.primaryZone.type} (${snap.activeZones.length} active)`
                    : 'None Active',
                color: snap.primaryZone ? palette.accentGold : palette.textMuted,
            },
            {
                label: 'Trigger Status (M15)',
                value: snap.m15TriggerEvent
                    ? `Confirmed (${snap.m15TriggerEvent.type})`
                    : snap.m15Sweep
                        ? 'Sweep Done (Wait CHoCH)'
                        : 'Waiting for Sweep',
                color: snap.m15TriggerEvent
                    ? palette.bullText
                    : snap.m15Sweep
                        ? palette.accentGold
                        : palette.textMuted,
            },
            {
                label: 'Indicator State',
                value: snap.stateMessage,
                color: snap.stateColor,
            },
            {
                label: 'Suggested Entry',
                value: MathUtils.formatPrice(snap.suggestedEntry, digits),
                color: palette.textPrimary,
            },
            {
                label: 'Suggested SL',
                value: MathUtils.formatPrice(snap.suggestedSL, digits),
                color: palette.bearText,
            },
            {
                label: 'Suggested TP1',
                value: MathUtils.formatPrice(snap.suggestedTP1, digits),
                color: palette.bullText,
            },
            {
                label: 'Current RR',
                value: snap.currentRR !== null
                    ? `${snap.currentRR.toFixed(2)}R (Min ${rrMin}R)`
                    : '—',
                color: snap.currentRR !== null
                    ? snap.currentRR >= rrMin
                        ? palette.bullText
                        : palette.bearText
                    : palette.textMuted,
            },
            {
                label: 'Action Guidance',
                value: snap.actionGuidance,
                color: palette.accentCyan,
            },
            {
                label: 'Recommendation',
                value: snap.entryGuidance,
                color: snap.stateColor,
            },
        ];
        const tableH = headerH + rows.length * rowH + 8;
        const margin = 14;
        let x = Math.max(margin, width - tableW - margin);
        let y = Math.max(margin, height - tableH - margin);
        if (dashboardPos === 'top-right') {
            x = Math.max(margin, width - tableW - margin);
            y = bannerPos === 'top-right' && bannerBottomY > 0 ? bannerBottomY + 8 : margin;
        }
        else if (dashboardPos === 'bottom-left') {
            x = margin;
            y =
                bannerPos === 'bottom-left' && bannerTopY < height
                    ? Math.max(margin, bannerTopY - tableH - 8)
                    : Math.max(margin, height - tableH - margin);
        }
        else if (dashboardPos === 'top-left') {
            x = margin;
            y = bannerPos === 'top-left' && bannerBottomY > 0 ? bannerBottomY + 8 : margin;
        }
        else {
            x = Math.max(margin, width - tableW - margin);
            y =
                bannerPos === 'bottom-right' && bannerTopY < height
                    ? Math.max(margin, bannerTopY - tableH - 8)
                    : Math.max(margin, height - tableH - margin);
        }
        ctx.save();
        ctx.fillStyle = palette.panelBg;
        ctx.strokeStyle = snap.stateColor || palette.panelBorder;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(x, y, tableW, tableH, 6);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = MathUtils.hexToRgba(snap.stateColor || '#2962ff', palette.panelHeaderBgAlpha);
        ctx.beginPath();
        ctx.roundRect(x, y, tableW, headerH, [6, 6, 0, 0]);
        ctx.fill();
        ctx.font = 'bold 11px sans-serif';
        ctx.fillStyle = palette.textPrimary;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(`SMC 3-LAYER DASHBOARD (${digits} Digits)`, x + 10, y + headerH / 2);
        for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            const ry = y + headerH + i * rowH;
            if (i % 2 === 1) {
                ctx.fillStyle = palette.rowAltBg;
                ctx.fillRect(x + 2, ry, tableW - 4, rowH);
            }
            ctx.font = '11px sans-serif';
            ctx.fillStyle = palette.textSecondary;
            ctx.textAlign = 'left';
            ctx.fillText(r.label, x + 10, ry + rowH / 2);
            ctx.font = 'bold 11px sans-serif';
            ctx.fillStyle = r.color || palette.textPrimary;
            ctx.textAlign = 'right';
            ctx.fillText(r.value, x + tableW - 10, ry + rowH / 2);
        }
        ctx.restore();
    }
}
// ============================================================================
// 4. MAIN QUANTDECK INDICATOR CLASS (IIndicator + Template Compatible)
// ============================================================================
export class SMC3LayerIndicator {
    constructor() {
        this.isVisible = true;
        this.engine = null;
        this.series = null;
        this._primitive = null;
        this._attachedMainSeries = null;
        this._rawBars = [];
        this._symbol = '';
        this._source = 'default';
        this._htfCache = new Map();
        this._rmaUp = [];
        this._rmaDown = [];
        this._staticLevels = {};
        this.computedLevels = [];
        this.cachedData = [];
        this.cachedMarkers = [];
        this.latestSnapshot = null;
        this.id = `custom_ind_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        this.name = 'SMC 3-Layer + Precision Levels & RSI';
        this.pane = 'main';
        this.description =
            '3-Layer Smart Money Concepts with Precision Price Levels (VWAP, H/L, POC, ADR, RSI Targets) and RSI Divergence Analysis';
        this.isVisible = true;
        this.params = {
            Theme_Mode: 'light',
            Banner_Position: 'top-right',
            Dashboard_Position: 'bottom-right',
            Price_Digits: -1,
            Zone_Transparency: 85,
            Show_Labels: 1,
            showSignals: 1,
            Show_SL_TP: 1,
            Show_Dashboard: 1,
            Enable_Alerts: 1,
            showLevelLines: 1,
            showDayLevels: 1,
            showVwapLevels: 1,
            showPocLevels: 1,
            showAdrLevels: 1,
            showRsiPredictor: 1,
            obLevel: 70,
            osLevel: 30,
            sessionMode: 'forex_gold',
            customOffsetHours: 2,
            showDivRsi: 1,
            lenRSI: 14,
            lbLeft: 5,
            lbRight: 5,
            Swing_Length: 5,
            Sweep_min_atr: 0.15,
            Disp_min_atr: 0.5,
            Z_max_age: 40,
            Z_max_size_atr: 1.5,
            Show_FVG: 1,
            Show_OB: 1,
            buffer_atr_mult: 0.3,
            RR_min: 1.5,
            Bull_OB_Color: '#00e676',
            Bear_OB_Color: '#ff5252',
            Bull_FVG_Color: '#26a69a',
            Bear_FVG_Color: '#ef5350',
            Eq_Line_Color: '#9c27b0',
            lineWidth: 1,
            lineStyle: 2,
        };
        this.paramDefs = [
            {
                key: 'Theme_Mode',
                label: 'Color Theme Mode',
                type: 'select',
                default: 'dark',
                options: [
                    { label: 'Dark Theme', value: 'dark' },
                    { label: 'Light Theme', value: 'light' },
                ],
            },
            {
                key: 'Banner_Position',
                label: 'Top Status Banner Position',
                type: 'select',
                default: 'top-right',
                options: [
                    { label: 'Top Right (Default)', value: 'top-right' },
                    { label: 'Top Center', value: 'top-center' },
                    { label: 'Bottom Left', value: 'bottom-left' },
                    { label: 'Bottom Right', value: 'bottom-right' },
                    { label: 'Top Left', value: 'top-left' },
                    { label: 'Hide Banner', value: 'hide' },
                ],
            },
            {
                key: 'Dashboard_Position',
                label: 'Dashboard Table Position',
                type: 'select',
                default: 'bottom-right',
                options: [
                    { label: 'Bottom Right (Default)', value: 'bottom-right' },
                    { label: 'Top Right', value: 'top-right' },
                    { label: 'Bottom Left', value: 'bottom-left' },
                    { label: 'Top Left', value: 'top-left' },
                ],
            },
            {
                key: 'Show_Dashboard',
                label: '[SMC] Show Dashboard Table',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'Price_Digits',
                label: 'Price Decimal Digits',
                type: 'select',
                default: -1,
                options: [
                    { label: 'Auto-Detect (Asset Precision)', value: -1 },
                    { label: '0 Digits (Indices/Crypto)', value: 0 },
                    { label: '1 Digit', value: 1 },
                    { label: '2 Digits (Gold/Stocks)', value: 2 },
                    { label: '3 Digits (JPY Pairs)', value: 3 },
                    { label: '4 Digits', value: 4 },
                    { label: '5 Digits (FX Majors)', value: 5 },
                    { label: '6 Digits', value: 6 },
                ],
            },
            {
                key: 'showLevelLines',
                label: '[Levels] Master Show Price Levels',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showDayLevels',
                label: '[Levels] Show H / L / YH / YL',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showVwapLevels',
                label: '[Levels] Show VWAP & ±2σ',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showPocLevels',
                label: '[Levels] Show DPOC / WPOC / MPOC',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showAdrLevels',
                label: '[Levels] Show O / ADR_H / ADR_L',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showRsiPredictor',
                label: '[Levels] Show RSI 70 / 30 Target Price',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'sessionMode',
                label: '[Session] Daily Cutoff Timezone',
                type: 'select',
                default: 'forex_gold',
                options: [
                    { label: 'Gold / Forex (17:00 NY / UTC+2)', value: 'forex_gold' },
                    { label: 'Thai Market / TFEX (UTC+7)', value: 'bkk' },
                    { label: 'Crypto (00:00 UTC)', value: 'utc' },
                    { label: 'Custom Hour Offset', value: 'custom' },
                ],
            },
            {
                key: 'customOffsetHours',
                label: '[Session] Custom Offset Hours',
                type: 'number',
                default: 2,
                min: -12,
                max: 14,
                step: 1,
            },
            {
                key: 'showDivRsi',
                label: '[RSI] Show Divergence Markers (R-Div/H-Div)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'lenRSI',
                label: '[RSI] Calculation Length',
                type: 'number',
                default: 14,
                min: 2,
                max: 100,
                step: 1,
            },
            {
                key: 'lbLeft',
                label: '[RSI] Divergence Lookback Left',
                type: 'number',
                default: 5,
                min: 2,
                max: 25,
                step: 1,
            },
            {
                key: 'lbRight',
                label: '[RSI] Divergence Lookback Right',
                type: 'number',
                default: 5,
                min: 2,
                max: 25,
                step: 1,
            },
            {
                key: 'Swing_Length',
                label: '[SMC] Swing Length (Min 3)',
                type: 'number',
                default: 5,
                min: 3,
                max: 50,
                step: 1,
            },
            {
                key: 'Sweep_min_atr',
                label: '[SMC] Sweep Min ATR Mult',
                type: 'number',
                default: 0.15,
                min: 0.05,
                max: 2.0,
                step: 0.05,
            },
            {
                key: 'Disp_min_atr',
                label: '[SMC] Displacement Min ATR Mult',
                type: 'number',
                default: 0.5,
                min: 0.1,
                max: 3.0,
                step: 0.1,
            },
            {
                key: 'Z_max_age',
                label: '[SMC] Zone Max Age (H1 Bars)',
                type: 'number',
                default: 40,
                min: 5,
                max: 250,
                step: 5,
            },
            {
                key: 'Z_max_size_atr',
                label: '[SMC] Zone Max Size ATR Mult',
                type: 'number',
                default: 1.5,
                min: 0.3,
                max: 5.0,
                step: 0.1,
            },
            {
                key: 'Show_FVG',
                label: '[SMC] Show Fair Value Gaps (FVG)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'Show_OB',
                label: '[SMC] Show Order Blocks (OB)',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'buffer_atr_mult',
                label: '[SMC] SL Buffer ATR Mult',
                type: 'number',
                default: 0.3,
                min: 0.05,
                max: 2.0,
                step: 0.05,
            },
            {
                key: 'RR_min',
                label: '[SMC] Minimum Reward/Risk (RR)',
                type: 'number',
                default: 1.5,
                min: 0.5,
                max: 10.0,
                step: 0.25,
            },
            {
                key: 'Show_SL_TP',
                label: '[SMC] Show Suggested Entry / SL / TP',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'Show_Labels',
                label: '[SMC] Show Zone & Bias Labels',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'showSignals',
                label: '[SMC] Show Sweep & Structure Markers',
                type: 'select',
                default: 1,
                options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }],
            },
            {
                key: 'Zone_Transparency',
                label: 'Zone Transparency (%)',
                type: 'number',
                default: 85,
                min: 20,
                max: 95,
                step: 5,
            },
            {
                key: 'Enable_Alerts',
                label: 'Enable Real-Time Alerts',
                type: 'select',
                default: 1,
                options: [{ label: 'Enabled', value: 1 }, { label: 'Disabled', value: 0 }],
            },
            { key: 'Bull_OB_Color', label: 'Bullish OB Color', type: 'color', default: '#00e676' },
            { key: 'Bear_OB_Color', label: 'Bearish OB Color', type: 'color', default: '#ff5252' },
            { key: 'Bull_FVG_Color', label: 'Bullish FVG Color', type: 'color', default: '#26a69a' },
            { key: 'Bear_FVG_Color', label: 'Bearish FVG Color', type: 'color', default: '#ef5350' },
            { key: 'Eq_Line_Color', label: 'H4 Equilibrium Line Color', type: 'color', default: '#9c27b0' },
        ];
    }
    getRawBars() {
        return this._rawBars;
    }
    setSymbol(symbol) {
        if (symbol && symbol !== this._symbol) {
            this._symbol = symbol;
            this._htfCache.clear();
        }
    }
    setSource(source) {
        if (source && source !== this._source) {
            this._source = source;
            this._htfCache.clear();
        }
    }
    async fetchHTFBars(symbol, apiTf, fallbackBars) {
        const periodSeconds = apiTf === 'H4' ? 14400 : 3600;
        const effectiveSymbol = symbol || this._symbol || (this.engine && this.engine.symbol) || '';
        const effectiveSource = this._source || (this.engine && this.engine.source) || 'default';
        if (effectiveSymbol && typeof fetch === 'function') {
            const cacheKey = `${effectiveSymbol}_${apiTf}_${effectiveSource}`;
            const cached = this._htfCache.get(cacheKey);
            const now = Date.now();
            if (cached && now - cached.timestamp < 45000 && cached.bars.length > 0) {
                return cached.bars;
            }
            try {
                const url = `/api/bars?symbol=${encodeURIComponent(effectiveSymbol)}&timeframe=${encodeURIComponent(apiTf)}&count=1000&source=${encodeURIComponent(effectiveSource)}`;
                const resp = await fetch(url);
                if (resp && resp.ok) {
                    const json = await resp.json();
                    const rawList = Array.isArray(json)
                        ? json
                        : Array.isArray(json?.bars)
                            ? json.bars
                            : Array.isArray(json?.data)
                                ? json.data
                                : [];
                    if (rawList.length > 10) {
                        const parsed = rawList
                            .map((b) => ({
                            time: Number(b.time),
                            open: Number(b.open),
                            high: Number(b.high),
                            low: Number(b.low),
                            close: Number(b.close),
                            volume: b.volume !== undefined ? Number(b.volume) : 0,
                        }))
                            .filter((b) => isFinite(b.time) &&
                            isFinite(b.open) &&
                            isFinite(b.high) &&
                            isFinite(b.low) &&
                            isFinite(b.close))
                            .sort((a, b) => a.time - b.time);
                        if (parsed.length > 10) {
                            this._htfCache.set(cacheKey, { timestamp: now, bars: parsed });
                            return parsed;
                        }
                    }
                }
            }
            catch (_err) { }
        }
        return MathUtils.resampleBars(fallbackBars, periodSeconds);
    }
    refreshRealtimeLevels() {
        const bars = this._rawBars;
        if (!bars || bars.length < 30)
            return;
        const n = bars.length;
        const lastBar = bars[n - 1];
        const closes = bars.map((b) => b.close);
        const tc = MathUtils.getThemePalette(String(this.params.Theme_Mode || 'dark'));
        const levels = [];
        // 1. Session-Anchored VWAP
        if (Number(this.params.showVwapLevels) === 1) {
            const lastSec = MathUtils.getBarTimeSec(lastBar.time);
            const lastDate = MathUtils.getAdjustedDate(lastSec, this.params.sessionMode, this.params.customOffsetHours);
            const todayKey = `${lastDate.getUTCFullYear()}-${lastDate.getUTCMonth() + 1}-${lastDate.getUTCDate()}`;
            let todayStartIdx = n - 1;
            while (todayStartIdx > 0) {
                const prevSec = MathUtils.getBarTimeSec(bars[todayStartIdx - 1].time);
                const prevDate = MathUtils.getAdjustedDate(prevSec, this.params.sessionMode, this.params.customOffsetHours);
                const prevKey = `${prevDate.getUTCFullYear()}-${prevDate.getUTCMonth() + 1}-${prevDate.getUTCDate()}`;
                if (prevKey !== todayKey)
                    break;
                todayStartIdx--;
            }
            let cumVol = 0;
            let cumCloseVol = 0;
            for (let i = todayStartIdx; i < n; i++) {
                const v = bars[i].volume && (bars[i].volume || 0) > 0 ? (bars[i].volume || 1) : 1;
                cumVol += v;
                cumCloseVol += bars[i].close * v;
            }
            const vwapBasis = cumVol > 0 ? cumCloseVol / cumVol : closes[n - 1];
            let devSqVol = 0;
            for (let i = todayStartIdx; i < n; i++) {
                const v = bars[i].volume && (bars[i].volume || 0) > 0 ? (bars[i].volume || 1) : 1;
                devSqVol += Math.pow(bars[i].close - vwapBasis, 2) * v;
            }
            const vwapStdev = cumVol > 0 ? Math.sqrt(devSqVol / cumVol) : 0;
            levels.push({ label: 'VWAP', price: vwapBasis, color: tc.vwapColor, lineStyle: 0, lineWidth: 2 });
            levels.push({ label: 'VWAP +2σ', price: vwapBasis + vwapStdev * 2, color: tc.vwapBandColor, lineStyle: 2, lineWidth: 1 });
            levels.push({ label: 'VWAP -2σ', price: vwapBasis - vwapStdev * 2, color: tc.vwapBandColor, lineStyle: 2, lineWidth: 1 });
        }
        // 2. Day Structure (H, L, YH, YL, O, ADR)
        const st = this._staticLevels;
        if (Number(this.params.showDayLevels) === 1 && st.todayOpen !== undefined) {
            const liveDayHigh = Math.max(st.todayHigh || -Infinity, lastBar.high);
            const liveDayLow = Math.min(st.todayLow || Infinity, lastBar.low);
            levels.push({ label: 'H', price: liveDayHigh, color: tc.hlColor, lineStyle: 2, lineWidth: 1.5 });
            levels.push({ label: 'L', price: liveDayLow, color: tc.hlColor, lineStyle: 2, lineWidth: 1.5 });
            if (st.yh !== undefined) {
                levels.push({ label: 'YH', price: st.yh, color: tc.yhlColor, lineStyle: 2, lineWidth: 1 });
                levels.push({ label: 'YL', price: st.yl, color: tc.yhlColor, lineStyle: 2, lineWidth: 1 });
            }
        }
        if (Number(this.params.showPocLevels) === 1 && st.dpoc) {
            levels.push({ label: 'DPOC', price: st.dpoc, color: tc.dpocColor, lineStyle: 0, lineWidth: 2 });
            levels.push({ label: 'WPOC', price: st.wpoc, color: tc.wpocColor, lineStyle: 0, lineWidth: 2 });
            levels.push({ label: 'MPOC', price: st.mpoc, color: tc.mpocColor, lineStyle: 0, lineWidth: 2 });
        }
        if (Number(this.params.showAdrLevels) === 1 && st.todayOpen !== undefined) {
            levels.push({ label: 'O', price: st.todayOpen, color: tc.adrColor, lineStyle: 2, lineWidth: 1 });
            if (st.adrVal) {
                levels.push({ label: 'ADR_H', price: st.todayOpen + st.adrVal, color: tc.adrColor, lineStyle: 2, lineWidth: 1 });
                levels.push({ label: 'ADR_L', price: st.todayOpen - st.adrVal, color: tc.adrColor, lineStyle: 2, lineWidth: 1 });
            }
        }
        // 3. RSI Predictor Realtime Targets
        if (Number(this.params.showRsiPredictor) === 1 && this._rmaUp.length > 0) {
            const pUp = this._rmaUp[this._rmaUp.length - 1];
            const pDown = this._rmaDown[this._rmaDown.length - 1];
            const curClose = lastBar.close;
            const len = Number(this.params.lenRSI) || 14;
            const price70 = MathUtils.predictRsiPrice(Number(this.params.obLevel) || 70, curClose, pUp, pDown, len);
            const price30 = MathUtils.predictRsiPrice(Number(this.params.osLevel) || 30, curClose, pUp, pDown, len);
            levels.push({ label: `RSI ${this.params.obLevel}`, price: price70, color: tc.rsiObColor, lineStyle: 2, lineWidth: 1 });
            levels.push({ label: `RSI ${this.params.osLevel}`, price: price30, color: tc.rsiOsColor, lineStyle: 2, lineWidth: 1 });
        }
        this.computedLevels = levels;
    }
    async calculate(bars, symbolOrParams) {
        if (!bars || !Array.isArray(bars) || bars.length === 0) {
            this.cachedData = [];
            this.cachedMarkers = [];
            this.computedLevels = [];
            return [];
        }
        if (typeof symbolOrParams === 'string' && symbolOrParams.trim() !== '') {
            this.setSymbol(symbolOrParams);
        }
        else if (symbolOrParams && typeof symbolOrParams === 'object') {
            this.params = { ...this.params, ...symbolOrParams };
        }
        const cleanBars = bars
            .filter((b) => b &&
            isFinite(b.time) &&
            isFinite(b.open) &&
            isFinite(b.high) &&
            isFinite(b.low) &&
            isFinite(b.close))
            .sort((a, b) => a.time - b.time);
        this._rawBars = cleanBars;
        const n = cleanBars.length;
        if (n < 20) {
            this.cachedData = [];
            this.cachedMarkers = [];
            return [];
        }
        const effectiveSymbol = this._symbol || (this.engine && this.engine.symbol) || '';
        const digits = MathUtils.detectPricePrecision(cleanBars, effectiveSymbol, Number(this.params.Price_Digits ?? -1), this.engine);
        const [h4Bars, h1Bars] = await Promise.all([
            this.fetchHTFBars(effectiveSymbol, 'H4', cleanBars),
            this.fetchHTFBars(effectiveSymbol, 'H1', cleanBars),
        ]);
        const prevSnap = this.latestSnapshot;
        const snapshot = StateManager.evaluateMarketState(cleanBars, h4Bars.length >= 10 ? h4Bars : cleanBars, h1Bars.length >= 10 ? h1Bars : cleanBars, this.params, digits, prevSnap);
        this.latestSnapshot = snapshot;
        const swingLen = Math.max(3, Number(this.params.Swing_Length) || 5);
        const sweepMin = Number(this.params.Sweep_min_atr) || 0.15;
        const dispMin = Number(this.params.Disp_min_atr) || 0.5;
        const m15Trig = TriggerDetector.evaluateM15Triggers(cleanBars, snapshot.h4Bias, snapshot.primaryZone, swingLen, sweepMin, dispMin);
        const eqValue = snapshot.h4Equilibrium;
        const seriesData = [];
        let lastTime = -Infinity;
        for (let i = 0; i < cleanBars.length; i++) {
            const t = cleanBars[i].time;
            if (t <= lastTime)
                continue;
            const val = eqValue !== null && isFinite(eqValue) ? eqValue : cleanBars[i].close;
            if (isFinite(val)) {
                seriesData.push({ time: t, value: val });
                lastTime = t;
            }
        }
        this.cachedData = seriesData;
        const closes = cleanBars.map((b) => b.close);
        const rsiLen = Number(this.params.lenRSI) || 14;
        const { rsi, rmaUp, rmaDown } = MathUtils.calculateRSI(closes, rsiLen);
        this._rmaUp = rmaUp;
        this._rmaDown = rmaDown;
        const daysMap = new Map();
        const weeksMap = new Map();
        const monthsMap = new Map();
        for (let i = 0; i < n; i++) {
            const sec = MathUtils.getBarTimeSec(cleanBars[i].time);
            const d = MathUtils.getAdjustedDate(sec, this.params.sessionMode, this.params.customOffsetHours);
            const dayKey = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
            if (!daysMap.has(dayKey)) {
                daysMap.set(dayKey, { open: cleanBars[i].open, high: cleanBars[i].high, low: cleanBars[i].low, close: cleanBars[i].close });
            }
            else {
                const item = daysMap.get(dayKey);
                item.high = Math.max(item.high, cleanBars[i].high);
                item.low = Math.min(item.low, cleanBars[i].low);
                item.close = cleanBars[i].close;
            }
            const dayNum = d.getUTCDay() || 7;
            const mondaySec = sec - (dayNum - 1) * 86400;
            const monDate = MathUtils.getAdjustedDate(mondaySec, this.params.sessionMode, this.params.customOffsetHours);
            const weekKey = `${monDate.getUTCFullYear()}-W${String(monDate.getUTCMonth() + 1).padStart(2, '0')}-${String(monDate.getUTCDate()).padStart(2, '0')}`;
            if (!weeksMap.has(weekKey)) {
                weeksMap.set(weekKey, { high: cleanBars[i].high, low: cleanBars[i].low, close: cleanBars[i].close });
            }
            else {
                const w = weeksMap.get(weekKey);
                w.high = Math.max(w.high, cleanBars[i].high);
                w.low = Math.min(w.low, cleanBars[i].low);
                w.close = cleanBars[i].close;
            }
            const monthKey = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
            if (!monthsMap.has(monthKey)) {
                monthsMap.set(monthKey, { high: cleanBars[i].high, low: cleanBars[i].low, close: cleanBars[i].close });
            }
            else {
                const m = monthsMap.get(monthKey);
                m.high = Math.max(m.high, cleanBars[i].high);
                m.low = Math.min(m.low, cleanBars[i].low);
                m.close = cleanBars[i].close;
            }
        }
        const days = Array.from(daysMap.values());
        const weeks = Array.from(weeksMap.values());
        const months = Array.from(monthsMap.values());
        const today = days[days.length - 1];
        const yesterday = days.length >= 2 ? days[days.length - 2] : today;
        const prevWeek = weeks.length >= 2 ? weeks[weeks.length - 2] : weeks[0];
        const prevMonth = months.length >= 2 ? months[months.length - 2] : months[0];
        let sumRange = 0;
        let cnt = 0;
        for (let i = days.length - 2; i >= 0 && cnt < 14; i--) {
            sumRange += days[i].high - days[i].low;
            cnt++;
        }
        const adrVal = cnt > 0 ? sumRange / cnt : today.high - today.low;
        this._staticLevels = {
            todayOpen: today.open,
            todayHigh: today.high,
            todayLow: today.low,
            yh: days.length >= 2 ? yesterday.high : undefined,
            yl: days.length >= 2 ? yesterday.low : undefined,
            dpoc: (yesterday.high + yesterday.low + yesterday.close) / 3.0,
            wpoc: (prevWeek.high + prevWeek.low + prevWeek.close) / 3.0,
            mpoc: (prevMonth.high + prevMonth.low + prevMonth.close) / 3.0,
            adrVal: adrVal,
        };
        this.refreshRealtimeLevels();
        const palette = MathUtils.getThemePalette(String(this.params.Theme_Mode || 'dark'));
        const markerMap = new Map();
        // 1. SMC Markers
        if (Number(this.params.showSignals) === 1) {
            for (const sw of m15Trig.sweeps.slice(-25)) {
                markerMap.set(sw.time, {
                    time: sw.time,
                    position: sw.direction === 'BULLISH' ? 'belowBar' : 'aboveBar',
                    color: palette.accentGold,
                    shape: sw.direction === 'BULLISH' ? 'arrowUp' : 'arrowDown',
                    text: `SWEEP (${sw.penetrationAtr.toFixed(2)}x ATR)`,
                });
            }
            for (const ev of m15Trig.events.slice(-25)) {
                const isChoch = ev.type === 'CHOCH';
                markerMap.set(ev.time, {
                    time: ev.time,
                    position: ev.direction === 'BULLISH' ? 'belowBar' : 'aboveBar',
                    color: ev.direction === 'BULLISH' ? palette.bullText : palette.bearText,
                    shape: isChoch
                        ? ev.direction === 'BULLISH'
                            ? 'arrowUp'
                            : 'arrowDown'
                        : 'circle',
                    text: isChoch
                        ? ev.sweptPrior
                            ? 'CHoCH + Sweep'
                            : 'CHoCH'
                        : 'BOS',
                });
            }
            if (snapshot.state === 'TRIGGER_READY' && snapshot.m15TriggerEvent) {
                const tTime = snapshot.m15TriggerEvent.time;
                markerMap.set(tTime, {
                    time: tTime,
                    position: snapshot.h4Bias === 'BULLISH' ? 'belowBar' : 'aboveBar',
                    color: palette.bullText,
                    shape: snapshot.h4Bias === 'BULLISH' ? 'arrowUp' : 'arrowDown',
                    text: `TRIGGER READY (${snapshot.h4Bias})`,
                });
            }
        }
        // 2. RSI Divergence Markers
        if (Number(this.params.showDivRsi) === 1 && rsi.length >= rsiLen + 10) {
            const lbL = Number(this.params.lbLeft) || 5;
            const lbR = Number(this.params.lbRight) || 5;
            let prevPlLow = null;
            let prevPlRsi = null;
            let prevPhHigh = null;
            let prevPhRsi = null;
            for (let i = lbL + lbR; i < n; i++) {
                const pivotIdx = i - lbR;
                const pivotRsi = rsi[pivotIdx];
                let isPh = true;
                let isPl = true;
                for (let k = pivotIdx - lbL; k <= pivotIdx + lbR; k++) {
                    if (k !== pivotIdx) {
                        if (rsi[k] >= pivotRsi)
                            isPh = false;
                        if (rsi[k] <= pivotRsi)
                            isPl = false;
                    }
                }
                const pivotTime = cleanBars[pivotIdx].time;
                const pivotLow = cleanBars[pivotIdx].low;
                const pivotHigh = cleanBars[pivotIdx].high;
                if (isPl) {
                    if (prevPlLow !== null && prevPlRsi !== null) {
                        if (pivotLow < prevPlLow && pivotRsi > prevPlRsi) {
                            markerMap.set(pivotTime, {
                                time: pivotTime,
                                position: 'belowBar',
                                color: palette.bullText,
                                shape: 'arrowUp',
                                text: 'R-Div',
                            });
                        }
                        else if (pivotLow > prevPlLow && pivotRsi < prevPlRsi) {
                            markerMap.set(pivotTime, {
                                time: pivotTime,
                                position: 'belowBar',
                                color: palette.bullText,
                                shape: 'arrowUp',
                                text: 'H-Div',
                            });
                        }
                    }
                    prevPlLow = pivotLow;
                    prevPlRsi = pivotRsi;
                }
                if (isPh) {
                    if (prevPhHigh !== null && prevPhRsi !== null) {
                        if (pivotHigh > prevPhHigh && pivotRsi < prevPhRsi) {
                            markerMap.set(pivotTime, {
                                time: pivotTime,
                                position: 'aboveBar',
                                color: palette.bearText,
                                shape: 'arrowDown',
                                text: 'R-Div',
                            });
                        }
                        else if (pivotHigh < prevPhHigh && pivotRsi > prevPhRsi) {
                            markerMap.set(pivotTime, {
                                time: pivotTime,
                                position: 'aboveBar',
                                color: palette.bearText,
                                shape: 'arrowDown',
                                text: 'H-Div',
                            });
                        }
                    }
                    prevPhHigh = pivotHigh;
                    prevPhRsi = pivotRsi;
                }
            }
        }
        this.cachedMarkers = Array.from(markerMap.values()).sort((a, b) => a.time - b.time);
        if (Number(this.params.Enable_Alerts) !== 0 &&
            snapshot.alertsFired.length > 0) {
            this.dispatchAlerts(snapshot.alertsFired, snapshot);
        }
        return this.cachedData;
    }
    dispatchAlerts(messages, snapshot) {
        for (const msg of messages) {
            if (this.engine && typeof this.engine.triggerAlert === 'function') {
                this.engine.triggerAlert({
                    indicatorId: this.id,
                    indicatorName: this.name,
                    state: snapshot.state,
                    message: msg,
                    time: snapshot.time,
                });
            }
            else if (typeof window !== 'undefined' &&
                typeof window.dispatchEvent === 'function') {
                window.dispatchEvent(new CustomEvent('quantdeck:indicator-alert', {
                    detail: {
                        indicatorId: this.id,
                        indicatorName: this.name,
                        state: snapshot.state,
                        message: msg,
                        snapshot,
                    },
                }));
            }
        }
    }
    ensurePrimitiveAttached() {
        if (!this.engine || typeof this.engine.getMainSeries !== 'function')
            return;
        const mainSeries = this.engine.getMainSeries();
        if (!mainSeries)
            return;
        if (!this._primitive) {
            this._primitive = new SMCCanvasPrimitive(this);
        }
        if (this._attachedMainSeries !== mainSeries) {
            if (this._attachedMainSeries &&
                typeof this._attachedMainSeries.detachPrimitive === 'function') {
                try {
                    this._attachedMainSeries.detachPrimitive(this._primitive);
                }
                catch (_e) { }
            }
            if (typeof mainSeries.attachPrimitive === 'function') {
                mainSeries.attachPrimitive(this._primitive);
                this._attachedMainSeries = mainSeries;
            }
        }
    }
    render(engine, _onSettings, _onClose) {
        this.engine = engine;
        if (!engine || !engine.chart)
            return;
        const scalePos = typeof engine.getPriceScalePosition === 'function'
            ? engine.getPriceScalePosition()
            : 'right';
        const digits = this.latestSnapshot ? this.latestSnapshot.digits : 5;
        const minMove = Number(Math.pow(10, -digits).toFixed(digits));
        this.series = engine.chart.addLineSeries({
            priceScaleId: scalePos,
            color: String(this.params.Eq_Line_Color || '#9c27b0'),
            lineWidth: Number(this.params.lineWidth) || 1,
            lineStyle: Number(this.params.lineStyle ?? 2),
            visible: this.isVisible && Number(this.params.Show_Labels) !== 0,
            lastValueVisible: false,
            priceLineVisible: false,
            crosshairMarkerVisible: false,
            title: 'H4 EQ (50%)',
            priceFormat: {
                type: 'price',
                precision: digits,
                minMove,
            },
        });
        this.ensurePrimitiveAttached();
        if (this.cachedData && this.cachedData.length > 0) {
            this.setData(this.cachedData);
        }
    }
    setData(data) {
        if (this.series && Array.isArray(data)) {
            if (this.latestSnapshot) {
                const digits = this.latestSnapshot.digits;
                const minMove = Number(Math.pow(10, -digits).toFixed(digits));
                this.series.applyOptions({
                    priceFormat: {
                        type: 'price',
                        precision: digits,
                        minMove,
                    },
                });
            }
            this.series.setData(data);
        }
        this.ensurePrimitiveAttached();
        this.applyMarkers();
        this._primitive?.requestUpdate();
    }
    async update(bar) {
        if (!bar || !isFinite(bar.time))
            return;
        const n = this._rawBars.length;
        let isNewBarClosed = false;
        if (n === 0) {
            this._rawBars.push({ ...bar });
        }
        else {
            const lastBar = this._rawBars[n - 1];
            if (bar.time > lastBar.time) {
                this._rawBars.push({ ...bar });
                isNewBarClosed = true;
            }
            else if (bar.time === lastBar.time) {
                this._rawBars[n - 1] = { ...bar };
            }
        }
        if (isNewBarClosed || !this.latestSnapshot) {
            const data = await this.calculate(this._rawBars, this._symbol);
            this.setData(data);
        }
        else {
            if (this.series && this.cachedData.length > 0) {
                const eqVal = this.latestSnapshot.h4Equilibrium !== null
                    ? this.latestSnapshot.h4Equilibrium
                    : bar.close;
                this.series.update({ time: bar.time, value: eqVal });
            }
            this.refreshRealtimeLevels();
            this._primitive?.requestUpdate();
        }
    }
    async updateParams(newParams, engine) {
        this.params = { ...this.params, ...newParams };
        if (engine)
            this.engine = engine;
        if (this.series) {
            this.series.applyOptions({
                color: String(this.params.Eq_Line_Color || '#9c27b0'),
                lineWidth: Number(this.params.lineWidth) || 1,
                lineStyle: Number(this.params.lineStyle ?? 2),
                visible: this.isVisible && Number(this.params.Show_Labels) !== 0,
            });
        }
        const bars = this.engine &&
            Array.isArray(this.engine.allBars) &&
            this.engine.allBars.length > 0
            ? this.engine.allBars
            : this._rawBars;
        if (bars && bars.length > 0) {
            const data = await this.calculate(bars, this._symbol);
            this.setData(data);
        }
        else {
            this.refreshRealtimeLevels();
            this.applyMarkers();
            this._primitive?.requestUpdate();
        }
    }
    setVisible(visible) {
        this.isVisible = visible !== false;
        if (this.series) {
            this.series.applyOptions({
                visible: this.isVisible && Number(this.params.Show_Labels) !== 0,
            });
        }
        if (!this.isVisible) {
            this.clearMarkers();
        }
        else {
            this.applyMarkers();
        }
        this._primitive?.requestUpdate();
    }
    destroy(engine) {
        const eng = engine || this.engine;
        this.clearMarkers();
        if (this._primitive) {
            const mainSeries = this._attachedMainSeries ||
                (eng && typeof eng.getMainSeries === 'function'
                    ? eng.getMainSeries()
                    : null);
            if (mainSeries && typeof mainSeries.detachPrimitive === 'function') {
                try {
                    mainSeries.detachPrimitive(this._primitive);
                }
                catch (_e) { }
            }
            this._primitive = null;
            this._attachedMainSeries = null;
        }
        if (this.series &&
            eng &&
            eng.chart &&
            typeof eng.chart.removeSeries === 'function') {
            try {
                eng.chart.removeSeries(this.series);
            }
            catch (_e) { }
            this.series = null;
        }
    }
    applyMarkers() {
        if (!this.engine || !this.isVisible) {
            this.clearMarkers();
            return;
        }
        if (typeof this.engine.setIndicatorMarkers === 'function') {
            this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries && typeof mainSeries.setMarkers === 'function') {
            mainSeries.setMarkers(this.cachedMarkers || []);
        }
    }
    clearMarkers() {
        if (!this.engine)
            return;
        if (typeof this.engine.clearIndicatorMarkers === 'function') {
            this.engine.clearIndicatorMarkers(this.id);
            return;
        }
    }
}
export default SMC3LayerIndicator;

