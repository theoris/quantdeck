// @ts-sha256: d1022b5e5ea0d04df4323339959476f894bca37244acd1216a4d727eaee80b9f
/**
 * QuantDeck Custom Indicator: 3-Layer Smart Money Concepts (H4 -> H1 -> M15) v3.1 (v2 Refinement)
 * File: SMC_3Layer_Indicator_v3.ts
 * Placement: custom_indicators/
 *
 * Refinements in v2:
 * 1. Dynamic Asset Price Precision (Auto-detects 5 digits for EURUSD/FX, 3 for JPY, 2 for Gold/Indices, or manual override)
 * 2. Light / Dark Theme Support (High-contrast typography, adaptive panel backgrounds, borders, and label pills)
 * 3. Configurable Positions for Top Banner Pill (Default: Top-Right to avoid top-left asset/indicator legend collision)
 *    and Decision Dashboard Table.
 */
// ============================================================================
// 1. PURE MODULAR DETECTION PIPELINE & PRECISION / THEME HELPERS
// ============================================================================
class MathUtils {
    static computeATR(bars, period = 14) {
        const n = bars.length;
        if (n === 0)
            return [];
        const tr = new Array(n).fill(0);
        const atr = new Array(n).fill(0);
        for (let i = 0; i < n; i++) {
            const high = bars[i].high;
            const low = bars[i].low;
            if (i === 0) {
                tr[i] = Math.max(high - low, 1e-8);
            }
            else {
                const prevClose = bars[i - 1].close;
                tr[i] = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose), 1e-8);
            }
        }
        let sum = 0;
        for (let i = 0; i < n; i++) {
            if (i < period) {
                sum += tr[i];
                atr[i] = sum / (i + 1);
            }
            else {
                atr[i] = (atr[i - 1] * (period - 1) + tr[i]) / period;
            }
        }
        return atr;
    }
    static resampleBars(bars, periodSeconds) {
        if (!bars || bars.length === 0)
            return [];
        const result = [];
        let currentBucket = null;
        for (let i = 0; i < bars.length; i++) {
            const b = bars[i];
            const bucketTime = Math.floor(b.time / periodSeconds) * periodSeconds;
            if (!currentBucket || currentBucket.time !== bucketTime) {
                if (currentBucket)
                    result.push(currentBucket);
                currentBucket = {
                    time: bucketTime,
                    open: b.open,
                    high: b.high,
                    low: b.low,
                    close: b.close,
                    volume: b.volume || 0,
                };
            }
            else {
                if (b.high > currentBucket.high)
                    currentBucket.high = b.high;
                if (b.low < currentBucket.low)
                    currentBucket.low = b.low;
                currentBucket.close = b.close;
                currentBucket.volume = (currentBucket.volume || 0) + (b.volume || 0);
            }
        }
        if (currentBucket)
            result.push(currentBucket);
        return result;
    }
    static hexToRgba(hex, alpha) {
        const cleaned = (hex || '#2962ff').replace('#', '').trim();
        let r = 41, g = 98, b = 255;
        if (cleaned.length === 3) {
            r = parseInt(cleaned[0] + cleaned[0], 16);
            g = parseInt(cleaned[1] + cleaned[1], 16);
            b = parseInt(cleaned[2] + cleaned[2], 16);
        }
        else if (cleaned.length >= 6) {
            r = parseInt(cleaned.substring(0, 2), 16);
            g = parseInt(cleaned.substring(2, 4), 16);
            b = parseInt(cleaned.substring(4, 6), 16);
        }
        const clampedAlpha = Math.max(0, Math.min(1, isFinite(alpha) ? alpha : 0.2));
        return `rgba(${isNaN(r) ? 41 : r}, ${isNaN(g) ? 98 : g}, ${isNaN(b) ? 255 : b}, ${clampedAlpha.toFixed(3)})`;
    }
    /**
     * Automatically detects optimal decimal precision (digits) from:
     * 1. Manual override parameter (`Price_Digits >= 0`)
     * 2. Engine / Series priceFormat (`minMove` or `precision`)
     * 3. Symbol naming conventions (EURUSD -> 5, USDJPY -> 3, XAUUSD -> 2)
     * 4. Actual OHLC bar decimal inspection + price magnitude heuristics
     */
    static detectPricePrecision(bars, symbol = '', manualDigits = -1, engine) {
        if (manualDigits !== undefined && manualDigits !== null && Number(manualDigits) >= 0) {
            return Math.min(8, Math.max(0, Math.floor(Number(manualDigits))));
        }
        // 1. Check ChartEngine or MainSeries priceFormat if available
        if (engine) {
            if (typeof engine.getPricePrecision === 'function') {
                const p = engine.getPricePrecision();
                if (typeof p === 'number' && isFinite(p) && p >= 0 && p <= 8)
                    return p;
            }
            if (typeof engine.decimals === 'number' && engine.decimals >= 0) {
                return engine.decimals;
            }
            if (typeof engine.getMainSeries === 'function') {
                try {
                    const mainSeries = engine.getMainSeries();
                    const opts = mainSeries && typeof mainSeries.options === 'function' ? mainSeries.options() : null;
                    if (opts && opts.priceFormat) {
                        if (typeof opts.priceFormat.precision === 'number' && opts.priceFormat.precision >= 0) {
                            return opts.priceFormat.precision;
                        }
                        if (typeof opts.priceFormat.minMove === 'number' && opts.priceFormat.minMove > 0) {
                            const mm = opts.priceFormat.minMove;
                            const digitsFromMinMove = Math.max(0, Math.round(-Math.log10(mm)));
                            if (isFinite(digitsFromMinMove) && digitsFromMinMove <= 8) {
                                return digitsFromMinMove;
                            }
                        }
                    }
                }
                catch (_e) { }
            }
        }
        // 2. Check Symbol conventions
        const sym = (symbol || '').toUpperCase();
        if (sym) {
            if (sym.includes('XAU') || sym.includes('GOLD') || sym.includes('XAG')) {
                // Still inspect bars in case XAG has 3 digits
            }
            else if (sym.includes('JPY')) {
                return 3;
            }
            else if (/^(EUR|GBP|AUD|NZD|USD|CAD|CHF)(EUR|GBP|AUD|NZD|USD|CAD|CHF)$/.test(sym.replace(/[^A-Z]/g, '').substring(0, 6))) {
                return 5;
            }
        }
        // 3. Inspect last 100 OHLC bar values for decimal places
        let maxDecimals = 0;
        const sampleStart = Math.max(0, bars.length - 100);
        for (let i = sampleStart; i < bars.length; i++) {
            const b = bars[i];
            if (!b)
                continue;
            const vals = [b.open, b.high, b.low, b.close];
            for (const v of vals) {
                if (!isFinite(v))
                    continue;
                // Convert avoiding scientific notation for standard ranges
                const s = v.toFixed(8).replace(/0+$/, '');
                const dotIdx = s.indexOf('.');
                if (dotIdx !== -1) {
                    const decLen = s.length - dotIdx - 1;
                    if (decLen > maxDecimals)
                        maxDecimals = decLen;
                }
            }
        }
        if (maxDecimals > 0) {
            const lastClose = bars.length > 0 ? Math.abs(bars[bars.length - 1].close) : 100;
            // Ensure standard FX pairs (0.4 < price < 2.5) with 4+ decimals show 5 digits
            if (lastClose > 0.3 && lastClose < 3.0 && maxDecimals >= 4) {
                return Math.max(5, maxDecimals);
            }
            return Math.min(8, maxDecimals);
        }
        // 4. Magnitude fallback
        const refPrice = bars.length > 0 ? Math.abs(bars[bars.length - 1].close) : 100;
        if (refPrice === 0)
            return 2;
        if (refPrice < 0.01)
            return 6;
        if (refPrice < 3.0)
            return 5;
        if (refPrice < 200.0 && sym.includes('JPY'))
            return 3;
        return 2;
    }
    static formatPrice(price, digits) {
        if (price === null || price === undefined || !isFinite(price))
            return '—';
        const d = Math.max(0, Math.min(8, Math.floor(digits)));
        return price.toFixed(d);
    }
    static getThemePalette(themeMode) {
        const isLight = String(themeMode).toLowerCase() === 'light';
        if (isLight) {
            return {
                isLight: true,
                panelBg: 'rgba(255, 255, 255, 0.96)',
                panelHeaderBgAlpha: 0.18,
                panelBorder: '#cbd5e1',
                rowAltBg: 'rgba(15, 23, 42, 0.04)',
                textPrimary: '#0f172a',
                textSecondary: '#334155',
                textMuted: '#64748b',
                pillBg: 'rgba(255, 255, 255, 0.95)',
                pillText: '#0f172a',
                zoneLabelBg: 'rgba(255, 255, 255, 0.88)',
                zoneLabelText: '#0f172a',
                zoneMitigatedText: '#64748b',
                eqLineStroke: 'rgba(126, 34, 206, 0.75)',
                eqText: '#6b21a8',
                bullText: '#047857', // Deep Emerald for crisp readability on light background
                bearText: '#b91c1c', // Deep Crimson for crisp readability on light background
                neutralText: '#475569',
                warnText: '#991b1b',
                accentGold: '#b45309', // Dark Amber for Entry / Active POI on light chart
                accentCyan: '#0369a1', // Deep Ocean Blue for Action Guidance
                tp2Color: '#0284c7',
            };
        }
        return {
            isLight: false,
            panelBg: 'rgba(15, 23, 42, 0.94)',
            panelHeaderBgAlpha: 0.28,
            panelBorder: '#334155',
            rowAltBg: 'rgba(255, 255, 255, 0.04)',
            textPrimary: '#f8fafc',
            textSecondary: '#cbd5e1',
            textMuted: '#94a3b8',
            pillBg: 'rgba(15, 23, 42, 0.92)',
            pillText: '#f8fafc',
            zoneLabelBg: 'rgba(15, 23, 42, 0.82)',
            zoneLabelText: '#f8fafc',
            zoneMitigatedText: '#94a3b8',
            eqLineStroke: 'rgba(192, 132, 252, 0.70)',
            eqText: '#e9d5ff',
            bullText: '#34d399', // Bright Mint Green on dark background
            bearText: '#f87171', // Soft Coral Red on dark background
            neutralText: '#94a3b8',
            warnText: '#fca5a5',
            accentGold: '#fbbf24', // Warm Gold on dark chart
            accentCyan: '#38bdf8', // Sky Cyan on dark chart
            tp2Color: '#38bdf8',
        };
    }
}
class StructureDetector {
    static detectConfirmedSwings(bars, swingLength) {
        const len = Math.max(3, Math.floor(swingLength || 5));
        const swings = [];
        const lastClosedIdx = bars.length - 2;
        if (lastClosedIdx < len * 2)
            return swings;
        for (let confirmIdx = len * 2; confirmIdx <= lastClosedIdx; confirmIdx++) {
            const pivotIdx = confirmIdx - len;
            const candidateHigh = bars[pivotIdx].high;
            const candidateLow = bars[pivotIdx].low;
            let isSwingHigh = true;
            let isSwingLow = true;
            for (let k = pivotIdx - len; k <= pivotIdx + len; k++) {
                if (k === pivotIdx)
                    continue;
                if (bars[k].high > candidateHigh)
                    isSwingHigh = false;
                if (bars[k].low < candidateLow)
                    isSwingLow = false;
                if (!isSwingHigh && !isSwingLow)
                    break;
            }
            if (isSwingHigh) {
                swings.push({
                    index: pivotIdx,
                    ConfirmIndex: confirmIdx,
                    time: bars[pivotIdx].time,
                    confirmTime: bars[confirmIdx].time,
                    price: candidateHigh,
                    type: 'HIGH',
                });
            }
            if (isSwingLow) {
                swings.push({
                    index: pivotIdx,
                    ConfirmIndex: confirmIdx,
                    time: bars[pivotIdx].time,
                    confirmTime: bars[confirmIdx].time,
                    price: candidateLow,
                    type: 'LOW',
                });
            }
        }
        return swings;
    }
    static evaluateStructure(bars, swingLength, sweepMinAtr, upToTimestamp) {
        const len = Math.max(3, Math.floor(swingLength || 5));
        const atr = MathUtils.computeATR(bars, 14);
        const events = [];
        const sweeps = [];
        let bias = 'NEUTRAL';
        let activeSwingHigh = null;
        let activeSwingLow = null;
        let brokenHighIdx = -1;
        let brokenLowIdx = -1;
        let recentBearishSweep = false;
        let recentBullishSweep = false;
        const maxIdx = bars.length - 2; // Closed bars only
        for (let i = len * 2; i <= maxIdx; i++) {
            const bar = bars[i];
            if (upToTimestamp !== undefined && bar.time > upToTimestamp)
                break;
            const pivotIdx = i - len;
            let isHigh = true;
            let isLow = true;
            for (let k = pivotIdx - len; k <= pivotIdx + len; k++) {
                if (k === pivotIdx)
                    continue;
                if (bars[k].high > bars[pivotIdx].high)
                    isHigh = false;
                if (bars[k].low < bars[pivotIdx].low)
                    isLow = false;
            }
            if (isHigh) {
                activeSwingHigh = {
                    index: pivotIdx,
                    ConfirmIndex: i,
                    time: bars[pivotIdx].time,
                    confirmTime: bar.time,
                    price: bars[pivotIdx].high,
                    type: 'HIGH',
                };
            }
            if (isLow) {
                activeSwingLow = {
                    index: pivotIdx,
                    ConfirmIndex: i,
                    time: bars[pivotIdx].time,
                    confirmTime: bar.time,
                    price: bars[pivotIdx].low,
                    type: 'LOW',
                };
            }
            const curAtr = atr[i] || 1e-8;
            if (activeSwingHigh && activeSwingHigh.index !== brokenHighIdx) {
                const pen = bar.high - activeSwingHigh.price;
                if (pen >= sweepMinAtr * curAtr && bar.close <= activeSwingHigh.price) {
                    sweeps.push({
                        time: bar.time,
                        barIndex: i,
                        direction: 'BEARISH',
                        swingPrice: activeSwingHigh.price,
                        wickExtreme: bar.high,
                        penetrationAtr: pen / curAtr,
                    });
                    recentBearishSweep = true;
                }
            }
            if (activeSwingLow && activeSwingLow.index !== brokenLowIdx) {
                const pen = activeSwingLow.price - bar.low;
                if (pen >= sweepMinAtr * curAtr && bar.close >= activeSwingLow.price) {
                    sweeps.push({
                        time: bar.time,
                        barIndex: i,
                        direction: 'BULLISH',
                        swingPrice: activeSwingLow.price,
                        wickExtreme: bar.low,
                        penetrationAtr: pen / curAtr,
                    });
                    recentBullishSweep = true;
                }
            }
            if (activeSwingHigh &&
                activeSwingHigh.index !== brokenHighIdx &&
                bar.close > activeSwingHigh.price) {
                const type = bias === 'BULLISH' ? 'BOS' : 'CHOCH';
                events.push({
                    time: bar.time,
                    barIndex: i,
                    type,
                    direction: 'BULLISH',
                    level: activeSwingHigh.price,
                    sweptPrior: recentBullishSweep,
                });
                bias = 'BULLISH';
                brokenHighIdx = activeSwingHigh.index;
                recentBullishSweep = false;
            }
            else if (activeSwingLow &&
                activeSwingLow.index !== brokenLowIdx &&
                bar.close < activeSwingLow.price) {
                const type = bias === 'BEARISH' ? 'BOS' : 'CHOCH';
                events.push({
                    time: bar.time,
                    barIndex: i,
                    type,
                    direction: 'BEARISH',
                    level: activeSwingLow.price,
                    sweptPrior: recentBearishSweep,
                });
                bias = 'BEARISH';
                brokenLowIdx = activeSwingLow.index;
                recentBearishSweep = false;
            }
        }
        return {
            bias,
            events,
            sweeps,
            lastSwingHigh: activeSwingHigh,
            lastSwingLow: activeSwingLow,
        };
    }
}
class ZoneDetector {
    static detectH1Zones(h1Bars, params) {
        const n = h1Bars.length;
        if (n < 5)
            return { activeZones: [], recentlyMitigatedZones: [], h1Atr: 0 };
        const atr = MathUtils.computeATR(h1Bars, 14);
        const allZones = [];
        const lastClosedIdx = n - 2;
        for (let i = 2; i <= lastClosedIdx; i++) {
            const curAtr = atr[i] || 1e-8;
            const b0 = h1Bars[i];
            const b1 = h1Bars[i - 1];
            const b2 = h1Bars[i - 2];
            if (params.showFVG) {
                const body1 = Math.abs(b1.close - b1.open);
                if (b0.low > b2.high && b1.close > b1.open && body1 >= params.dispMinAtr * curAtr) {
                    const top = b0.low;
                    const bottom = b2.high;
                    const sizeAtr = (top - bottom) / curAtr;
                    if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                        allZones.push({
                            id: `FVG_BULL_${b1.time}`,
                            type: 'FVG',
                            direction: 'BULLISH',
                            top,
                            bottom,
                            entryEdge: top,
                            farSide: bottom,
                            createdTime: b1.time,
                            confirmedTime: b0.time,
                            createdH1Index: i,
                            mitigated: false,
                            sizeAtr,
                            qualityScore: Math.min(100, Math.round((body1 / curAtr) * 50)),
                        });
                    }
                }
                if (b0.high < b2.low && b1.close < b1.open && body1 >= params.dispMinAtr * curAtr) {
                    const top = b2.low;
                    const bottom = b0.high;
                    const sizeAtr = (top - bottom) / curAtr;
                    if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                        allZones.push({
                            id: `FVG_BEAR_${b1.time}`,
                            type: 'FVG',
                            direction: 'BEARISH',
                            top,
                            bottom,
                            entryEdge: bottom,
                            farSide: top,
                            createdTime: b1.time,
                            confirmedTime: b0.time,
                            createdH1Index: i,
                            mitigated: false,
                            sizeAtr,
                            qualityScore: Math.min(100, Math.round((body1 / curAtr) * 50)),
                        });
                    }
                }
            }
            if (params.showOB) {
                const dispBody = Math.abs(b0.close - b0.open);
                const isBullDisp = b0.close > b0.open && dispBody >= params.dispMinAtr * curAtr && b0.close > b1.high;
                const isBearDisp = b0.close < b0.open && dispBody >= params.dispMinAtr * curAtr && b0.close < b1.low;
                if (isBullDisp) {
                    let obCandle = null;
                    for (let lookback = 1; lookback <= 3 && i - lookback >= 0; lookback++) {
                        const cand = h1Bars[i - lookback];
                        if (cand.close < cand.open) {
                            obCandle = cand;
                            break;
                        }
                    }
                    if (obCandle) {
                        const top = obCandle.high;
                        const bottom = obCandle.low;
                        const sizeAtr = (top - bottom) / curAtr;
                        if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                            allZones.push({
                                id: `OB_BULL_${obCandle.time}`,
                                type: 'OB',
                                direction: 'BULLISH',
                                top,
                                bottom,
                                entryEdge: top,
                                farSide: bottom,
                                createdTime: obCandle.time,
                                confirmedTime: b0.time,
                                createdH1Index: i,
                                mitigated: false,
                                sizeAtr,
                                qualityScore: Math.min(100, Math.round((dispBody / curAtr) * 60)),
                            });
                        }
                    }
                }
                if (isBearDisp) {
                    let obCandle = null;
                    for (let lookback = 1; lookback <= 3 && i - lookback >= 0; lookback++) {
                        const cand = h1Bars[i - lookback];
                        if (cand.close > cand.open) {
                            obCandle = cand;
                            break;
                        }
                    }
                    if (obCandle) {
                        const top = obCandle.high;
                        const bottom = obCandle.low;
                        const sizeAtr = (top - bottom) / curAtr;
                        if (sizeAtr > 0.05 && sizeAtr <= params.zMaxSizeAtr) {
                            allZones.push({
                                id: `OB_BEAR_${obCandle.time}`,
                                type: 'OB',
                                direction: 'BEARISH',
                                top,
                                bottom,
                                entryEdge: bottom,
                                farSide: top,
                                createdTime: obCandle.time,
                                confirmedTime: b0.time,
                                createdH1Index: i,
                                mitigated: false,
                                sizeAtr,
                                qualityScore: Math.min(100, Math.round((dispBody / curAtr) * 60)),
                            });
                        }
                    }
                }
            }
            for (const z of allZones) {
                if (z.mitigated || i <= z.createdH1Index)
                    continue;
                if (z.direction === 'BULLISH' && b0.close < z.farSide) {
                    z.mitigated = true;
                    z.mitigatedTime = b0.time;
                }
                else if (z.direction === 'BEARISH' && b0.close > z.farSide) {
                    z.mitigated = true;
                    z.mitigatedTime = b0.time;
                }
            }
        }
        const activeZones = [];
        const recentlyMitigatedZones = [];
        for (const z of allZones) {
            const ageBars = lastClosedIdx - z.createdH1Index;
            if (!z.mitigated && ageBars <= params.zMaxAge) {
                activeZones.push(z);
            }
            else if (z.mitigated && ageBars <= Math.min(12, params.zMaxAge)) {
                recentlyMitigatedZones.push(z);
            }
        }
        return {
            activeZones,
            recentlyMitigatedZones,
            h1Atr: atr[lastClosedIdx] || atr[atr.length - 1] || 0,
        };
    }
}
class TriggerDetector {
    static evaluateM15Triggers(m15Bars, bias, primaryZone, swingLength, sweepMinAtr, dispMinAtr) {
        const struct = StructureDetector.evaluateStructure(m15Bars, swingLength, sweepMinAtr);
        const atrArr = MathUtils.computeATR(m15Bars, 14);
        const lastClosedIdx = Math.max(0, m15Bars.length - 2);
        const m15Atr = atrArr[lastClosedIdx] || 1e-8;
        let latestValidSweep = null;
        let latestTriggerChoch;
        latestTriggerChoch = null;
        let strongDisplacementAfterZone = false;
        const targetDir = bias === 'BULLISH' ? 'BULLISH' : bias === 'BEARISH' ? 'BEARISH' : null;
        if (!targetDir) {
            return {
                events: struct.events,
                sweeps: struct.sweeps,
                latestValidSweep: null,
                latestTriggerChoch: null,
                strongDisplacementAfterZone: false,
                m15Atr,
            };
        }
        const lookbackStartIdx = Math.max(0, lastClosedIdx - 15);
        const lookbackStartTime = m15Bars[lookbackStartIdx]?.time || 0;
        for (let i = struct.sweeps.length - 1; i >= 0; i--) {
            const sw = struct.sweeps[i];
            if (sw.time < lookbackStartTime)
                break;
            if (sw.direction === targetDir) {
                latestValidSweep = sw;
                break;
            }
        }
        for (let i = struct.events.length - 1; i >= 0; i--) {
            const ev = struct.events[i];
            if (ev.time < lookbackStartTime)
                break;
            if (ev.direction === targetDir && (ev.type === 'CHOCH' || ev.sweptPrior)) {
                if (latestValidSweep && ev.barIndex >= latestValidSweep.barIndex) {
                    latestTriggerChoch = ev;
                    break;
                }
                else if (ev.sweptPrior) {
                    latestTriggerChoch = ev;
                    break;
                }
            }
        }
        if (primaryZone) {
            for (let i = Math.max(1, lastClosedIdx - 2); i <= lastClosedIdx; i++) {
                const b = m15Bars[i];
                const prev = m15Bars[i - 1];
                const body = Math.abs(b.close - b.open);
                const curAtr = atrArr[i] || m15Atr;
                if (targetDir === 'BULLISH' &&
                    (b.low <= primaryZone.top || prev.low <= primaryZone.top) &&
                    b.close > b.open &&
                    body >= dispMinAtr * curAtr * 1.25) {
                    strongDisplacementAfterZone = true;
                }
                else if (targetDir === 'BEARISH' &&
                    (b.high >= primaryZone.bottom || prev.high >= primaryZone.bottom) &&
                    b.close < b.open &&
                    body >= dispMinAtr * curAtr * 1.25) {
                    strongDisplacementAfterZone = true;
                }
            }
        }
        return {
            events: struct.events,
            sweeps: struct.sweeps,
            latestValidSweep,
            latestTriggerChoch,
            strongDisplacementAfterZone,
            m15Atr,
        };
    }
}
class StateManager {
    static evaluateMarketState(m15Bars, h4Bars, h1Bars, params, digits, previousSnapshot) {
        const swingLength = Number(params.Swing_Length) || 5;
        const sweepMinAtr = Number(params.Sweep_min_atr) || 0.15;
        const dispMinAtr = Number(params.Disp_min_atr) || 0.5;
        const zMaxAge = Number(params.Z_max_age) || 40;
        const zMaxSizeAtr = Number(params.Z_max_size_atr) || 1.5;
        const showFVG = Number(params.Show_FVG) !== 0;
        const showOB = Number(params.Show_OB) !== 0;
        const bufferAtrMult = Number(params.buffer_atr_mult) || 0.3;
        const rrMin = Number(params.RR_min) || 1.5;
        const isLight = String(params.Theme_Mode || 'dark').toLowerCase() === 'light';
        const lastClosedM15Idx = Math.max(0, m15Bars.length - 2);
        const currentBar = m15Bars[lastClosedM15Idx] || m15Bars[m15Bars.length - 1];
        const currentPrice = currentBar ? currentBar.close : 0;
        const currentTime = currentBar ? currentBar.time : 0;
        // 1. H4 Bias & Premium/Discount Range
        const h4Struct = StructureDetector.evaluateStructure(h4Bars, swingLength, sweepMinAtr);
        const h4Bias = h4Struct.bias;
        const h4High = h4Struct.lastSwingHigh ? h4Struct.lastSwingHigh.price : null;
        const h4Low = h4Struct.lastSwingLow ? h4Struct.lastSwingLow.price : null;
        let h4Equilibrium = null;
        let pdZone = 'NA';
        let pdPercent = 50;
        if (h4High !== null && h4Low !== null && h4High > h4Low) {
            h4Equilibrium = (h4High + h4Low) * 0.5;
            pdPercent = ((currentPrice - h4Low) / (h4High - h4Low)) * 100;
            if (pdPercent >= 47.5 && pdPercent <= 52.5) {
                pdZone = 'EQUILIBRIUM';
            }
            else if (pdPercent < 47.5) {
                pdZone = 'DISCOUNT';
            }
            else {
                pdZone = 'PREMIUM';
            }
        }
        // 2. H1 Zones Detection & Selection
        const h1ZoneResult = ZoneDetector.detectH1Zones(h1Bars, {
            dispMinAtr,
            zMaxAge,
            zMaxSizeAtr,
            showFVG,
            showOB,
        });
        const alignedZones = h1ZoneResult.activeZones.filter((z) => (h4Bias === 'BULLISH' && z.direction === 'BULLISH') ||
            (h4Bias === 'BEARISH' && z.direction === 'BEARISH'));
        alignedZones.sort((a, b) => {
            const distA = currentPrice >= a.bottom && currentPrice <= a.top
                ? 0
                : Math.min(Math.abs(currentPrice - a.top), Math.abs(currentPrice - a.bottom));
            const distB = currentPrice >= b.bottom && currentPrice <= b.top
                ? 0
                : Math.min(Math.abs(currentPrice - b.top), Math.abs(currentPrice - b.bottom));
            return distA - distB;
        });
        const primaryZone = alignedZones.length > 0 ? alignedZones[0] : null;
        let isPriceInZone = false;
        let touchedZoneRecently = false;
        if (primaryZone) {
            isPriceInZone = currentPrice >= primaryZone.bottom && currentPrice <= primaryZone.top;
            for (let k = Math.max(0, lastClosedM15Idx - 6); k <= lastClosedM15Idx; k++) {
                const b = m15Bars[k];
                if (b && b.low <= primaryZone.top && b.high >= primaryZone.bottom) {
                    touchedZoneRecently = true;
                    break;
                }
            }
        }
        // 3. M15 Trigger Detection
        const m15Trig = TriggerDetector.evaluateM15Triggers(m15Bars, h4Bias, primaryZone, swingLength, sweepMinAtr, dispMinAtr);
        // 4. Warning Conditions
        const warnings = [];
        const m15AtrArr = MathUtils.computeATR(m15Bars, 14);
        const recentAtr = m15AtrArr[lastClosedM15Idx] || 0;
        let avgAtr50 = 0;
        const startAtrIdx = Math.max(0, lastClosedM15Idx - 50);
        const countAtr = lastClosedM15Idx - startAtrIdx + 1;
        for (let k = startAtrIdx; k <= lastClosedM15Idx; k++) {
            avgAtr50 += m15AtrArr[k] || 0;
        }
        avgAtr50 = countAtr > 0 ? avgAtr50 / countAtr : recentAtr;
        if (avgAtr50 > 0 && recentAtr < avgAtr50 * 0.45) {
            warnings.push('Low Volatility (ATR Compression)');
        }
        const utcHour = new Date(currentTime * 1000).getUTCHours();
        if (utcHour === 21 || utcHour === 22) {
            warnings.push('Session End / Rollover Window');
        }
        const latestH1ClosedTime = h1Bars.length >= 2 ? h1Bars[h1Bars.length - 2].time : 0;
        const justMitigatedZone = h1ZoneResult.recentlyMitigatedZones.find((z) => z.mitigatedTime === latestH1ClosedTime &&
            ((h4Bias === 'BULLISH' && z.direction === 'BULLISH') ||
                (h4Bias === 'BEARISH' && z.direction === 'BEARISH')));
        // 5. Risk Levels (Entry, SL, TP1, TP2, RR)
        let suggestedEntry = null;
        let suggestedSL = null;
        let suggestedTP1 = null;
        let suggestedTP2 = null;
        let currentRR = null;
        const riskAtr = h1ZoneResult.h1Atr > 0 ? h1ZoneResult.h1Atr : recentAtr * 2;
        if (primaryZone && h4Bias !== 'NEUTRAL') {
            const isTriggerConfirmed = Boolean(m15Trig.latestTriggerChoch && (isPriceInZone || touchedZoneRecently));
            suggestedEntry = isTriggerConfirmed ? currentPrice : primaryZone.entryEdge;
            if (h4Bias === 'BULLISH') {
                const slBase = m15Trig.latestValidSweep
                    ? Math.min(primaryZone.farSide, m15Trig.latestValidSweep.wickExtreme)
                    : primaryZone.farSide;
                suggestedSL = slBase - bufferAtrMult * riskAtr;
                const risk = Math.max(Math.abs(suggestedEntry - suggestedSL), 1e-8);
                suggestedTP1 =
                    h4High && h4High > suggestedEntry + risk * rrMin
                        ? h4High
                        : suggestedEntry + risk * rrMin;
                suggestedTP2 = suggestedEntry + risk * Math.max(rrMin * 1.6, 2.5);
                currentRR = (suggestedTP1 - suggestedEntry) / risk;
            }
            else if (h4Bias === 'BEARISH') {
                const slBase = m15Trig.latestValidSweep
                    ? Math.max(primaryZone.farSide, m15Trig.latestValidSweep.wickExtreme)
                    : primaryZone.farSide;
                suggestedSL = slBase + bufferAtrMult * riskAtr;
                const risk = Math.max(Math.abs(suggestedSL - suggestedEntry), 1e-8);
                suggestedTP1 =
                    h4Low && h4Low < suggestedEntry - risk * rrMin
                        ? h4Low
                        : suggestedEntry - risk * rrMin;
                suggestedTP2 = suggestedEntry - risk * Math.max(rrMin * 1.6, 2.5);
                currentRR = (suggestedEntry - suggestedTP1) / risk;
            }
        }
        // 6. State Machine with Theme-Aware High-Contrast State Colors
        let state = 'NO_TRADE';
        let stateMessage = 'NO TRADE - Neutral Bias';
        let stateColor = isLight ? '#475569' : '#94a3b8'; // Gray
        let actionGuidance = 'Stay out';
        let entryGuidance = 'No Trade';
        const hasValidTrigger = Boolean(m15Trig.latestTriggerChoch && (isPriceInZone || touchedZoneRecently));
        if (h4Bias === 'NEUTRAL') {
            state = 'NO_TRADE';
            stateMessage = 'NO TRADE - Neutral Bias';
            stateColor = isLight ? '#475569' : '#94a3b8';
            actionGuidance = 'Stay out';
            entryGuidance = 'No Trade';
        }
        else if (justMitigatedZone && !primaryZone) {
            state = 'INVALID';
            stateMessage = 'INVALID - Zone Mitigated';
            stateColor = isLight ? '#dc2626' : '#f87171'; // Red
            actionGuidance = 'Cancel pending orders';
            entryGuidance = 'No Trade';
        }
        else if (warnings.length > 0 && !hasValidTrigger) {
            state = 'WARNING';
            stateMessage = 'WARNING - Poor Conditions';
            stateColor = isLight ? '#991b1b' : '#ef4444'; // Dark Red
            actionGuidance = 'Avoid new entries';
            entryGuidance = warnings[0];
        }
        else if (!primaryZone) {
            state = 'BIAS_ONLY';
            stateMessage = 'BIAS ONLY - Waiting for Zone';
            stateColor = isLight ? '#1d4ed8' : '#60a5fa'; // Blue
            actionGuidance = 'Monitor for new POI';
            entryGuidance = 'No Trade';
        }
        else if (hasValidTrigger) {
            state = 'TRIGGER_READY';
            stateMessage = 'TRIGGER - Confirm Entry';
            stateColor = isLight ? '#047857' : '#34d399'; // Green
            actionGuidance = 'Enter market (or confirm limit)';
            if (currentRR !== null && currentRR < rrMin) {
                entryGuidance = 'RR too low - Skip';
            }
            else {
                entryGuidance = 'Valid Trigger - Consider Market Entry';
            }
        }
        else if (isPriceInZone) {
            state = 'IN_ZONE';
            stateMessage = 'IN ZONE - Waiting for Trigger';
            stateColor = isLight ? '#c2410c' : '#fb923c'; // Orange
            actionGuidance = 'Watch for Sweep + CHoCH';
            if (m15Trig.strongDisplacementAfterZone) {
                entryGuidance = 'Momentum Play - Consider Stop Entry';
            }
            else {
                entryGuidance = 'Wait for Sweep + CHoCH close';
            }
        }
        else {
            state = 'ARMED';
            stateMessage = 'ARMED - Limit Zone Ready';
            stateColor = isLight ? '#b45309' : '#fbbf24'; // Yellow / Amber
            actionGuidance = 'Prepare limit order at zone edge';
            if (currentRR !== null && currentRR < rrMin) {
                entryGuidance = 'RR too low - Skip';
            }
            else if (m15Trig.strongDisplacementAfterZone && touchedZoneRecently) {
                entryGuidance = 'Momentum Play - Consider Stop Entry';
            }
            else {
                entryGuidance = 'Consider Limit at zone edge';
            }
        }
        // 7. Alerts (Formatted with accurate asset digits)
        const alertsFired = [];
        if (previousSnapshot) {
            if (previousSnapshot.h4Bias !== h4Bias) {
                alertsFired.push(`Bias Flip: H4 Bias changed to ${h4Bias}`);
            }
            if (primaryZone &&
                (!previousSnapshot.primaryZone || previousSnapshot.primaryZone.id !== primaryZone.id)) {
                alertsFired.push(`New Valid Zone Detected: H1 ${primaryZone.direction} ${primaryZone.type} (${MathUtils.formatPrice(primaryZone.bottom, digits)} - ${MathUtils.formatPrice(primaryZone.top, digits)})`);
            }
            if (state === 'IN_ZONE' && previousSnapshot.state !== 'IN_ZONE') {
                alertsFired.push(`Price Entered H1 ${primaryZone?.direction || ''} ${primaryZone?.type || 'Zone'}`);
            }
            if (state === 'TRIGGER_READY' && previousSnapshot.state !== 'TRIGGER_READY') {
                alertsFired.push(`Valid Trigger Confirmed: M15 Sweep + CHoCH (${h4Bias})`);
            }
            if (state === 'INVALID' && previousSnapshot.state !== 'INVALID') {
                alertsFired.push(`Zone Mitigated / Invalidated`);
            }
            if (state === 'WARNING' && previousSnapshot.state !== 'WARNING') {
                alertsFired.push(`Warning Condition: ${warnings.join(', ')}`);
            }
        }
        return {
            time: currentTime,
            close: currentPrice,
            digits,
            h4Bias,
            h4SwingHigh: h4High,
            h4SwingLow: h4Low,
            h4Equilibrium,
            pdZone,
            pdPercent,
            activeZones: h1ZoneResult.activeZones,
            mitigatedZones: h1ZoneResult.recentlyMitigatedZones.slice(-4),
            primaryZone,
            m15Sweep: m15Trig.latestValidSweep,
            m15TriggerEvent: m15Trig.latestTriggerChoch,
            strongDisplacementAfterZone: m15Trig.strongDisplacementAfterZone,
            state,
            stateMessage,
            stateColor,
            actionGuidance,
            entryGuidance,
            suggestedEntry,
            suggestedSL,
            suggestedTP1,
            suggestedTP2,
            currentRR,
            warnings,
            alertsFired,
        };
    }
}
// ============================================================================
// 2. CUSTOM CANVAS PRIMITIVE (ISeriesPrimitive for Zones, SL/TP & Dashboard)
// ============================================================================
class SMCCanvasPrimitive {
    constructor(indicator) {
        this._chart = null;
        this._series = null;
        this.indicator = indicator;
    }
    attached(param) {
        this._chart = param.chart;
        this._series = param.series;
        this._requestUpdate = param.requestUpdate;
    }
    detached() {
        this._chart = null;
        this._series = null;
        this._requestUpdate = undefined;
    }
    requestUpdate() {
        if (typeof this._requestUpdate === 'function') {
            this._requestUpdate();
        }
    }
    paneViews() {
        if (!this.indicator || this.indicator.isDestroyed || !this.indicator.isVisible)
            return [];
        const self = this;
        return [
            {
                zOrder() {
                    return 'normal';
                },
                renderer() {
                    return {
                        draw(target) {
                            if (!self.indicator || self.indicator.isDestroyed || !self.indicator.isVisible)
                                return;
                            if (typeof target.useMediaCoordinateSpace === 'function') {
                                target.useMediaCoordinateSpace(({ context, mediaSize }) => {
                                    self.drawOverlay(context, mediaSize.width, mediaSize.height, 1, 1);
                                });
                            }
                            else if (typeof target.useBitmapCoordinateSpace === 'function') {
                                target.useBitmapCoordinateSpace(({ context, bitmapSize, horizontalPixelRatio, verticalPixelRatio, }) => {
                                    self.drawOverlay(context, bitmapSize.width, bitmapSize.height, horizontalPixelRatio || 1, verticalPixelRatio || 1);
                                });
                            }
                        },
                    };
                },
            },
        ];
    }
    timeToX(time, fallbackRightEdge) {
        if (!this._chart)
            return null;
        const ts = this._chart.timeScale();
        if (!ts)
            return null;
        if (typeof ts.timeToCoordinate === 'function') {
            const coord = ts.timeToCoordinate(time);
            if (coord !== null && coord !== undefined && isFinite(coord))
                return Number(coord);
        }
        const bars = this.indicator.getRawBars();
        if (bars.length > 0 && typeof ts.logicalToCoordinate === 'function') {
            if (time <= bars[0].time) {
                const c0 = ts.logicalToCoordinate(0);
                if (c0 !== null && c0 !== undefined)
                    return Number(c0);
            }
            if (time >= bars[bars.length - 1].time) {
                const cLast = ts.logicalToCoordinate(bars.length - 1);
                if (cLast !== null && cLast !== undefined)
                    return Number(cLast);
                return fallbackRightEdge;
            }
            let lo = 0, hi = bars.length - 1;
            while (lo <= hi) {
                const mid = (lo + hi) >> 1;
                if (bars[mid].time < time)
                    lo = mid + 1;
                else
                    hi = mid - 1;
            }
            const coord = ts.logicalToCoordinate(lo);
            if (coord !== null && coord !== undefined && isFinite(coord))
                return Number(coord);
        }
        return null;
    }
    priceToY(price) {
        if (!this._series || typeof this._series.priceToCoordinate !== 'function')
            return null;
        const y = this._series.priceToCoordinate(price);
        if (y === null || y === undefined || !isFinite(y))
            return null;
        return Number(y);
    }
    /**
     * Draws a high-contrast text badge (pill) so labels remain crystal clear
     * over candlesticks in both Light and Dark themes.
     */
    drawTextTag(ctx, text, x, y, align, textColor, bgColor, borderColor, font = 'bold 10px sans-serif') {
        ctx.save();
        ctx.font = font;
        const padX = 6;
        const boxH = 16;
        const textW = ctx.measureText(text).width;
        const boxW = textW + padX * 2;
        const drawX = align === 'right' ? x - boxW : x;
        const drawY = y - boxH / 2;
        ctx.fillStyle = bgColor;
        ctx.beginPath();
        ctx.roundRect(drawX, drawY, boxW, boxH, 3);
        ctx.fill();
        if (borderColor) {
            ctx.strokeStyle = borderColor;
            ctx.lineWidth = 1;
            ctx.stroke();
        }
        ctx.fillStyle = textColor;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, drawX + padX, y);
        ctx.restore();
    }
    drawOverlay(ctx, width, height, hRatio, vRatio) {
        const snap = this.indicator.latestSnapshot;
        if (!snap || !this._series)
            return;
        ctx.save();
        if (hRatio !== 1 || vRatio !== 1) {
            ctx.scale(hRatio, vRatio);
            width = width / hRatio;
            height = height / vRatio;
        }
        const params = this.indicator.params;
        const palette = MathUtils.getThemePalette(String(params.Theme_Mode || 'dark'));
        const digits = snap.digits ?? 2;
        const transparency = Number(params.Zone_Transparency ?? 85);
        const baseAlpha = Math.max(0.06, Math.min(0.65, (100 - transparency) / 100));
        const fillAlpha = palette.isLight ? Math.min(0.65, baseAlpha * 1.25) : baseAlpha;
        const showLabels = Number(params.Show_Labels) !== 0;
        const showSLTP = Number(params.Show_SL_TP) !== 0;
        const showDashboard = Number(params.Show_Dashboard) !== 0;
        const bannerPos = String(params.Banner_Position || 'top-right');
        const dashboardPos = String(params.Dashboard_Position || 'bottom-right');
        const bars = this.indicator.getRawBars();
        const lastBarTime = bars.length > 0 ? bars[bars.length - 1].time : snap.time;
        const chartRightX = Math.min(width - 8, (this.timeToX(lastBarTime, width - 80) ?? width - 80) + 95);
        // 1. Draw H4 Equilibrium Line & Premium/Discount Reference
        if (snap.h4Equilibrium !== null &&
            snap.h4SwingHigh !== null &&
            snap.h4SwingLow !== null) {
            const yEq = this.priceToY(snap.h4Equilibrium);
            if (yEq !== null && yEq >= 0 && yEq <= height) {
                ctx.save();
                ctx.strokeStyle = palette.eqLineStroke;
                ctx.lineWidth = 1.25;
                ctx.setLineDash([4, 4]);
                ctx.beginPath();
                ctx.moveTo(Math.max(0, chartRightX - 280), yEq);
                ctx.lineTo(chartRightX, yEq);
                ctx.stroke();
                ctx.restore();
                if (showLabels) {
                    this.drawTextTag(ctx, `H4 EQ (50%): ${MathUtils.formatPrice(snap.h4Equilibrium, digits)} [${snap.pdZone}]`, chartRightX - 4, yEq - 10, 'right', palette.eqText, palette.zoneLabelBg, palette.eqLineStroke, 'bold 10px sans-serif');
                }
            }
        }
        // 2. Draw Active & Recently Mitigated H1 Zones (OB & FVG)
        const zonesToRender = [...snap.mitigatedZones, ...snap.activeZones];
        for (const z of zonesToRender) {
            const yTop = this.priceToY(z.top);
            const yBottom = this.priceToY(z.bottom);
            if (yTop === null || yBottom === null)
                continue;
            const xStartRaw = this.timeToX(z.createdTime, 40);
            const xStart = Math.max(0, xStartRaw !== null ? xStartRaw : 40);
            const xEnd = z.mitigated && z.mitigatedTime
                ? Math.min(chartRightX, this.timeToX(z.mitigatedTime, chartRightX) ?? chartRightX)
                : chartRightX;
            if (xEnd <= xStart)
                continue;
            const boxY = Math.min(yTop, yBottom);
            const boxH = Math.max(2, Math.abs(yBottom - yTop));
            const isPrimary = snap.primaryZone && snap.primaryZone.id === z.id;
            let baseColor = '#26a69a';
            if (z.direction === 'BULLISH') {
                baseColor =
                    z.type === 'OB'
                        ? String(params.Bull_OB_Color || '#00e676')
                        : String(params.Bull_FVG_Color || '#26a69a');
            }
            else {
                baseColor =
                    z.type === 'OB'
                        ? String(params.Bear_OB_Color || '#ff5252')
                        : String(params.Bear_FVG_Color || '#ef5350');
            }
            ctx.save();
            ctx.fillStyle = MathUtils.hexToRgba(baseColor, z.mitigated ? fillAlpha * 0.45 : isPrimary ? fillAlpha * 1.35 : fillAlpha);
            ctx.fillRect(xStart, boxY, xEnd - xStart, boxH);
            const strokeAlpha = z.mitigated ? 0.45 : isPrimary ? 0.95 : 0.75;
            ctx.strokeStyle = MathUtils.hexToRgba(baseColor, strokeAlpha);
            ctx.lineWidth = isPrimary ? 1.6 : 1.1;
            if (z.mitigated)
                ctx.setLineDash([3, 3]);
            ctx.strokeRect(xStart, boxY, xEnd - xStart, boxH);
            // Highlight Zone Entry Edge
            if (!z.mitigated && isPrimary) {
                const yEdge = this.priceToY(z.entryEdge);
                if (yEdge !== null) {
                    ctx.strokeStyle = palette.accentGold;
                    ctx.lineWidth = 2;
                    ctx.setLineDash([]);
                    ctx.beginPath();
                    ctx.moveTo(xStart, yEdge);
                    ctx.lineTo(xEnd, yEdge);
                    ctx.stroke();
                }
            }
            ctx.restore();
            // Zone Label Badge (High contrast for both Light & Dark themes)
            if (showLabels && xEnd - xStart > 55) {
                const statusTag = z.mitigated
                    ? ' [MITIGATED]'
                    : isPrimary
                        ? ' [ACTIVE POI]'
                        : '';
                const labelText = `H1 ${z.direction === 'BULLISH' ? 'Bull' : 'Bear'} ${z.type} (${MathUtils.formatPrice(z.bottom, digits)}-${MathUtils.formatPrice(z.top, digits)})${statusTag}`;
                const labelColor = z.mitigated
                    ? palette.zoneMitigatedText
                    : z.direction === 'BULLISH'
                        ? palette.bullText
                        : palette.bearText;
                this.drawTextTag(ctx, labelText, xStart + 5, boxY + 11, 'left', labelColor, palette.zoneLabelBg, MathUtils.hexToRgba(baseColor, z.mitigated ? 0.35 : 0.7), isPrimary ? 'bold 10px sans-serif' : '10px sans-serif');
            }
        }
        // 3. Draw Suggested Entry, Stop Loss & Take Profit Lines
        if (showSLTP &&
            snap.suggestedEntry !== null &&
            snap.suggestedSL !== null &&
            snap.suggestedTP1 !== null &&
            (snap.state === 'ARMED' ||
                snap.state === 'IN_ZONE' ||
                snap.state === 'TRIGGER_READY')) {
            const lineStartX = Math.max(40, chartRightX - 225);
            const drawLevelLine = (price, color, dash, label) => {
                const y = this.priceToY(price);
                if (y === null || y < 0 || y > height)
                    return;
                ctx.save();
                ctx.strokeStyle = color;
                ctx.lineWidth = 1.75;
                ctx.setLineDash(dash);
                ctx.beginPath();
                ctx.moveTo(lineStartX, y);
                ctx.lineTo(chartRightX, y);
                ctx.stroke();
                ctx.restore();
                if (showLabels) {
                    this.drawTextTag(ctx, `${label}: ${MathUtils.formatPrice(price, digits)}`, chartRightX - 4, y - 10, 'right', color, palette.zoneLabelBg, color, 'bold 10px sans-serif');
                }
            };
            drawLevelLine(snap.suggestedEntry, palette.accentGold, [], 'ENTRY');
            drawLevelLine(snap.suggestedSL, palette.bearText, [4, 3], 'SL');
            drawLevelLine(snap.suggestedTP1, palette.bullText, [4, 3], `TP1 (${snap.currentRR !== null ? snap.currentRR.toFixed(2) + 'R' : ''})`);
            if (snap.suggestedTP2 !== null) {
                drawLevelLine(snap.suggestedTP2, palette.tp2Color, [2, 3], 'TP2');
            }
        }
        // 4. Draw H4 Bias Status Banner Pill (Configurable position, default Top-Right)
        let bannerBottomY = 0;
        let bannerTopY = height;
        if (showLabels && bannerPos !== 'hide') {
            ctx.save();
            const biasColors = {
                BULLISH: palette.bullText,
                BEARISH: palette.bearText,
                NEUTRAL: palette.neutralText,
            };
            const badgeText = `H4 BIAS: ${snap.h4Bias}  |  ZONE: ${snap.pdZone} (${snap.pdPercent.toFixed(0)}%)  |  STATE: ${snap.stateMessage}`;
            ctx.font = 'bold 11px sans-serif';
            const textWidth = ctx.measureText(badgeText).width;
            const pillW = textWidth + 24;
            const pillH = 26;
            const margin = 14;
            let pillX = width - pillW - margin;
            let pillY = margin;
            if (bannerPos === 'top-center') {
                pillX = Math.max(margin, (width - pillW) / 2);
                pillY = margin;
            }
            else if (bannerPos === 'top-left') {
                pillX = margin;
                pillY = margin;
            }
            else if (bannerPos === 'bottom-left') {
                pillX = margin;
                pillY = Math.max(margin, height - pillH - margin);
            }
            else if (bannerPos === 'bottom-right') {
                pillX = Math.max(margin, width - pillW - margin);
                pillY = Math.max(margin, height - pillH - margin);
            }
            else {
                // Default: top-right
                pillX = Math.max(margin, width - pillW - margin);
                pillY = margin;
            }
            bannerBottomY = pillY + pillH;
            bannerTopY = pillY;
            ctx.fillStyle = palette.pillBg;
            ctx.strokeStyle = biasColors[snap.h4Bias];
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.roundRect(pillX, pillY, pillW, pillH, 6);
            ctx.fill();
            ctx.stroke();
            ctx.fillStyle = palette.pillText;
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(badgeText, pillX + 12, pillY + pillH / 2);
            ctx.restore();
        }
        // 5. Draw Compact SMC Decision Dashboard Table
        if (showDashboard) {
            this.drawDashboardTable(ctx, width, height, snap, palette, digits, Number(params.RR_min) || 1.5, dashboardPos, bannerPos, bannerBottomY, bannerTopY);
        }
        ctx.restore();
    }
    drawDashboardTable(ctx, width, height, snap, palette, digits, rrMin, dashboardPos, bannerPos, bannerBottomY, bannerTopY) {
        const tableW = 305;
        const rowH = 20;
        const headerH = 26;
        const rows = [
            {
                label: 'Current Bias (H4)',
                value: `${snap.h4Bias} (${snap.pdZone})`,
                color: snap.h4Bias === 'BULLISH'
                    ? palette.bullText
                    : snap.h4Bias === 'BEARISH'
                        ? palette.bearText
                        : palette.neutralText,
            },
            {
                label: 'Active Zone (H1)',
                value: snap.primaryZone
                    ? `${snap.primaryZone.direction} ${snap.primaryZone.type} (${snap.activeZones.length} active)`
                    : 'None Active',
                color: snap.primaryZone ? palette.accentGold : palette.textMuted,
            },
            {
                label: 'Trigger Status (M15)',
                value: snap.m15TriggerEvent
                    ? `Confirmed (${snap.m15TriggerEvent.type})`
                    : snap.m15Sweep
                        ? 'Sweep Done (Wait CHoCH)'
                        : 'Waiting for Sweep',
                color: snap.m15TriggerEvent
                    ? palette.bullText
                    : snap.m15Sweep
                        ? palette.accentGold
                        : palette.textMuted,
            },
            {
                label: 'Indicator State',
                value: snap.stateMessage,
                color: snap.stateColor,
            },
            {
                label: 'Suggested Entry',
                value: MathUtils.formatPrice(snap.suggestedEntry, digits),
                color: palette.textPrimary,
            },
            {
                label: 'Suggested SL',
                value: MathUtils.formatPrice(snap.suggestedSL, digits),
                color: palette.bearText,
            },
            {
                label: 'Suggested TP1',
                value: MathUtils.formatPrice(snap.suggestedTP1, digits),
                color: palette.bullText,
            },
            {
                label: 'Current RR',
                value: snap.currentRR !== null
                    ? `${snap.currentRR.toFixed(2)}R (Min ${rrMin}R)`
                    : '—',
                color: snap.currentRR !== null
                    ? snap.currentRR >= rrMin
                        ? palette.bullText
                        : palette.bearText
                    : palette.textMuted,
            },
            {
                label: 'Action Guidance',
                value: snap.actionGuidance,
                color: palette.accentCyan,
            },
            {
                label: 'Recommendation',
                value: snap.entryGuidance,
                color: snap.stateColor,
            },
        ];
        const tableH = headerH + rows.length * rowH + 8;
        const margin = 14;
        let x = Math.max(margin, width - tableW - margin);
        let y = Math.max(margin, height - tableH - margin);
        if (dashboardPos === 'top-right') {
            x = Math.max(margin, width - tableW - margin);
            y = bannerPos === 'top-right' && bannerBottomY > 0 ? bannerBottomY + 8 : margin;
        }
        else if (dashboardPos === 'bottom-left') {
            x = margin;
            y =
                bannerPos === 'bottom-left' && bannerTopY < height
                    ? Math.max(margin, bannerTopY - tableH - 8)
                    : Math.max(margin, height - tableH - margin);
        }
        else if (dashboardPos === 'top-left') {
            x = margin;
            y = bannerPos === 'top-left' && bannerBottomY > 0 ? bannerBottomY + 8 : margin;
        }
        else {
            // Default: bottom-right
            x = Math.max(margin, width - tableW - margin);
            y =
                bannerPos === 'bottom-right' && bannerTopY < height
                    ? Math.max(margin, bannerTopY - tableH - 8)
                    : Math.max(margin, height - tableH - margin);
        }
        ctx.save();
        // Panel Background
        ctx.fillStyle = palette.panelBg;
        ctx.strokeStyle = snap.stateColor || palette.panelBorder;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(x, y, tableW, tableH, 6);
        ctx.fill();
        ctx.stroke();
        // Header Bar
        ctx.fillStyle = MathUtils.hexToRgba(snap.stateColor || '#2962ff', palette.panelHeaderBgAlpha);
        ctx.beginPath();
        ctx.roundRect(x, y, tableW, headerH, [6, 6, 0, 0]);
        ctx.fill();
        ctx.font = 'bold 11px sans-serif';
        ctx.fillStyle = palette.textPrimary;
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(`SMC 3-LAYER DASHBOARD (${digits} Digits)`, x + 10, y + headerH / 2);
        // Table Rows
        for (let i = 0; i < rows.length; i++) {
            const r = rows[i];
            const ry = y + headerH + i * rowH;
            if (i % 2 === 1) {
                ctx.fillStyle = palette.rowAltBg;
                ctx.fillRect(x + 2, ry, tableW - 4, rowH);
            }
            ctx.font = '11px sans-serif';
            ctx.fillStyle = palette.textSecondary;
            ctx.textAlign = 'left';
            ctx.fillText(r.label, x + 10, ry + rowH / 2);
            ctx.font = 'bold 11px sans-serif';
            ctx.fillStyle = r.color || palette.textPrimary;
            ctx.textAlign = 'right';
            ctx.fillText(r.value, x + tableW - 10, ry + rowH / 2);
        }
        ctx.restore();
    }
}
// ============================================================================
// 3. MAIN QUANTDECK INDICATOR CLASS (IIndicator + Template Compatible)
// ============================================================================
export class SMC3LayerIndicator {
    constructor() {
        this.isVisible = true;
        this.engine = null;
        this.series = null;
        this._primitive = null;
        this._attachedMainSeries = null;
        this.isDestroyed = false;
        this.customFile = 'SMC_3Layer_Indicator_v3-v2.ts';
        this.isCustom = true;
        this._rawBars = [];
        this._symbol = '';
        this._source = 'default';
        this._htfCache = new Map();
        this.cachedData = [];
        this.cachedMarkers = [];
        this.latestSnapshot = null;
        this.id = `custom_ind_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        this.name = 'SMC 3-Layer (H4 -> H1 -> M15)';
        this.pane = 'main';
        this.description =
            '3-Layer Smart Money Concepts Decision-Support Indicator (H4 Bias, H1 OB/FVG Zones, M15 Sweep + CHoCH Triggers)';
        this.isVisible = true;
        // 1. Default Parameter Values
        this.params = {
            Theme_Mode: 'light',
            Banner_Position: 'top-right',
            Dashboard_Position: 'bottom-right',
            Show_Dashboard: 1,
            Price_Digits: -1, // -1 = Auto-detect from asset/bars
            Swing_Length: 5,
            Sweep_min_atr: 0.15,
            Disp_min_atr: 0.5,
            Z_max_age: 40,
            Z_max_size_atr: 1.5,
            Show_FVG: 1,
            Show_OB: 1,
            buffer_atr_mult: 0.3,
            RR_min: 1.5,
            Show_SL_TP: 1,
            Show_Labels: 1,
            showSignals: 1,
            Zone_Transparency: 85,
            Enable_Alerts: 1,
            Bull_OB_Color: '#00e676',
            Bear_OB_Color: '#ff5252',
            Bull_FVG_Color: '#26a69a',
            Bear_FVG_Color: '#ef5350',
            Eq_Line_Color: '#9c27b0',
            lineWidth: 1,
            lineStyle: 2, // 2 = Dashed
        };
        // 2. Settings Modal UI Definitions (English Labels Only)
        this.paramDefs = [
            {
                key: 'Theme_Mode',
                label: 'Color Theme Mode',
                type: 'select',
                default: 'dark',
                options: [
                    { label: 'Dark Theme', value: 'dark' },
                    { label: 'Light Theme', value: 'light' },
                ],
            },
            {
                key: 'Banner_Position',
                label: 'Top Status Banner Position',
                type: 'select',
                default: 'top-right',
                options: [
                    { label: 'Top Right (Default)', value: 'top-right' },
                    { label: 'Top Center', value: 'top-center' },
                    { label: 'Bottom Left', value: 'bottom-left' },
                    { label: 'Bottom Right', value: 'bottom-right' },
                    { label: 'Top Left', value: 'top-left' },
                    { label: 'Hide Banner', value: 'hide' },
                ],
            },
            {
                key: 'Dashboard_Position',
                label: 'Dashboard Table Position',
                type: 'select',
                default: 'bottom-right',
                options: [
                    { label: 'Bottom Right (Default)', value: 'bottom-right' },
                    { label: 'Top Right', value: 'top-right' },
                    { label: 'Bottom Left', value: 'bottom-left' },
                    { label: 'Top Left', value: 'top-left' },
                ],
            },
            {
                key: 'Show_Dashboard',
                label: 'Show SMC Dashboard Table',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show', value: 1 },
                    { label: 'Hide', value: 0 },
                ],
            },
            {
                key: 'Price_Digits',
                label: 'Price Decimal Digits',
                type: 'select',
                default: -1,
                options: [
                    { label: 'Auto-Detect (Asset Precision)', value: -1 },
                    { label: '0 Digits (Indices/Crypto)', value: 0 },
                    { label: '1 Digit', value: 1 },
                    { label: '2 Digits (Gold/Stocks)', value: 2 },
                    { label: '3 Digits (JPY Pairs)', value: 3 },
                    { label: '4 Digits', value: 4 },
                    { label: '5 Digits (FX Majors)', value: 5 },
                    { label: '6 Digits', value: 6 },
                ],
            },
            {
                key: 'Swing_Length',
                label: 'Swing Length (Min 3)',
                type: 'number',
                default: 5,
                min: 3,
                max: 50,
                step: 1,
            },
            {
                key: 'Sweep_min_atr',
                label: 'Sweep Min ATR Mult',
                type: 'number',
                default: 0.15,
                min: 0.05,
                max: 2.0,
                step: 0.05,
            },
            {
                key: 'Disp_min_atr',
                label: 'Displacement Min ATR Mult',
                type: 'number',
                default: 0.5,
                min: 0.1,
                max: 3.0,
                step: 0.1,
            },
            {
                key: 'Z_max_age',
                label: 'Zone Max Age (H1 Bars)',
                type: 'number',
                default: 40,
                min: 5,
                max: 250,
                step: 5,
            },
            {
                key: 'Z_max_size_atr',
                label: 'Zone Max Size ATR Mult',
                type: 'number',
                default: 1.5,
                min: 0.3,
                max: 5.0,
                step: 0.1,
            },
            {
                key: 'Show_FVG',
                label: 'Show Fair Value Gaps (FVG)',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show', value: 1 },
                    { label: 'Hide', value: 0 },
                ],
            },
            {
                key: 'Show_OB',
                label: 'Show Order Blocks (OB)',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show', value: 1 },
                    { label: 'Hide', value: 0 },
                ],
            },
            {
                key: 'buffer_atr_mult',
                label: 'SL Buffer ATR Mult',
                type: 'number',
                default: 0.3,
                min: 0.05,
                max: 2.0,
                step: 0.05,
            },
            {
                key: 'RR_min',
                label: 'Minimum Reward/Risk (RR)',
                type: 'number',
                default: 1.5,
                min: 0.5,
                max: 10.0,
                step: 0.25,
            },
            {
                key: 'Show_SL_TP',
                label: 'Show Suggested Entry / SL / TP',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show', value: 1 },
                    { label: 'Hide', value: 0 },
                ],
            },
            {
                key: 'Show_Labels',
                label: 'Show Zone & Bias Labels',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show', value: 1 },
                    { label: 'Hide', value: 0 },
                ],
            },
            {
                key: 'showSignals',
                label: 'Show Sweep & BOS/CHoCH Markers',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show', value: 1 },
                    { label: 'Hide', value: 0 },
                ],
            },
            {
                key: 'Zone_Transparency',
                label: 'Zone Transparency (%)',
                type: 'number',
                default: 85,
                min: 20,
                max: 95,
                step: 5,
            },
            {
                key: 'Enable_Alerts',
                label: 'Enable Real-Time Alerts',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Enabled', value: 1 },
                    { label: 'Disabled', value: 0 },
                ],
            },
            { key: 'Bull_OB_Color', label: 'Bullish OB Color', type: 'color', default: '#00e676' },
            { key: 'Bear_OB_Color', label: 'Bearish OB Color', type: 'color', default: '#ff5252' },
            { key: 'Bull_FVG_Color', label: 'Bullish FVG Color', type: 'color', default: '#26a69a' },
            { key: 'Bear_FVG_Color', label: 'Bearish FVG Color', type: 'color', default: '#ef5350' },
            { key: 'Eq_Line_Color', label: 'H4 Equilibrium Line Color', type: 'color', default: '#9c27b0' },
        ];
    }
    getRawBars() {
        return this._rawBars;
    }
    setSymbol(symbol) {
        if (symbol && symbol !== this._symbol) {
            this._symbol = symbol;
            this._htfCache.clear();
        }
    }
    setSource(source) {
        if (source && source !== this._source) {
            this._source = source;
            this._htfCache.clear();
        }
    }
    async fetchHTFBars(symbol, apiTf, fallbackBars) {
        const periodSeconds = apiTf === 'H4' ? 14400 : 3600;
        const effectiveSymbol = symbol || this._symbol || (this.engine && this.engine.symbol) || '';
        const effectiveSource = this._source || (this.engine && this.engine.source) || 'default';
        if (effectiveSymbol && typeof fetch === 'function') {
            const cacheKey = `${effectiveSymbol}_${apiTf}_${effectiveSource}`;
            const cached = this._htfCache.get(cacheKey);
            const now = Date.now();
            if (cached && now - cached.timestamp < 45000 && cached.bars.length > 0) {
                return cached.bars;
            }
            try {
                const url = `/api/bars?symbol=${encodeURIComponent(effectiveSymbol)}&timeframe=${encodeURIComponent(apiTf)}&count=1000&source=${encodeURIComponent(effectiveSource)}`;
                const resp = await fetch(url);
                if (resp && resp.ok) {
                    const json = await resp.json();
                    const rawList = Array.isArray(json)
                        ? json
                        : Array.isArray(json?.bars)
                            ? json.bars
                            : Array.isArray(json?.data)
                                ? json.data
                                : [];
                    if (rawList.length > 10) {
                        const parsed = rawList
                            .map((b) => ({
                            time: Number(b.time),
                            open: Number(b.open),
                            high: Number(b.high),
                            low: Number(b.low),
                            close: Number(b.close),
                            volume: b.volume !== undefined ? Number(b.volume) : 0,
                        }))
                            .filter((b) => isFinite(b.time) &&
                            isFinite(b.open) &&
                            isFinite(b.high) &&
                            isFinite(b.low) &&
                            isFinite(b.close))
                            .sort((a, b) => a.time - b.time);
                        if (parsed.length > 10) {
                            this._htfCache.set(cacheKey, { timestamp: now, bars: parsed });
                            return parsed;
                        }
                    }
                }
            }
            catch (_err) { }
        }
        return MathUtils.resampleBars(fallbackBars, periodSeconds);
    }
    async calculate(bars, symbolOrParams) {
        if (this.isDestroyed)
            return [];
        if (!bars || !Array.isArray(bars) || bars.length === 0) {
            this.cachedData = [];
            this.cachedMarkers = [];
            return [];
        }
        if (typeof symbolOrParams === 'string' && symbolOrParams.trim() !== '') {
            this.setSymbol(symbolOrParams);
        }
        else if (symbolOrParams && typeof symbolOrParams === 'object') {
            this.params = { ...this.params, ...symbolOrParams };
        }
        const cleanBars = bars
            .filter((b) => b &&
            isFinite(b.time) &&
            isFinite(b.open) &&
            isFinite(b.high) &&
            isFinite(b.low) &&
            isFinite(b.close))
            .sort((a, b) => a.time - b.time);
        this._rawBars = cleanBars;
        if (cleanBars.length < 15) {
            this.cachedData = [];
            this.cachedMarkers = [];
            return [];
        }
        const effectiveSymbol = this._symbol || (this.engine && this.engine.symbol) || '';
        const digits = MathUtils.detectPricePrecision(cleanBars, effectiveSymbol, Number(this.params.Price_Digits ?? -1), this.engine);
        const [h4Bars, h1Bars] = await Promise.all([
            this.fetchHTFBars(effectiveSymbol, 'H4', cleanBars),
            this.fetchHTFBars(effectiveSymbol, 'H1', cleanBars),
        ]);
        const prevSnap = this.latestSnapshot;
        const snapshot = StateManager.evaluateMarketState(cleanBars, h4Bars.length >= 10 ? h4Bars : cleanBars, h1Bars.length >= 10 ? h1Bars : cleanBars, this.params, digits, prevSnap);
        this.latestSnapshot = snapshot;
        const swingLen = Math.max(3, Number(this.params.Swing_Length) || 5);
        const sweepMin = Number(this.params.Sweep_min_atr) || 0.15;
        const dispMin = Number(this.params.Disp_min_atr) || 0.5;
        const m15Trig = TriggerDetector.evaluateM15Triggers(cleanBars, snapshot.h4Bias, snapshot.primaryZone, swingLen, sweepMin, dispMin);
        const eqValue = snapshot.h4Equilibrium;
        const seriesData = [];
        let lastTime = -Infinity;
        for (let i = 0; i < cleanBars.length; i++) {
            const t = cleanBars[i].time;
            if (t <= lastTime)
                continue;
            const val = eqValue !== null && isFinite(eqValue) ? eqValue : cleanBars[i].close;
            if (isFinite(val)) {
                seriesData.push({ time: t, value: val });
                lastTime = t;
            }
        }
        this.cachedData = seriesData;
        // Theme-aware marker colors for optimal legibility on Light and Dark charts
        const palette = MathUtils.getThemePalette(String(this.params.Theme_Mode || 'dark'));
        const markerMap = new Map();
        for (const sw of m15Trig.sweeps.slice(-25)) {
            markerMap.set(sw.time, {
                time: sw.time,
                position: sw.direction === 'BULLISH' ? 'belowBar' : 'aboveBar',
                color: palette.accentGold,
                shape: sw.direction === 'BULLISH' ? 'arrowUp' : 'arrowDown',
                text: `SWEEP (${sw.penetrationAtr.toFixed(2)}x ATR)`,
            });
        }
        for (const ev of m15Trig.events.slice(-25)) {
            const isChoch = ev.type === 'CHOCH';
            markerMap.set(ev.time, {
                time: ev.time,
                position: ev.direction === 'BULLISH' ? 'belowBar' : 'aboveBar',
                color: ev.direction === 'BULLISH' ? palette.bullText : palette.bearText,
                shape: isChoch
                    ? ev.direction === 'BULLISH'
                        ? 'arrowUp'
                        : 'arrowDown'
                    : 'circle',
                text: isChoch
                    ? ev.sweptPrior
                        ? 'CHoCH + Sweep'
                        : 'CHoCH'
                    : 'BOS',
            });
        }
        if (snapshot.state === 'TRIGGER_READY' && snapshot.m15TriggerEvent) {
            const tTime = snapshot.m15TriggerEvent.time;
            markerMap.set(tTime, {
                time: tTime,
                position: snapshot.h4Bias === 'BULLISH' ? 'belowBar' : 'aboveBar',
                color: palette.bullText,
                shape: snapshot.h4Bias === 'BULLISH' ? 'arrowUp' : 'arrowDown',
                text: `TRIGGER READY (${snapshot.h4Bias})`,
            });
        }
        this.cachedMarkers = Array.from(markerMap.values()).sort((a, b) => a.time - b.time);
        if (Number(this.params.Enable_Alerts) !== 0 &&
            snapshot.alertsFired.length > 0) {
            this.dispatchAlerts(snapshot.alertsFired, snapshot);
        }
        return this.cachedData;
    }
    dispatchAlerts(messages, snapshot) {
        for (const msg of messages) {
            if (this.engine && typeof this.engine.triggerAlert === 'function') {
                this.engine.triggerAlert({
                    indicatorId: this.id,
                    indicatorName: this.name,
                    state: snapshot.state,
                    message: msg,
                    time: snapshot.time,
                });
            }
            else if (typeof window !== 'undefined' &&
                typeof window.dispatchEvent === 'function') {
                window.dispatchEvent(new CustomEvent('quantdeck:indicator-alert', {
                    detail: {
                        indicatorId: this.id,
                        indicatorName: this.name,
                        state: snapshot.state,
                        message: msg,
                        snapshot,
                    },
                }));
            }
        }
    }
    ensurePrimitiveAttached() {
        if (this.isDestroyed)
            return;
        if (!this.engine || typeof this.engine.getMainSeries !== 'function')
            return;
        const mainSeries = this.engine.getMainSeries();
        if (!mainSeries)
            return;
        if (!this._primitive) {
            this._primitive = new SMCCanvasPrimitive(this);
        }
        if (this._attachedMainSeries !== mainSeries) {
            if (this._attachedMainSeries &&
                typeof this._attachedMainSeries.detachPrimitive === 'function') {
                try {
                    this._attachedMainSeries.detachPrimitive(this._primitive);
                }
                catch (_e) { }
            }
            if (typeof mainSeries.attachPrimitive === 'function') {
                mainSeries.attachPrimitive(this._primitive);
                this._attachedMainSeries = mainSeries;
            }
        }
    }
    render(engine, _onSettings, _onClose) {
        this.engine = engine;
        if (!engine || !engine.chart)
            return;
        const scalePos = typeof engine.getPriceScalePosition === 'function'
            ? engine.getPriceScalePosition()
            : 'right';
        const digits = this.latestSnapshot ? this.latestSnapshot.digits : 5;
        const minMove = Number(Math.pow(10, -digits).toFixed(digits));
        this.series = engine.chart.addLineSeries({
            priceScaleId: scalePos,
            color: String(this.params.Eq_Line_Color || '#9c27b0'),
            lineWidth: Number(this.params.lineWidth) || 1,
            lineStyle: Number(this.params.lineStyle ?? 2),
            visible: this.isVisible && Number(this.params.Show_Labels) !== 0,
            lastValueVisible: false,
            priceLineVisible: false,
            crosshairMarkerVisible: false,
            title: 'H4 EQ (50%)',
            priceFormat: {
                type: 'price',
                precision: digits,
                minMove,
            },
        });
        this.ensurePrimitiveAttached();
        if (this.cachedData && this.cachedData.length > 0) {
            this.setData(this.cachedData);
        }
    }
    setData(data) {
        if (this.isDestroyed)
            return;
        if (this.series && Array.isArray(data)) {
            if (this.latestSnapshot) {
                const digits = this.latestSnapshot.digits;
                const minMove = Number(Math.pow(10, -digits).toFixed(digits));
                this.series.applyOptions({
                    priceFormat: {
                        type: 'price',
                        precision: digits,
                        minMove,
                    },
                });
            }
            this.series.setData(data);
        }
        this.ensurePrimitiveAttached();
        this.applyMarkers();
        this._primitive?.requestUpdate();
    }
    async update(bar) {
        if (!bar || !isFinite(bar.time))
            return;
        const n = this._rawBars.length;
        let isNewBarClosed = false;
        if (n === 0) {
            this._rawBars.push({ ...bar });
        }
        else {
            const lastBar = this._rawBars[n - 1];
            if (bar.time > lastBar.time) {
                this._rawBars.push({ ...bar });
                isNewBarClosed = true;
            }
            else if (bar.time === lastBar.time) {
                this._rawBars[n - 1] = { ...bar };
            }
        }
        if (isNewBarClosed || !this.latestSnapshot) {
            const data = await this.calculate(this._rawBars, this._symbol);
            this.setData(data);
        }
        else {
            if (this.series && this.cachedData.length > 0) {
                const eqVal = this.latestSnapshot.h4Equilibrium !== null
                    ? this.latestSnapshot.h4Equilibrium
                    : bar.close;
                this.series.update({ time: bar.time, value: eqVal });
            }
            this._primitive?.requestUpdate();
        }
    }
    async updateParams(newParams, engine) {
        this.params = { ...this.params, ...newParams };
        if (engine)
            this.engine = engine;
        if (this.series) {
            this.series.applyOptions({
                color: String(this.params.Eq_Line_Color || '#9c27b0'),
                lineWidth: Number(this.params.lineWidth) || 1,
                lineStyle: Number(this.params.lineStyle ?? 2),
                visible: this.isVisible && Number(this.params.Show_Labels) !== 0,
            });
        }
        const bars = this.engine &&
            Array.isArray(this.engine.allBars) &&
            this.engine.allBars.length > 0
            ? this.engine.allBars
            : this._rawBars;
        if (bars && bars.length > 0) {
            const data = await this.calculate(bars, this._symbol);
            this.setData(data);
        }
        else {
            this.applyMarkers();
            this._primitive?.requestUpdate();
        }
    }
    setVisible(visible) {
        this.isVisible = visible !== false;
        if (this.series) {
            this.series.applyOptions({
                visible: this.isVisible && Number(this.params.Show_Labels) !== 0,
            });
        }
        if (!this.isVisible) {
            this.clearMarkers();
        }
        else {
            this.applyMarkers();
        }
        this._primitive?.requestUpdate();
    }
    destroy(engine) {
        this.isDestroyed = true;
        const eng = engine || this.engine;
        this.clearMarkers();
        if (this._primitive) {
            const mainSeries = this._attachedMainSeries ||
                (eng && typeof eng.getMainSeries === 'function'
                    ? eng.getMainSeries()
                    : null);
            if (mainSeries && typeof mainSeries.detachPrimitive === 'function') {
                try {
                    mainSeries.detachPrimitive(this._primitive);
                }
                catch (_e) { }
            }
            this._primitive = null;
            this._attachedMainSeries = null;
        }
        if (this.series &&
            eng &&
            eng.chart &&
            typeof eng.chart.removeSeries === 'function') {
            try {
                eng.chart.removeSeries(this.series);
            }
            catch (_e) { }
            this.series = null;
        }
    }
    applyMarkers() {
        if (!this.engine ||
            !this.isVisible ||
            Number(this.params.showSignals) === 0) {
            this.clearMarkers();
            return;
        }
        if (typeof this.engine.setIndicatorMarkers === 'function') {
            this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries && typeof mainSeries.setMarkers === 'function') {
            mainSeries.setMarkers(this.cachedMarkers || []);
        }
    }
    clearMarkers() {
        if (!this.engine)
            return;
        if (typeof this.engine.clearIndicatorMarkers === 'function') {
            this.engine.clearIndicatorMarkers(this.id);
            return;
        }
    }
}
export default SMC3LayerIndicator;

