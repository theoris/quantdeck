// @ts-sha256: 5b908c6766e656f49757e48e5a31081e7561ef7ad50a8cf2003173a5a90b8e04
// Numeric line styles to avoid runtime import resolution errors in browser blob URLs
const STYLE_SOLID = 0;
const STYLE_DOTTED = 1;
const STYLE_DASHED = 2;
function hexToRgba(hex, alpha) {
    const clean = (hex || '#1e90ff').replace('#', '').trim();
    if (clean.length === 3) {
        const r = parseInt(clean[0] + clean[0], 16);
        const g = parseInt(clean[1] + clean[1], 16);
        const b = parseInt(clean[2] + clean[2], 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
    if (clean.length >= 6) {
        const r = parseInt(clean.substring(0, 2), 16);
        const g = parseInt(clean.substring(2, 4), 16);
        const b = parseInt(clean.substring(4, 6), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
    return `rgba(30, 144, 255, ${alpha})`;
}
// ============================================================================
// Custom Canvas Primitive: Renders discrete Pine Script v6 style ER Boxes
// and the HMM x ER Box Status Dashboard Table on the main chart pane
// ============================================================================
class ErBoxPaneView {
    constructor(primitive) {
        this._primitive = primitive;
    }
    zOrder() {
        return 'normal';
    }
    renderer() {
        return {
            draw: (target) => {
                const primitive = this._primitive;
                const indicator = primitive._indicator;
                if (!indicator || !indicator.isVisible)
                    return;
                const chart = primitive._chart || indicator.engine?.chart;
                const series = primitive._series || indicator.engine?.getMainSeries() || indicator.vwapSeries;
                if (!chart || !series)
                    return;
                const timeScale = chart.timeScale();
                const bars = indicator._rawBars || [];
                const boxes = indicator.boxes || [];
                const getBarX = (barIdx, barTime) => {
                    let x = null;
                    if (bars[barIdx] !== undefined) {
                        try {
                            x = timeScale.timeToCoordinate(bars[barIdx].time);
                        }
                        catch { }
                    }
                    if ((x === null || x === undefined || isNaN(x)) && barTime !== undefined) {
                        try {
                            x = timeScale.timeToCoordinate(barTime);
                        }
                        catch { }
                    }
                    if ((x === null || x === undefined || isNaN(x)) && typeof timeScale.logicalToCoordinate === 'function') {
                        try {
                            x = timeScale.logicalToCoordinate(barIdx);
                        }
                        catch { }
                    }
                    return x !== null && x !== undefined && !isNaN(x) ? x : null;
                };
                const renderFn = (ctx, width, height) => {
                    ctx.save();
                    // 1. Render Discrete ER Boxes (matching Pine Script v6 box.new)
                    if (Number(indicator.params.useHtf) === 1 && Number(indicator.params.showBoxLines) === 1 && boxes.length > 0) {
                        const fillAlpha = Math.max(0, Math.min(1, (Number(indicator.params.boxFillOpacity) || 15) / 100));
                        const borderAlpha = Math.max(0.1, Math.min(1, (Number(indicator.params.boxBorderOpacity) || 55) / 100));
                        const fillColor = hexToRgba(indicator.params.boxColor, fillAlpha);
                        const borderColor = hexToRgba(indicator.params.boxColor, borderAlpha);
                        const borderWidth = Number(indicator.params.boxLineWidth) || 1;
                        const showMid = Number(indicator.params.showMidLine) === 1;
                        const showTol = Number(indicator.params.showTolLines) === 1;
                        const showText = indicator.params.boxTextMode !== 'none';
                        // Limit to last 500 boxes like max_boxes_count = 500 in Pine Script
                        const startIdx = Math.max(0, boxes.length - 500);
                        for (let bIdx = startIdx; bIdx < boxes.length; bIdx++) {
                            const box = boxes[bIdx];
                            const x1Raw = getBarX(box.leftBarIdx, box.leftTime);
                            const x2Raw = getBarX(box.rightBarIdx, box.rightTime);
                            if (x1Raw === null || x2Raw === null)
                                continue;
                            const leftX = Math.min(x1Raw, x2Raw);
                            const rightX = Math.max(x1Raw, x2Raw);
                            // Skip boxes completely outside horizontal viewport
                            if (rightX < 0 || leftX > width)
                                continue;
                            const yTopRaw = series.priceToCoordinate(box.top);
                            const yBotRaw = series.priceToCoordinate(box.bottom);
                            if (yTopRaw === null || yBotRaw === null || isNaN(yTopRaw) || isNaN(yBotRaw))
                                continue;
                            const topY = Math.min(yTopRaw, yBotRaw);
                            const botY = Math.max(yTopRaw, yBotRaw);
                            if (botY < 0 || topY > height)
                                continue;
                            const boxW = Math.max(2, rightX - leftX);
                            const boxH = Math.max(2, botY - topY);
                            // Box background fill (bgcolor = color.rgb(30, 144, 255, 85))
                            ctx.fillStyle = fillColor;
                            ctx.fillRect(leftX, topY, boxW, boxH);
                            // Box 4-sided border (border_color = color.rgb(30, 144, 255, 50))
                            ctx.strokeStyle = borderColor;
                            ctx.lineWidth = borderWidth;
                            ctx.setLineDash([]);
                            ctx.strokeRect(leftX, topY, boxW, boxH);
                            // Optional Midline inside this specific ER Box only
                            if (showMid) {
                                const yMid = series.priceToCoordinate(box.mid);
                                if (yMid !== null && !isNaN(yMid)) {
                                    ctx.strokeStyle = indicator.params.midColor || '#60a5fa';
                                    ctx.lineWidth = 1;
                                    ctx.setLineDash([2, 3]);
                                    ctx.beginPath();
                                    ctx.moveTo(leftX, yMid);
                                    ctx.lineTo(rightX, yMid);
                                    ctx.stroke();
                                }
                            }
                            // Optional Upper & Lower ATR Tolerance lines scoped to this specific ER Box
                            if (showTol) {
                                const yUpTol = series.priceToCoordinate(box.upperTol);
                                const yDnTol = series.priceToCoordinate(box.lowerTol);
                                ctx.strokeStyle = indicator.params.tolColor || '#f59e0b';
                                ctx.lineWidth = 1;
                                ctx.setLineDash([5, 4]);
                                if (yUpTol !== null && !isNaN(yUpTol)) {
                                    ctx.beginPath();
                                    ctx.moveTo(leftX, yUpTol);
                                    ctx.lineTo(rightX, yUpTol);
                                    ctx.stroke();
                                }
                                if (yDnTol !== null && !isNaN(yDnTol)) {
                                    ctx.beginPath();
                                    ctx.moveTo(leftX, yDnTol);
                                    ctx.lineTo(rightX, yDnTol);
                                    ctx.stroke();
                                }
                            }
                            // Box Text at Top-Left inside the box (text_halign = left, text_valign = top)
                            if (showText && box.boxText && boxW >= 24 && boxH >= 14) {
                                const textX = Math.max(4, leftX + 5);
                                if (textX + 20 <= rightX) {
                                    ctx.font = 'bold 11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
                                    ctx.textAlign = 'left';
                                    ctx.textBaseline = 'top';
                                    ctx.fillStyle = indicator.params.boxTextColor || '#e2e8f0';
                                    ctx.fillText(box.boxText, textX, topY + 4);
                                }
                            }
                        }
                    }
                    // 2. Render HMM x ER Box Dashboard Table (Top-Right, matching Pine Script v6 section 6)
                    if (Number(indicator.params.showDashboard) === 1 && indicator.dashState) {
                        const ds = indicator.dashState;
                        const tableW = 215;
                        const rowH = 20;
                        const rowsCount = 6;
                        const tableH = rowH * rowsCount;
                        const padRight = 14;
                        const padTop = 14;
                        const x0 = Math.max(10, width - tableW - padRight);
                        const y0 = padTop;
                        ctx.setLineDash([]);
                        ctx.fillStyle = 'rgba(11, 14, 20, 0.88)';
                        ctx.fillRect(x0, y0, tableW, tableH);
                        // Header background
                        ctx.fillStyle = 'rgba(40, 45, 60, 0.92)';
                        ctx.fillRect(x0, y0, tableW, rowH);
                        ctx.strokeStyle = 'rgba(128, 128, 128, 0.4)';
                        ctx.lineWidth = 1;
                        ctx.strokeRect(x0, y0, tableW, tableH);
                        const colSplit = x0 + 102;
                        ctx.beginPath();
                        ctx.moveTo(colSplit, y0);
                        ctx.lineTo(colSplit, y0 + tableH);
                        ctx.stroke();
                        const stateTxt = ds.official === 0
                            ? 'TREND UP'
                            : ds.official === 2
                                ? 'TREND DOWN'
                                : ds.official === 1
                                    ? 'RANGE'
                                    : 'UNCERTAIN';
                        const stateColor = ds.official === 0
                            ? indicator.params.upC
                            : ds.official === 2
                                ? indicator.params.dnC
                                : ds.official === 1
                                    ? indicator.params.rgC
                                    : '#9ca3af';
                        const rows = [
                            { c1: 'HMM x ER Box', c2: 'Status', c1Color: '#ffffff', c2Color: '#ffffff', bold: true },
                            { c1: 'HMM State', c2: stateTxt, c1Color: '#9ca3af', c2Color: stateColor, bold: true },
                            { c1: 'P(Trend Up)', c2: `${(ds.pUp * 100).toFixed(1)}%`, c1Color: '#9ca3af', c2Color: indicator.params.upC },
                            { c1: 'P(Range)', c2: `${(ds.pRange * 100).toFixed(1)}%`, c1Color: '#9ca3af', c2Color: indicator.params.rgC },
                            { c1: 'P(Trend Down)', c2: `${(ds.pDown * 100).toFixed(1)}%`, c1Color: '#9ca3af', c2Color: indicator.params.dnC },
                            {
                                c1: 'ER Box Status',
                                c2: ds.isBoxActive ? 'ACTIVE (Wait)' : 'WAITING HTF',
                                c1Color: '#9ca3af',
                                c2Color: ds.isBoxActive ? '#facc15' : '#9ca3af',
                            },
                        ];
                        ctx.textBaseline = 'middle';
                        ctx.textAlign = 'left';
                        for (let r = 0; r < rows.length; r++) {
                            const ry = y0 + r * rowH;
                            if (r > 0) {
                                ctx.strokeStyle = 'rgba(128, 128, 128, 0.22)';
                                ctx.beginPath();
                                ctx.moveTo(x0, ry);
                                ctx.lineTo(x0 + tableW, ry);
                                ctx.stroke();
                            }
                            const row = rows[r];
                            ctx.font = `${row.bold ? 'bold ' : ''}11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
                            ctx.fillStyle = row.c1Color;
                            ctx.fillText(row.c1, x0 + 6, ry + rowH / 2);
                            ctx.fillStyle = row.c2Color;
                            ctx.fillText(row.c2, colSplit + 6, ry + rowH / 2);
                        }
                    }
                    ctx.restore();
                };
                if (typeof target.useMediaCoordinateSpace === 'function') {
                    target.useMediaCoordinateSpace((scope) => {
                        renderFn(scope.context, scope.mediaSize.width, scope.mediaSize.height);
                    });
                }
                else if (typeof target.useBitmapCoordinateSpace === 'function') {
                    target.useBitmapCoordinateSpace((scope) => {
                        const ctx = scope.context;
                        const ratio = scope.horizontalPixelRatio || 1;
                        ctx.save();
                        ctx.scale(ratio, ratio);
                        renderFn(ctx, scope.mediaSize.width, scope.mediaSize.height);
                        ctx.restore();
                    });
                }
                else if (target.context) {
                    renderFn(target.context, target.context.canvas.width, target.context.canvas.height);
                }
            },
        };
    }
}
class ErBoxPrimitive {
    constructor(indicator) {
        this._chart = null;
        this._series = null;
        this._requestUpdate = null;
        this._indicator = indicator;
        this._paneViews = [new ErBoxPaneView(this)];
    }
    attached({ chart, series, requestUpdate }) {
        this._chart = chart;
        this._series = series;
        this._requestUpdate = requestUpdate;
    }
    detached() {
        this._chart = null;
        this._series = null;
        this._requestUpdate = null;
        if (this._indicator && !this._indicator._isDestroyed) {
            this._indicator._onPrimitiveDetached();
        }
    }
    paneViews() {
        return this._paneViews;
    }
    timeAxisViews() {
        return [];
    }
    priceAxisViews() {
        return [];
    }
    updateAllViews() { }
    requestUpdate() {
        if (typeof this._requestUpdate === 'function') {
            this._requestUpdate();
        }
    }
}
export class HmmErBoxIndicator {
    constructor() {
        this.name = 'HMM + ER Box Execution';
        this.pane = 'main';
        this.paramDefs = [
            // HMM Engine
            {
                key: 'obsLen',
                label: 'Observation Smoothing',
                type: 'number',
                default: 5,
                min: 1,
                max: 50,
                step: 1,
            },
            {
                key: 'vpLen',
                label: 'VWAP Window',
                type: 'number',
                default: 30,
                min: 10,
                max: 200,
                step: 1,
            },
            {
                key: 'statLen',
                label: 'Scaling Window (Z-Score)',
                type: 'number',
                default: 150,
                min: 30,
                max: 500,
                step: 5,
            },
            {
                key: 'muK',
                label: 'Regime Multiplier',
                type: 'number',
                default: 1.0,
                min: 0.1,
                max: 5.0,
                step: 0.1,
            },
            {
                key: 'stick',
                label: 'Transition Stickiness',
                type: 'number',
                default: 0.97,
                min: 0.8,
                max: 0.999,
                step: 0.001,
            },
            {
                key: 'confirmB',
                label: 'Confirmation Bars',
                type: 'number',
                default: 3,
                min: 1,
                max: 20,
                step: 1,
            },
            {
                key: 'domThresh',
                label: 'Dominance Threshold',
                type: 'number',
                default: 0.55,
                min: 0.34,
                max: 0.99,
                step: 0.01,
            },
            // ER Box
            {
                key: 'useHtf',
                label: 'Use ER Box',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Enabled', value: 1 },
                    { label: 'Disabled', value: 0 },
                ],
            },
            {
                key: 'htfMinutes',
                label: 'HTF Timeframe',
                type: 'select',
                default: 15,
                options: [
                    { label: '5m', value: 5 },
                    { label: '15m', value: 15 },
                    { label: '30m', value: 30 },
                    { label: '1h', value: 60 },
                    { label: '4h', value: 240 },
                    { label: '1D', value: 1440 },
                ],
            },
            {
                key: 'erPeriod',
                label: 'HTF ER Lookback',
                type: 'number',
                default: 8,
                min: 2,
                max: 50,
                step: 1,
            },
            {
                key: 'erThreshold',
                label: 'HTF ER Threshold',
                type: 'number',
                default: 0.35,
                min: 0.05,
                max: 1.0,
                step: 0.05,
            },
            {
                key: 'atrPeriod',
                label: 'HTF ATR Period',
                type: 'number',
                default: 14,
                min: 1,
                max: 50,
                step: 1,
            },
            // Micro Execution
            {
                key: 'atrMult',
                label: 'ATR Tolerance Mult',
                type: 'number',
                default: 1.0,
                min: 0.1,
                max: 5.0,
                step: 0.1,
            },
            {
                key: 'wickPct',
                label: 'Min Rejection Wick (%)',
                type: 'number',
                default: 50.0,
                min: 0.0,
                max: 100.0,
                step: 5.0,
            },
            // Visuals & Styling
            {
                key: 'showBoxLines',
                label: 'Show ER Boxes',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show ER Boxes', value: 1 },
                    { label: 'Hide ER Boxes', value: 0 },
                ],
            },
            {
                key: 'boxColor',
                label: 'ER Box Color',
                type: 'color',
                default: '#1e90ff',
            },
            {
                key: 'boxFillOpacity',
                label: 'Box Fill Opacity (%)',
                type: 'number',
                default: 15,
                min: 0,
                max: 80,
                step: 5,
            },
            {
                key: 'boxBorderOpacity',
                label: 'Box Border Opacity (%)',
                type: 'number',
                default: 55,
                min: 10,
                max: 100,
                step: 5,
            },
            {
                key: 'boxLineWidth',
                label: 'Box Border Width',
                type: 'select',
                default: 1,
                options: [
                    { label: '1px', value: 1 },
                    { label: '2px', value: 2 },
                    { label: '3px', value: 3 },
                ],
            },
            {
                key: 'boxTextMode',
                label: 'Box Range Label',
                type: 'select',
                default: 'auto',
                options: [
                    { label: 'Auto (Pine Script Pips/Points)', value: 'auto' },
                    { label: 'Price Delta (Max - Min)', value: 'price' },
                    { label: 'Pips (x10)', value: 'pips10' },
                    { label: 'Points (x100)', value: 'pts100' },
                    { label: 'Hide Label', value: 'none' },
                ],
            },
            {
                key: 'boxTextColor',
                label: 'Box Label Text Color',
                type: 'color',
                default: '#e2e8f0',
            },
            {
                key: 'showMidLine',
                label: 'Show Box Midpoint',
                type: 'select',
                default: 0,
                options: [
                    { label: 'Show Mid Line', value: 1 },
                    { label: 'Hide Mid Line', value: 0 },
                ],
            },
            {
                key: 'midColor',
                label: 'Box Midpoint Color',
                type: 'color',
                default: '#60a5fa',
            },
            {
                key: 'showTolLines',
                label: 'Show ATR Tolerances',
                type: 'select',
                default: 0,
                options: [
                    { label: 'Show ATR Bands', value: 1 },
                    { label: 'Hide ATR Bands', value: 0 },
                ],
            },
            {
                key: 'tolColor',
                label: 'ATR Tolerance Color',
                type: 'color',
                default: '#f59e0b',
            },
            {
                key: 'showVwap',
                label: 'Show Anchor VWAP',
                type: 'select',
                default: 0,
                options: [
                    { label: 'Show Anchor VWAP', value: 1 },
                    { label: 'Hide Anchor VWAP', value: 0 },
                ],
            },
            {
                key: 'lineColor',
                label: 'Anchor VWAP Color',
                type: 'color',
                default: '#3b82f6',
            },
            {
                key: 'lineWidth',
                label: 'VWAP Line Width',
                type: 'select',
                default: 2,
                options: [
                    { label: '1px', value: 1 },
                    { label: '2px', value: 2 },
                    { label: '3px', value: 3 },
                ],
            },
            {
                key: 'showDashboard',
                label: 'Show HMM Dashboard',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show Top-Right Table', value: 1 },
                    { label: 'Hide Table', value: 0 },
                ],
            },
            {
                key: 'showRawSignals',
                label: 'Show Raw ER Break/Sweep',
                type: 'select',
                default: 1,
                options: [
                    { label: 'Show All (HMM + Raw)', value: 1 },
                    { label: 'Only HMM Filtered', value: 0 },
                ],
            },
            {
                key: 'upC',
                label: 'Trend Up Signal Color',
                type: 'color',
                default: '#2fe6c2',
            },
            {
                key: 'rgC',
                label: 'Range / Sweep Signal Color',
                type: 'color',
                default: '#968cb9',
            },
            {
                key: 'dnC',
                label: 'Trend Down Signal Color',
                type: 'color',
                default: '#ec4899',
            },
        ];
        this.cachedData = {};
        this.cachedMarkers = [];
        this.boxes = [];
        this.dashState = null;
        this._rawBars = [];
        this.isVisible = true;
        this._isDestroyed = false;
        this._reattachTimer = null;
        this._watchdogTimer = null;
        this._unsubRange = null;
        this._unsubCrosshair = null;
        this.id = `hmm_er_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        this.params = {
            obsLen: 5,
            vpLen: 30,
            statLen: 150,
            muK: 1.0,
            stick: 0.97,
            confirmB: 3,
            domThresh: 0.55,
            useHtf: 1,
            htfMinutes: 15,
            erPeriod: 8,
            erThreshold: 0.35,
            atrPeriod: 14,
            atrMult: 1.0,
            wickPct: 50.0,
            showBoxLines: 1,
            boxColor: '#1e90ff',
            boxFillOpacity: 15,
            boxBorderOpacity: 55,
            boxLineWidth: 1,
            boxTextMode: 'auto',
            boxTextColor: '#e2e8f0',
            showMidLine: 0,
            midColor: '#60a5fa',
            showTolLines: 0,
            tolColor: '#f59e0b',
            showVwap: 0,
            lineColor: '#3b82f6',
            lineWidth: 2,
            showDashboard: 1,
            showRawSignals: 1,
            upC: '#2fe6c2',
            rgC: '#968cb9',
            dnC: '#ec4899',
        };
        this._primitive = new ErBoxPrimitive(this);
    }
    /**
     * Gaussian Probability Density Function
     */
    gpdf(x, mu, sigma) {
        const s = Math.max(sigma, 0.01);
        const z = (x - mu) / s;
        return Math.exp(-0.5 * z * z) / (s * Math.sqrt(2.0 * Math.PI));
    }
    /**
     * Safe Timestamp extractor in Unix seconds
     */
    getBarSeconds(time) {
        if (typeof time === 'number') {
            return time > 2e10 ? Math.floor(time / 1000) : time;
        }
        if (typeof time === 'string') {
            const parsed = Date.parse(time);
            return isNaN(parsed) ? 0 : Math.floor(parsed / 1000);
        }
        if (time && typeof time.year === 'number') {
            const dt = new Date(Date.UTC(time.year, time.month - 1, time.day));
            return Math.floor(dt.getTime() / 1000);
        }
        return 0;
    }
    /**
     * Formats the box range text matching Pine Script v6:
     * pipMultiplier = syminfo.type == "forex" ? 10 : 1
     * boxPips = (boxMax - boxMin) / syminfo.mintick / pipMultiplier
     */
    formatBoxText(boxMax, boxMin) {
        const diff = Math.max(0, boxMax - boxMin);
        const mode = this.params.boxTextMode || 'auto';
        if (mode === 'none')
            return '';
        if (mode === 'price')
            return ` ${diff.toFixed(2)}`;
        if (mode === 'pips10')
            return ` ${(diff * 10).toFixed(1)}`;
        if (mode === 'pts100')
            return ` ${(diff * 100).toFixed(1)}`;
        // 'auto' mode matching Pine Script v6
        if (boxMax < 10) {
            // Standard 5-digit Forex (e.g. EURUSD: mintick=0.00001, pipMultiplier=10 -> / 0.0001)
            return ` ${(diff * 10000).toFixed(1)}`;
        }
        if (boxMax >= 80 && boxMax <= 220) {
            // 3-digit JPY Forex or similar
            return ` ${(diff * 100).toFixed(1)}`;
        }
        // Gold (XAUUSD), Indices, Crypto, Stocks (mintick=0.01, pipMultiplier=1 -> * 100)
        return ` ${(diff * 100).toFixed(1)}`;
    }
    /**
     * Resamples base bars into HTF bars (e.g. 15m) with RMA ATR and ER precomputed
     * matching Pine Script v6 f_calc_htf(er_len, atr_len)
     */
    buildHtfSeries(bars, htfMinutes) {
        const htfIntervalSec = Math.max(1, Number(htfMinutes) || 15) * 60;
        const htfBars = [];
        const barHtfMap = new Array(bars.length);
        let curHtfBar = null;
        let curHtfStartSec = -1;
        for (let i = 0; i < bars.length; i++) {
            const sec = this.getBarSeconds(bars[i].time);
            const htfBucket = Math.floor(sec / htfIntervalSec) * htfIntervalSec;
            if (!curHtfBar || htfBucket !== curHtfStartSec) {
                if (curHtfBar) {
                    htfBars.push(curHtfBar);
                }
                curHtfStartSec = htfBucket;
                curHtfBar = {
                    time: htfBucket,
                    firstBaseBarIdx: i,
                    open: bars[i].open,
                    high: bars[i].high,
                    low: bars[i].low,
                    close: bars[i].close,
                    volume: bars[i].volume || 0,
                    er: NaN,
                    atr: 0,
                    hh: bars[i].high,
                    ll: bars[i].low,
                };
            }
            else {
                curHtfBar.high = Math.max(curHtfBar.high, bars[i].high);
                curHtfBar.low = Math.min(curHtfBar.low, bars[i].low);
                curHtfBar.close = bars[i].close;
                curHtfBar.volume += bars[i].volume || 0;
            }
            barHtfMap[i] = htfBars.length; // index in htfBars
        }
        if (curHtfBar) {
            htfBars.push(curHtfBar);
        }
        const n = htfBars.length;
        if (n === 0)
            return { htfBars, barHtfMap };
        // Precalculate HTF ATR (Wilder's RMA matching ta.atr(atr_len))
        const atrPeriod = Math.max(1, Number(this.params.atrPeriod) || 14);
        const htfTr = new Array(n);
        let trSum = 0;
        for (let j = 0; j < n; j++) {
            if (j === 0) {
                htfTr[j] = htfBars[j].high - htfBars[j].low;
                htfBars[j].atr = htfTr[j];
                trSum = htfTr[j];
            }
            else {
                htfTr[j] = Math.max(htfBars[j].high - htfBars[j].low, Math.abs(htfBars[j].high - htfBars[j - 1].close), Math.abs(htfBars[j].low - htfBars[j - 1].close));
                if (j < atrPeriod) {
                    trSum += htfTr[j];
                    htfBars[j].atr = trSum / (j + 1);
                }
                else {
                    htfBars[j].atr = (htfBars[j - 1].atr * (atrPeriod - 1) + htfTr[j]) / atrPeriod;
                }
            }
        }
        // Precalculate HTF ER (Efficiency Ratio), Highest High, Lowest Low over erPeriod
        const erPeriod = Math.max(2, Number(this.params.erPeriod) || 8);
        for (let j = 0; j < n; j++) {
            if (j >= erPeriod) {
                const netChange = Math.abs(htfBars[j].close - htfBars[j - erPeriod].close);
                let sumVol = 0;
                let hh = -Infinity;
                let ll = Infinity;
                for (let k = 0; k < erPeriod; k++) {
                    const idx = j - k;
                    sumVol += Math.abs(htfBars[idx].close - htfBars[idx - 1].close);
                    if (htfBars[idx].high > hh)
                        hh = htfBars[idx].high;
                    if (htfBars[idx].low < ll)
                        ll = htfBars[idx].low;
                }
                htfBars[j].er = sumVol === 0 ? 0 : netChange / sumVol;
                htfBars[j].hh = hh;
                htfBars[j].ll = ll;
            }
            else {
                // Must be NaN when j < erPeriod so 'not na(htf_er)' in Pine Script is respected
                htfBars[j].er = NaN;
                htfBars[j].hh = htfBars[j].high;
                htfBars[j].ll = htfBars[j].low;
            }
        }
        return { htfBars, barHtfMap };
    }
    calculate(bars) {
        this._rawBars = bars || [];
        const minBars = Math.max(this.params.statLen + this.params.obsLen, this.params.vpLen * 2, 50);
        if (!bars || bars.length < minBars) {
            this.cachedData = {};
            this.cachedMarkers = [];
            this.boxes = [];
            this.dashState = null;
            return {};
        }
        const n = bars.length;
        const markers = [];
        const boxes = [];
        // --- 1. Base ATR (14) Calculation ---
        const atr14 = new Array(n);
        let trRunningSum = 0;
        for (let i = 0; i < n; i++) {
            const tr = i === 0
                ? bars[i].high - bars[i].low
                : Math.max(bars[i].high - bars[i].low, Math.abs(bars[i].high - bars[i - 1].close), Math.abs(bars[i].low - bars[i - 1].close));
            if (i < 14) {
                trRunningSum += tr;
                atr14[i] = trRunningSum / (i + 1);
            }
            else {
                atr14[i] = (atr14[i - 1] * 13 + tr) / 14;
            }
        }
        // --- 2. Relative Volume & Return Smoothing ---
        const smaVolLen = this.params.obsLen * 2;
        const rawReturn = new Array(n).fill(0);
        let volSum = 0;
        for (let i = 0; i < n; i++) {
            const v = bars[i].volume && bars[i].volume > 0 ? bars[i].volume : 1.0;
            volSum += v;
            if (i >= smaVolLen) {
                volSum -= bars[i - smaVolLen].volume && bars[i - smaVolLen].volume > 0 ? bars[i - smaVolLen].volume : 1.0;
            }
            const volSma = i >= smaVolLen - 1 ? volSum / smaVolLen : 1.0;
            const relVol = volSma > 0 ? v / volSma : 1.0;
            if (i > 0 && atr14[i] > 0) {
                rawReturn[i] = ((bars[i].close - bars[i - 1].close) / atr14[i]) * relVol;
            }
        }
        // Exponential Moving Average of Return (obs_ret)
        const obs_ret = new Array(n).fill(0);
        const alpha_ret = 2.0 / (this.params.obsLen + 1.0);
        for (let i = 0; i < n; i++) {
            if (i === 0) {
                obs_ret[i] = rawReturn[0];
            }
            else {
                obs_ret[i] = rawReturn[i] * alpha_ret + obs_ret[i - 1] * (1.0 - alpha_ret);
            }
        }
        // --- 3. Dynamic Rolling Anchor VWAP (hlc3) ---
        const dynVwap = new Array(n).fill(0);
        let cumPv = 0;
        let cumVol = 0;
        for (let i = 0; i < n; i++) {
            if (i % this.params.vpLen === 0) {
                cumPv = 0;
                cumVol = 0;
            }
            const hlc3 = (bars[i].high + bars[i].low + bars[i].close) / 3.0;
            const v = bars[i].volume && bars[i].volume > 0 ? bars[i].volume : 1.0;
            cumPv += hlc3 * v;
            cumVol += v;
            dynVwap[i] = cumVol > 0 ? cumPv / cumVol : hlc3;
        }
        // --- 4. VWAP Deviation & Observation Profile (obs_vp) ---
        const obs_vp = new Array(n).fill(0);
        for (let i = 0; i < n; i++) {
            if (i >= this.params.vpLen - 1) {
                let sum = 0;
                for (let k = i - this.params.vpLen + 1; k <= i; k++) {
                    sum += bars[k].close - dynVwap[k];
                }
                const mean = sum / this.params.vpLen;
                let sumSq = 0;
                for (let k = i - this.params.vpLen + 1; k <= i; k++) {
                    const diff = bars[k].close - dynVwap[k] - mean;
                    sumSq += diff * diff;
                }
                const vwapDev = Math.sqrt(sumSq / Math.max(this.params.vpLen - 1, 1));
                obs_vp[i] = vwapDev > 0 ? (bars[i].close - dynVwap[i]) / vwapDev : 0.0;
            }
            else {
                obs_vp[i] = 0;
            }
        }
        // --- 5. Multi-Timeframe ER Resampling ---
        const { htfBars, barHtfMap } = this.buildHtfSeries(bars, this.params.htfMinutes);
        const erPeriod = Math.max(2, Number(this.params.erPeriod) || 8);
        // --- 6. HMM State Tracking & ER Box Execution Loop (Exact Pine Script v6 Logic) ---
        let probs = [1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0];
        let candPrev = -1;
        let streak = 0;
        let official = -1;
        let isBoxActive = false;
        let boxMax = 0;
        let boxMin = 0;
        let currentBox = null;
        const warmupIndex = Math.max(this.params.statLen + this.params.obsLen, this.params.vpLen);
        for (let i = 0; i < n; i++) {
            const time = bars[i].time;
            const barSec = this.getBarSeconds(bars[i].time);
            // Standard Deviation of obs_ret and obs_vp over statLen
            let sig_ret = 0;
            let sig_vp = 0;
            if (i >= this.params.statLen - 1) {
                let sumRet = 0;
                let sumVp = 0;
                for (let k = i - this.params.statLen + 1; k <= i; k++) {
                    sumRet += obs_ret[k];
                    sumVp += obs_vp[k];
                }
                const meanRet = sumRet / this.params.statLen;
                const meanVp = sumVp / this.params.statLen;
                let sqRet = 0;
                let sqVp = 0;
                for (let k = i - this.params.statLen + 1; k <= i; k++) {
                    const dRet = obs_ret[k] - meanRet;
                    sqRet += dRet * dRet;
                    const dVp = obs_vp[k] - meanVp;
                    sqVp += dVp * dVp;
                }
                sig_ret = Math.sqrt(sqRet / Math.max(this.params.statLen - 1, 1));
                sig_vp = Math.sqrt(sqVp / Math.max(this.params.statLen - 1, 1));
            }
            const ready = i >= warmupIndex && sig_ret > 0 && sig_vp > 0;
            if (ready) {
                const p0 = probs[0];
                const p1 = probs[1];
                const p2 = probs[2];
                const off = 1.0 - this.params.stick;
                const prior0 = p0 * this.params.stick + p1 * (off * 0.5) + p2 * (off * 0.25);
                const prior1 = p0 * (off * 0.75) + p1 * this.params.stick + p2 * (off * 0.75);
                const prior2 = p0 * (off * 0.25) + p1 * (off * 0.5) + p2 * this.params.stick;
                const mu_ret = this.params.muK * sig_ret;
                const e0 = this.gpdf(obs_ret[i], mu_ret, sig_ret) * this.gpdf(obs_vp[i], 1.2, sig_vp);
                const e1 = this.gpdf(obs_ret[i], 0.0, sig_ret) * this.gpdf(obs_vp[i], 0.0, sig_vp);
                const e2 = this.gpdf(obs_ret[i], -mu_ret, sig_ret) * this.gpdf(obs_vp[i], -1.2, sig_vp);
                const u0 = prior0 * e0;
                const u1 = prior1 * e1;
                const u2 = prior2 * e2;
                const total_u = u0 + u1 + u2;
                if (total_u > 0 && isFinite(total_u)) {
                    probs[0] = u0 / total_u;
                    probs[1] = u1 / total_u;
                    probs[2] = u2 / total_u;
                }
                const p_up = probs[0];
                const p_range = probs[1];
                const p_down = probs[2];
                const raw_state = p_up >= p_range && p_up >= p_down ? 0 : p_range >= p_down ? 1 : 2;
                const p_max = probs[raw_state];
                const candidate = p_max >= this.params.domThresh ? raw_state : -1;
                streak = candidate === candPrev && candidate !== -1 ? streak + 1 : candidate === -1 ? 0 : 1;
                candPrev = candidate;
                if (candidate !== -1 && candidate !== official && streak >= this.params.confirmB) {
                    official = candidate;
                }
            }
            // --- 3. ER BOX ENGINE (Exact match to Pine Script v6 lines 136-199) ---
            const currentHtfIndex = barHtfMap[i];
            const isNewHtfBar = i === 0 || currentHtfIndex !== barHtfMap[i - 1];
            const closedHtf = currentHtfIndex > 0 ? htfBars[currentHtfIndex - 1] : null;
            const htfAtr = closedHtf ? closedHtf.atr : 0;
            if (isNewHtfBar && closedHtf) {
                if (!isBoxActive) {
                    if (Number(this.params.useHtf) === 1 &&
                        !isNaN(closedHtf.er) &&
                        closedHtf.er < this.params.erThreshold) {
                        isBoxActive = true;
                        boxMax = closedHtf.hh;
                        boxMin = closedHtf.ll;
                        // start_time = time[er_len - 1] of closed HTF bar (index = (currentHtfIndex - 1) - (erPeriod - 1))
                        const startHtfIdx = Math.max(0, currentHtfIndex - 1 - (erPeriod - 1));
                        const startHtfBar = htfBars[startHtfIdx];
                        currentBox = {
                            leftTime: startHtfBar.time,
                            leftBarIdx: startHtfBar.firstBaseBarIdx,
                            rightTime: barSec,
                            rightBarIdx: i,
                            top: boxMax,
                            bottom: boxMin,
                            mid: (boxMax + boxMin) / 2,
                            upperTol: boxMax + htfAtr * this.params.atrMult,
                            lowerTol: boxMin - htfAtr * this.params.atrMult,
                            boxText: this.formatBoxText(boxMax, boxMin),
                            active: true,
                        };
                        boxes.push(currentBox);
                    }
                }
                else {
                    const upperTolHTF = boxMax + htfAtr * this.params.atrMult;
                    const lowerTolHTF = boxMin - htfAtr * this.params.atrMult;
                    if (closedHtf.close > upperTolHTF || closedHtf.close < lowerTolHTF) {
                        isBoxActive = false;
                        if (currentBox)
                            currentBox.active = false;
                    }
                }
            }
            let trendBuy = false;
            let trendSell = false;
            let sweepBuy = false;
            let sweepSell = false;
            if (isBoxActive && htfAtr > 0) {
                // box.set_right(currentBox, time)
                if (currentBox) {
                    currentBox.rightTime = barSec;
                    currentBox.rightBarIdx = i;
                    currentBox.upperTol = boxMax + htfAtr * this.params.atrMult;
                    currentBox.lowerTol = boxMin - htfAtr * this.params.atrMult;
                }
                const upperTol = boxMax + htfAtr * this.params.atrMult;
                const lowerTol = boxMin - htfAtr * this.params.atrMult;
                const candleSize = bars[i].high - bars[i].low;
                const reqWickRatio = this.params.wickPct / 100.0;
                if (bars[i].close > upperTol) {
                    trendBuy = true;
                    isBoxActive = false;
                    if (currentBox)
                        currentBox.active = false;
                }
                else if (bars[i].close < lowerTol) {
                    trendSell = true;
                    isBoxActive = false;
                    if (currentBox)
                        currentBox.active = false;
                }
                else if (candleSize > 0) {
                    if (bars[i].low < boxMin && bars[i].low >= lowerTol && bars[i].close > boxMin) {
                        const lowerWick = Math.min(bars[i].open, bars[i].close) - bars[i].low;
                        if (lowerWick / candleSize >= reqWickRatio) {
                            sweepBuy = true;
                        }
                    }
                    if (bars[i].high > boxMax && bars[i].high <= upperTol && bars[i].close < boxMax) {
                        const upperWick = bars[i].high - Math.max(bars[i].open, bars[i].close);
                        if (upperWick / candleSize >= reqWickRatio) {
                            sweepSell = true;
                        }
                    }
                }
            }
            // --- 4 & 7. SMART EXECUTION MATRIX & MTFA SIGNALS ---
            if (i >= warmupIndex) {
                const execute_long_bo = official === 0 && trendBuy;
                const execute_short_bo = official === 2 && trendSell;
                const execute_long_swp = official === 1 && sweepBuy;
                const execute_short_swp = official === 1 && sweepSell;
                if (execute_long_bo) {
                    markers.push({
                        time,
                        position: 'belowBar',
                        color: this.params.upC,
                        shape: 'arrowUp',
                        text: 'BO LONG',
                    });
                }
                else if (execute_short_bo) {
                    markers.push({
                        time,
                        position: 'aboveBar',
                        color: this.params.dnC,
                        shape: 'arrowDown',
                        text: 'BO SHORT',
                    });
                }
                else if (execute_long_swp) {
                    markers.push({
                        time,
                        position: 'belowBar',
                        color: this.params.rgC,
                        shape: 'arrowUp',
                        text: 'SWEEP LONG',
                    });
                }
                else if (execute_short_swp) {
                    markers.push({
                        time,
                        position: 'aboveBar',
                        color: this.params.rgC,
                        shape: 'arrowDown',
                        text: 'SWEEP SHORT',
                    });
                }
                else if (Number(this.params.showRawSignals) === 1 && Number(this.params.useHtf) === 1) {
                    // Section 7 Visual Plots (MTFA raw ER Box Breakouts / Sweeps from er.txt lines 265-268)
                    if (trendBuy) {
                        markers.push({
                            time,
                            position: 'belowBar',
                            color: '#22c55e',
                            shape: 'arrowUp',
                            text: '▲',
                        });
                    }
                    else if (trendSell) {
                        markers.push({
                            time,
                            position: 'aboveBar',
                            color: '#ef4444',
                            shape: 'arrowDown',
                            text: '▼',
                        });
                    }
                    else if (sweepBuy) {
                        markers.push({
                            time,
                            position: 'belowBar',
                            color: '#84cc16',
                            shape: 'circle',
                            text: 'SWP▲',
                        });
                    }
                    else if (sweepSell) {
                        markers.push({
                            time,
                            position: 'aboveBar',
                            color: '#d946ef',
                            shape: 'circle',
                            text: 'SWP▼',
                        });
                    }
                }
            }
        }
        this.boxes = boxes;
        this.dashState = {
            official,
            pUp: probs[0],
            pRange: probs[1],
            pDown: probs[2],
            isBoxActive,
        };
        // Build Anchor VWAP series
        const vwapData = [];
        for (let i = 0; i < n; i++) {
            const time = bars[i].time;
            const vwapValue = dynVwap[i];
            if (i >= warmupIndex && !isNaN(vwapValue) && isFinite(vwapValue)) {
                vwapData.push({ time, value: Number(vwapValue.toFixed(4)) });
            }
            else {
                vwapData.push({ time });
            }
        }
        const dataObj = {
            vwap: vwapData,
            boxes,
        };
        this.cachedData = dataObj;
        this.cachedMarkers = markers;
        return dataObj;
    }
    _ensureAttached(targetSeries) {
        const s = targetSeries || (this.engine ? this.engine.getMainSeries() : null);
        if (!s || typeof s.attachPrimitive !== 'function')
            return;
        if (this._primitive._series !== s) {
            try {
                s.attachPrimitive(this._primitive);
            }
            catch { }
        }
    }
    _onPrimitiveDetached() {
        if (this._isDestroyed)
            return;
        if (this._reattachTimer)
            clearTimeout(this._reattachTimer);
        this._reattachTimer = setTimeout(() => {
            if (this._isDestroyed || !this.engine)
                return;
            const mainSeries = this.engine.getMainSeries();
            if (mainSeries) {
                this._ensureAttached(mainSeries);
                if (this.isVisible) {
                    this.applyMarkers();
                }
                this._primitive.requestUpdate();
            }
        }, 40);
    }
    _checkAttachAndRedraw() {
        if (this._isDestroyed || !this.engine)
            return;
        const mainSeries = this.engine.getMainSeries();
        if (!mainSeries)
            return;
        if (!this._primitive._series || this._primitive._series !== mainSeries) {
            this._ensureAttached(mainSeries);
            if (this.isVisible) {
                this.applyMarkers();
            }
        }
        this._primitive.requestUpdate();
    }
    render(engine, onSettings, onClose) {
        this.engine = engine;
        this._isDestroyed = false;
        const scalePos = engine.getPriceScalePosition();
        // Anchor VWAP Line (optional overlay)
        this.vwapSeries = engine.chart.addLineSeries({
            color: this.params.lineColor,
            lineWidth: (this.params.lineWidth || 2),
            lineStyle: STYLE_SOLID,
            priceScaleId: scalePos,
            title: 'Anchor VWAP',
            lastValueVisible: false,
            priceLineVisible: false,
            visible: this.isVisible && Number(this.params.showVwap) === 1,
        });
        const mainSeries = engine.getMainSeries();
        if (mainSeries) {
            this._ensureAttached(mainSeries);
        }
        try {
            const ts = engine.chart.timeScale();
            if (typeof ts.subscribeVisibleLogicalRangeChange === 'function') {
                this._unsubRange = () => {
                    this._checkAttachAndRedraw();
                };
                ts.subscribeVisibleLogicalRangeChange(this._unsubRange);
            }
            if (typeof engine.chart.subscribeCrosshairMove === 'function') {
                this._unsubCrosshair = () => {
                    this._checkAttachAndRedraw();
                };
                engine.chart.subscribeCrosshairMove(this._unsubCrosshair);
            }
        }
        catch { }
        if (this._watchdogTimer)
            clearInterval(this._watchdogTimer);
        this._watchdogTimer = setInterval(() => {
            this._checkAttachAndRedraw();
        }, 400);
        if (this.cachedData && this.cachedData.vwap) {
            this.setData(this.cachedData);
        }
    }
    setData(data) {
        if (!data)
            return;
        this._ensureAttached();
        if (this.vwapSeries && data.vwap) {
            this.vwapSeries.setData(data.vwap);
        }
        else if (this.vwapSeries && Array.isArray(data)) {
            this.vwapSeries.setData(data);
        }
        this.applyMarkers();
        this._primitive.requestUpdate();
    }
    updateParams(newParams, engine) {
        this.params = { ...this.params, ...newParams };
        this._ensureAttached();
        this.vwapSeries?.applyOptions({
            color: this.params.lineColor,
            lineWidth: (this.params.lineWidth || 2),
            visible: this.isVisible && Number(this.params.showVwap) === 1,
        });
        const bars = engine.allBars || this._rawBars || [];
        if (bars.length > 0) {
            const newData = this.calculate(bars);
            this.setData(newData);
        }
        this._primitive.requestUpdate();
    }
    setVisible(visible) {
        this.isVisible = visible;
        this.vwapSeries?.applyOptions({ visible: visible && Number(this.params.showVwap) === 1 });
        if (!visible) {
            this.clearMarkers();
        }
        else {
            this.applyMarkers();
        }
        this._primitive.requestUpdate();
    }
    destroy(engine) {
        this._isDestroyed = true;
        if (this._reattachTimer)
            clearTimeout(this._reattachTimer);
        if (this._watchdogTimer)
            clearInterval(this._watchdogTimer);
        try {
            if (engine.chart && typeof engine.chart.timeScale === 'function' && this._unsubRange) {
                engine.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this._unsubRange);
            }
            if (engine.chart && this._unsubCrosshair) {
                engine.chart.unsubscribeCrosshairMove(this._unsubCrosshair);
            }
        }
        catch { }
        try {
            if (this._primitive && this._primitive._series && typeof this._primitive._series.detachPrimitive === 'function') {
                this._primitive._series.detachPrimitive(this._primitive);
            }
        }
        catch { }
        this.clearMarkers();
        if (this.vwapSeries) {
            try {
                engine.chart.removeSeries(this.vwapSeries);
            }
            catch { }
        }
        this.vwapSeries = undefined;
        this.cachedData = {};
        this.cachedMarkers = [];
        this.boxes = [];
        this.dashState = null;
        this.engine = undefined;
    }
    applyMarkers() {
        if (!this.engine || !this.isVisible)
            return;
        if (typeof this.engine.setIndicatorMarkers === 'function') {
            this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries) {
            try {
                mainSeries.setMarkers(this.cachedMarkers || []);
            }
            catch { }
        }
    }
    clearMarkers() {
        if (!this.engine)
            return;
        if (typeof this.engine.clearIndicatorMarkers === 'function') {
            this.engine.clearIndicatorMarkers(this.id);
            return;
        }
        const mainSeries = this.engine.getMainSeries();
        if (mainSeries) {
            try {
                mainSeries.setMarkers([]);
            }
            catch { }
        }
    }
}
export default HmmErBoxIndicator;

