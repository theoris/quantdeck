import os
import sys

# Redirect stdout/stderr to devnull when running in windowless mode (pythonw.exe) or silent production mode
if sys.stdout is None or os.environ.get("QD_WINDOWLESS") == "1":
    _devnull = open(os.devnull, "w", encoding="utf-8", errors="ignore")
    sys.stdout = _devnull
    sys.stderr = _devnull
else:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import subprocess
import threading
import time
import uvicorn

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT_DIR)

from backend.config_loader import (
    load_app_config,
    ensure_standalone_directories,
)

cfg = load_app_config()
server_cfg = cfg.get("server", {})
HOST = str(server_cfg.get("host", "127.0.0.1"))
PORT = int(server_cfg.get("port", 8765))
AUTO_OPEN_BROWSER = bool(server_cfg.get("auto_open_browser", True))


def is_port_in_use(host: str, port: int) -> bool:
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.5)
        in_use = (s.connect_ex((host, port)) == 0)
        s.close()
        return in_use
    except Exception:
        return False


def find_free_port(host: str, start_port: int, max_attempts: int = 50) -> int:
    port = start_port
    while is_port_in_use(host, port) and port < start_port + max_attempts:
        port += 1
    return port


def get_pid_for_port(port: int):
    try:
        import psutil
        for conn in psutil.net_connections(kind="tcp"):
            if conn.status == "LISTEN" and conn.laddr.port == port:
                return conn.pid
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            output = subprocess.check_output(
                f"netstat -ano | findstr :{port}",
                shell=True,
                text=True,
                errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            for line in output.strip().splitlines():
                parts = line.split()
                if len(parts) >= 5 and "LISTENING" in parts:
                    return int(parts[-1])
        except Exception:
            pass
    return None


def is_quantdeck_process(pid: int) -> bool:
    if pid <= 0 or pid == os.getpid():
        return False
    try:
        import psutil
        proc = psutil.Process(pid)
        cmd = " ".join(proc.cmdline()).lower()
        if "backend.main:app" in cmd or "run.py" in cmd or ("uvicorn" in cmd and "chart" in cmd):
            return True
    except Exception:
        pass
    return False


def resolve_server_port(host: str, preferred_port: int) -> int:
    if not is_port_in_use(host, preferred_port):
        return preferred_port

    pid = get_pid_for_port(preferred_port)
    if pid and is_quantdeck_process(pid):
        try:
            import psutil
            proc = psutil.Process(pid)
            proc.terminate()
            proc.wait(timeout=2.0)
        except Exception:
            if sys.platform == "win32":
                subprocess.run(
                    f"taskkill /F /PID {pid}",
                    shell=True,
                    capture_output=True,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
        time.sleep(0.6)
        if not is_port_in_use(host, preferred_port):
            return preferred_port

    return find_free_port(host, preferred_port + 1)


def start_backend():
    # Disable access_log and verbose log_level to prevent leaking API endpoints or internal paths
    uvicorn.run(
        "backend.main:app",
        host=HOST,
        port=PORT,
        log_level="critical",
        access_log=False,
    )


def open_app_window():
    if not AUTO_OPEN_BROWSER:
        return
    time.sleep(1.0)
    url = f"http://{HOST}:{PORT}/?_t={int(time.time())}"

    if sys.platform == "win32":
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        ]
        edge_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]

        browser_bin = None
        for p in chrome_paths + edge_paths:
            if os.path.exists(p):
                browser_bin = p
                break

        if browser_bin:
            subprocess.Popen([
                browser_bin,
                f"--app={url}",
                "--disable-http-cache",
                "--start-maximized",
            ])
            return
    elif sys.platform == "darwin":
        mac_chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.exists(mac_chrome):
            subprocess.Popen([mac_chrome, f"--app={url}", "--disable-http-cache"])
            return

    import webbrowser
    webbrowser.open(url)


if __name__ == "__main__":
    ensure_standalone_directories()
    PORT = resolve_server_port(HOST, PORT)
    backend_thread = threading.Thread(target=start_backend, daemon=True)
    backend_thread.start()

    open_app_window()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
