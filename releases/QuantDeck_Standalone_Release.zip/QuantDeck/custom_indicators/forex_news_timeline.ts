// QuantDeck Custom Indicator — Forex News Timeline
// Pure ES2020 JavaScript (Blob-URL safe, zero runtime imports, zero TypeScript)

const LINE_STYLE = {
  Solid: 0,
  Dotted: 1,
  Dashed: 2,
};

export class MathUtils {
  static sanitizeSeriesData(data) {
    if (!Array.isArray(data) || data.length === 0) return [];
    const valid = data.filter((pt) => {
      if (!pt || typeof pt.time !== 'number' || !Number.isFinite(pt.time)) return false;
      if ('value' in pt && (typeof pt.value !== 'number' || !Number.isFinite(pt.value))) return false;
      return true;
    });
    if (valid.length <= 1) return valid;
    valid.sort((a, b) => a.time - b.time);
    const deduped = [];
    for (let i = 0; i < valid.length; i++) {
      if (deduped.length > 0 && deduped[deduped.length - 1].time === valid[i].time) {
        deduped[deduped.length - 1] = valid[i];
      } else {
        deduped.push(valid[i]);
      }
    }
    return deduped;
  }

  static detectPricePrecision(params, engine, symbol, bars) {
    const paramDigits = Number(params?.priceDigits);
    if (!isNaN(paramDigits) && paramDigits >= 0 && paramDigits <= 6) return paramDigits;
    if (engine && typeof engine.getMainSeries === 'function') {
      const ms = engine.getMainSeries();
      const precision = ms?.options?.()?.priceFormat?.precision;
      if (typeof precision === 'number' && precision >= 0) return precision;
    }
    const sym = (symbol || '').toUpperCase().trim();
    if (sym.includes('JPY') || sym.includes('XAG')) return 3;
    if (sym.includes('XAU') || sym.includes('GOLD')) return 2;
    if (/^[A-Z]{6}$/.test(sym)) return 5;
    return 2;
  }

  static getThemePalette(themeMode = 'Dark') {
    const isDark = String(themeMode).toLowerCase() !== 'light';
    if (!isDark) {
      return {
        isDark: false,
        hudBg: 'rgba(255, 255, 255, 0.96)',
        hudBorder: 'rgba(100, 116, 139, 0.45)',
        textPrimary: '#0f172a',
        textSecondary: '#475569',
        high: '#b91c1c',
        medium: '#b45309',
        low: '#475569',
        accent: '#1d4ed8',
      };
    }
    return {
      isDark: true,
      hudBg: 'rgba(15, 23, 42, 0.94)',
      hudBorder: 'rgba(51, 65, 85, 0.8)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      high: '#f87171',
      medium: '#fbbf24',
      low: '#94a3b8',
      accent: '#38bdf8',
    };
  }

  static drawPillBadge(ctx, text, x, y, options) {
    const opts = options || {};
    const fontSize = opts.fontSize || 10;
    ctx.font = `bold ${fontSize}px sans-serif`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    const metrics = ctx.measureText(text);
    const padX = opts.paddingX || 5;
    const padY = opts.paddingY || 2;
    const w = metrics.width + padX * 2;
    const h = fontSize + padY * 2;
    const radius = opts.borderRadius || 3;
    let drawX = x;
    if (opts.align === 'center') drawX = x - w / 2;
    else if (opts.align === 'right') drawX = x - w;
    const drawY = y - h / 2;
    ctx.beginPath();
    ctx.fillStyle = opts.bgColor || 'rgba(15, 23, 42, 0.9)';
    if (ctx.roundRect) ctx.roundRect(drawX, drawY, w, h, radius);
    else ctx.rect(drawX, drawY, w, h);
    ctx.fill();
    if (opts.borderColor) {
      ctx.strokeStyle = opts.borderColor;
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.fillStyle = opts.textColor || '#f8fafc';
    ctx.fillText(text, drawX + padX, y);
  }
}

class NewsCanvasPrimitive {
  constructor(indicator) {
    this._indicator = indicator;
    this._chart = null;
    this._series = null;
    this._requestUpdate = null;
    this._renderer = {
      draw: (target) => this._draw(target),
    };
  }

  attached(param) {
    this._chart = param?.chart || null;
    this._series = param?.series || null;
    this._requestUpdate = param?.requestUpdate || null;
  }

  detached() {
    this._chart = null;
    this._series = null;
    this._requestUpdate = null;
  }

  updateAllViews() {}

  paneViews() {
    return [{ zOrder: () => 'top', renderer: () => this._renderer }];
  }

  requestUpdate() {
    if (typeof this._requestUpdate === 'function') {
      try { this._requestUpdate(); } catch (_e) {}
    }
  }

  _draw(target) {
    const ind = this._indicator;
    if (!ind || ind.isDestroyed || !ind.isVisible || !ind.cachedData) return;

    const drawFn = (ctx, width, height) => {
      this._drawScene(ctx, width, height, ind);
    };

    if (typeof target.useMediaCoordinateSpace === 'function') {
      target.useMediaCoordinateSpace(({ context: ctx, mediaSize }) => {
        drawFn(ctx, mediaSize.width, mediaSize.height);
      });
    }
  }

  _drawScene(ctx, width, height, ind) {
    const palette = MathUtils.getThemePalette(ind.params.themeMode);
    const params = ind.params;
    const news = ind.cachedData.news || [];
    const chart = ind.engine?.chart;
    const mainSeries = ind.engine?.getMainSeries?.();
    if (!chart || !mainSeries) return;

    const timeScale = chart.timeScale();

    // Vertical markers / labels on chart
    if (Number(params.showMarkers) !== 0 && news.length > 0) {
      for (const item of news) {
        const x = timeScale.timeToCoordinate(item.time);
        if (x == null || x < 0 || x > width) continue;

        const color = item.impact === 'High' ? palette.high :
                      item.impact === 'Medium' ? palette.medium : palette.low;

        ctx.save();
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
        ctx.setLineDash([]);

        // Small label near top
        const label = `${item.currency} ${item.impact[0]}`;
        MathUtils.drawPillBadge(ctx, label, x, 18, {
          bgColor: color,
          textColor: '#ffffff',
          fontSize: 9,
          align: 'center',
          paddingX: 4,
          paddingY: 1,
        });
        ctx.restore();
      }
    }

    // HUD List
    if (Number(params.showHud) !== 0 && news.length > 0) {
      const pos = String(params.hudPosition || 'Bottom Right');
      const margin = 10;
      const rowH = 18;
      const tableW = 280;
      const maxRows = Math.min(news.length, Number(params.maxNews) || 6);
      const tableH = 28 + maxRows * rowH;

      let dx = pos.includes('Left') ? margin : width - tableW - margin;
      let dy = pos.includes('Top') ? margin : height - tableH - margin;

      ctx.save();
      ctx.fillStyle = palette.hudBg;
      ctx.strokeStyle = palette.hudBorder;
      ctx.lineWidth = 1;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(dx, dy, tableW, tableH, 6);
      else ctx.rect(dx, dy, tableW, tableH);
      ctx.fill();
      ctx.stroke();

      ctx.font = 'bold 11px sans-serif';
      ctx.fillStyle = palette.textPrimary;
      ctx.fillText('Forex News Timeline', dx + 8, dy + 16);

      ctx.font = '10px sans-serif';
      for (let i = 0; i < maxRows; i++) {
        const item = news[i];
        const yy = dy + 32 + i * rowH;
        const impactColor = item.impact === 'High' ? palette.high :
                            item.impact === 'Medium' ? palette.medium : palette.low;

        const timeStr = this._formatTime(item.time);
        const text = `${timeStr}  ${item.currency}  ${item.impact[0]}  ${item.title}`;

        ctx.fillStyle = palette.textSecondary;
        ctx.fillText(text.slice(0, 48), dx + 8, yy);
        ctx.fillStyle = impactColor;
        ctx.fillRect(dx + tableW - 10, yy - 4, 6, 6);
      }
      ctx.restore();
    }
  }

  _formatTime(unix) {
    try {
      const tz = typeof localStorage !== 'undefined' ? (localStorage.getItem('app28_chart_timezone') || 'UTC') : 'UTC';
      let offsetHours = 0;
      if (tz.includes('+')) offsetHours = parseFloat(tz.replace(/[^0-9.]/g, '')) || 0;
      else if (tz.includes('-')) offsetHours = -(parseFloat(tz.replace(/[^0-9.]/g, '')) || 0);
      else if (tz.toLowerCase().includes('bangkok') || tz.toLowerCase().includes('jakarta')) offsetHours = 7;
      else if (tz.toLowerCase().includes('tokyo') || tz.toLowerCase().includes('seoul')) offsetHours = 9;
      else if (tz.toLowerCase().includes('london')) offsetHours = 0;
      else if (tz.toLowerCase().includes('new york')) offsetHours = -5;

      const d = new Date((unix + offsetHours * 3600) * 1000);
      const hh = String(d.getUTCHours()).padStart(2, '0');
      const mm = String(d.getUTCMinutes()).padStart(2, '0');
      return `${hh}:${mm}`;
    } catch (_e) {
      return '--:--';
    }
  }
}

const _NEWS_CACHE = new Map();

export class ForexNewsTimelineIndicator {
  constructor() {
    this.id = `forex_news_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    this.name = 'Forex News Timeline';
    this.pane = 'main';
    this.isVisible = true;
    this.isDestroyed = false;

    this.engine = null;
    this.currentSymbol = 'EURUSD';
    this.currentSource = '';
    this._rawBars = [];
    this.cachedData = { news: [], markers: [] };
    this._primitive = null;
    this._attachedMainSeries = null;

    this.params = {
      showHud: 1,
      showMarkers: 1,
      minImpact: 'Medium',
      currencyMode: 'Auto',
      customCurrencies: 'USD,EUR',
      maxNews: 6,
      hudPosition: 'Bottom Right',
      themeMode: 'Dark',
      priceDigits: -1,
    };

    this.paramDefs = [
      { key: 'showHud', label: 'Show HUD List', type: 'select', default: 1, options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }] },
      { key: 'showMarkers', label: 'Show Timeline Markers', type: 'select', default: 1, options: [{ label: 'Show', value: 1 }, { label: 'Hide', value: 0 }] },
      { key: 'minImpact', label: 'Minimum Impact', type: 'select', default: 'Medium', options: [
        { label: 'All', value: 'All' },
        { label: 'Low+', value: 'Low' },
        { label: 'Medium+', value: 'Medium' },
        { label: 'High Only', value: 'High' },
      ]},
      { key: 'currencyMode', label: 'Currency Filter', type: 'select', default: 'Auto', options: [
        { label: 'Auto (Pair)', value: 'Auto' },
        { label: 'Custom', value: 'Custom' },
      ]},
      { key: 'customCurrencies', label: 'Custom Currencies (CSV)', type: 'text', default: 'USD,EUR' },
      { key: 'maxNews', label: 'Max News in HUD', type: 'number', default: 6, min: 3, max: 15, step: 1 },
      { key: 'hudPosition', label: 'HUD Position', type: 'select', default: 'Bottom Right', options: [
        { label: 'Top Right', value: 'Top Right' },
        { label: 'Bottom Right', value: 'Bottom Right' },
        { label: 'Top Left', value: 'Top Left' },
        { label: 'Bottom Left', value: 'Bottom Left' },
      ]},
      { key: 'themeMode', label: 'Theme', type: 'select', default: 'Dark', options: [
        { label: 'Dark', value: 'Dark' },
        { label: 'Light', value: 'Light' },
      ]},
    ];

    if (typeof window !== 'undefined') {
      window.addEventListener('news_timeline_toggled', (e) => {
        const show = Boolean(e?.detail?.show);
        this.params.showMarkers = show ? 1 : 0;
        this.params.showHud = show ? 1 : 0;
        if (this._primitive) this._primitive.requestUpdate();
      });
    }
  }

  setSymbol(symbol) {
    if (symbol && typeof symbol === 'string') this.currentSymbol = symbol.trim().toUpperCase();
  }

  setSource(source) {
    if (source && typeof source === 'string') this.currentSource = source.trim().toUpperCase();
  }

  async _fetchNews() {
    const cacheKey = 'quantdeck_news_calendar';
    const now = Date.now();
    const cached = _NEWS_CACHE.get(cacheKey);
    if (cached && now - cached.ts < 120000) { // 2 min cache
      return cached.events;
    }

    // 1. Try local QuantDeck backend API first
    try {
      const resp = await fetch('/api/news/calendar?min_impact=Low&hours_ahead=72&hours_behind=6');
      if (resp.ok) {
        const json = await resp.json();
        const events = Array.isArray(json.events) ? json.events : [];
        const normalized = events.map((e) => ({
          title: String(e.event || e.title || 'News'),
          currency: String(e.currency || '').toUpperCase(),
          impact: String(e.impact || 'Medium'),
          time: Number(e.time_unix) || Math.floor(new Date(e.datetime_utc || '').getTime() / 1000),
        })).filter((e) => e.time > 0 && e.currency);

        if (normalized.length > 0) {
          _NEWS_CACHE.set(cacheKey, { ts: now, events: normalized });
          return normalized;
        }
      }
    } catch (_err) {}

    // 2. Fallback to external feed
    try {
      const resp = await fetch('https://pipatlas.com/api/calendar');
      if (!resp.ok) throw new Error('HTTP ' + resp.status);
      const json = await resp.json();
      const events = Array.isArray(json.events) ? json.events : [];
      const normalized = events.map((e) => {
        let ts = 0;
        try {
          ts = Math.floor(new Date(e.date).getTime() / 1000);
        } catch (_err) {}
        return {
          title: String(e.name || e.title || 'News'),
          currency: String(e.currency || '').toUpperCase(),
          impact: String(e.impact || 'Low'),
          time: ts,
        };
      }).filter((e) => e.time > 0 && e.currency);

      _NEWS_CACHE.set(cacheKey, { ts: now, events: normalized });
      return normalized;
    } catch (err) {
      console.warn('[ForexNews] fetch failed:', err);
      if (cached) return cached.events;
      return [];
    }
  }

  _filterNews(events, symbol) {
    const impactRank = { Low: 1, Medium: 2, High: 3, All: 0 };
    const minRank = impactRank[this.params.minImpact] || 2;

    let allowed = [];
    if (this.params.currencyMode === 'Auto' && symbol && symbol.length >= 6) {
      allowed = [symbol.slice(0, 3), symbol.slice(3, 6)];
    } else {
      allowed = String(this.params.customCurrencies || '')
        .split(',')
        .map((s) => s.trim().toUpperCase())
        .filter(Boolean);
    }

    const now = Math.floor(Date.now() / 1000);
    const filtered = events.filter((e) => {
      if (impactRank[e.impact] < minRank) return false;
      if (allowed.length && !allowed.includes(e.currency)) return false;
      // Show from 2 hours ago to +48 hours
      return e.time >= now - 7200 && e.time <= now + 172800;
    });

    filtered.sort((a, b) => a.time - b.time);
    return filtered.slice(0, 20);
  }

  async calculate(bars, symbol) {
    if (symbol) this.setSymbol(symbol);
    this._rawBars = Array.isArray(bars) ? [...bars] : [];

    const rawNews = await this._fetchNews();
    const filtered = this._filterNews(rawNews, this.currentSymbol);

    this.cachedData = {
      news: filtered,
      markers: [],
    };
    return this.cachedData;
  }

  ensurePrimitiveAttached() {
    if (this.isDestroyed) return;
    if (!this.engine || typeof this.engine.getMainSeries !== 'function') return;
    const mainSeries = this.engine.getMainSeries();
    if (!mainSeries) return;

    if (!this._primitive) {
      this._primitive = new NewsCanvasPrimitive(this);
    }

    if (this._attachedMainSeries !== mainSeries) {
      if (this._attachedMainSeries?.detachPrimitive) {
        try { this._attachedMainSeries.detachPrimitive(this._primitive); } catch (_e) {}
      }
      if (mainSeries.attachPrimitive) {
        try {
          mainSeries.attachPrimitive(this._primitive);
          this._attachedMainSeries = mainSeries;
        } catch (_e) {}
      }
    }
  }

  render(engine) {
    this.isDestroyed = false;
    this.engine = engine;
    if (!engine?.chart) return;
    this.ensurePrimitiveAttached();
    if (this.cachedData) this.setData(this.cachedData);
  }

  setData(data) {
    if (this.isDestroyed || !data) return;
    this.cachedData = data;
    this.ensurePrimitiveAttached();
    this._primitive?.requestUpdate();
  }

  async update(bar) {
    if (this.isDestroyed || !bar) return;
    const n = this._rawBars.length;
    if (n === 0 || bar.time > this._rawBars[n - 1]?.time) {
      this._rawBars.push({ ...bar });
    } else if (bar.time === this._rawBars[n - 1]?.time) {
      this._rawBars[n - 1] = { ...bar };
    } else return;

    // Refresh news periodically (full recalc is fine here)
    const data = await this.calculate(this._rawBars, this.currentSymbol);
    this.setData(data);
  }

  async updateParams(newParams, engine) {
    this.params = { ...this.params, ...newParams };
    if (engine) this.engine = engine;
    const bars = this.engine?.allBars?.length ? this.engine.allBars : this._rawBars;
    if (bars?.length) {
      const data = await this.calculate(bars, this.currentSymbol);
      this.setData(data);
    }
  }

  setVisible(visible) {
    this.isVisible = visible !== false;
    this._primitive?.requestUpdate();
  }

  destroy(engine) {
    this.isDestroyed = true;
    if (this._attachedMainSeries?.detachPrimitive && this._primitive) {
      try { this._attachedMainSeries.detachPrimitive(this._primitive); } catch (_e) {}
    }
    this._primitive = null;
    this._attachedMainSeries = null;
  }
}

export default ForexNewsTimelineIndicator;
