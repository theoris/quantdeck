/**
 * QuantDeck Standalone Custom Indicator
 * Name: Multi-EMA Trend Ribbon
 * Pane: 'main'
 * Zero runtime imports: Zero-dependency ES Module compatible with dynamic Blob URL execution.
 */

export interface BarData {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface MarkerData {
  time: number;
  position: 'aboveBar' | 'belowBar' | 'inBar';
  color: string;
  shape: 'arrowUp' | 'arrowDown' | 'circle' | 'square';
  text: string;
}

export interface ThemePalette {
  isDark: boolean;
  hudBg: string;
  hudBorder: string;
  textPrimary: string;
  textSecondary: string;
  bullish: string;
  bearish: string;
  neutral: string;
  accent: string;
  gridLine: string;
}

export class MathUtils {
  static detectPricePrecision(params: Record<string, any>, engine?: any, symbol?: string, bars?: BarData[]): number {
    const paramDigits = Number(params?.priceDigits);
    if (!isNaN(paramDigits) && paramDigits >= 0 && paramDigits <= 6) {
      return paramDigits;
    }

    if (engine && typeof engine.getMainSeries === 'function') {
      const ms = engine.getMainSeries();
      const precision = ms?.options?.()?.priceFormat?.precision;
      if (typeof precision === 'number' && precision >= 0) return precision;
      const minMove = ms?.options?.()?.priceFormat?.minMove;
      if (typeof minMove === 'number' && minMove > 0) {
        const d = Math.round(-Math.log10(minMove));
        if (d >= 0 && d <= 6) return d;
      }
    }

    const sym = (symbol || '').toUpperCase().trim();
    if (sym.includes('JPY')) return 3;
    if (sym.includes('XAU') || sym.includes('GOLD')) return 2;
    if (sym.includes('XAG') || sym.includes('SILVER')) return 3;
    if (sym.includes('BTC') || sym.includes('ETH')) return 2;
    if (/^[A-Z]{6}$/.test(sym) || sym.includes('EUR') || sym.includes('GBP') || sym.includes('AUD')) return 5;
    if (/^(US30|NAS100|SPX500|GER40|UK100|SET50|S50)/.test(sym)) return 1;
    if (sym.length <= 5 && !sym.includes('/')) return 2;

    if (Array.isArray(bars) && bars.length > 0) {
      const sample = bars.slice(-100);
      let maxDigits = 2;
      for (const b of sample) {
        for (const p of [b.close, b.open, b.high, b.low]) {
          if (typeof p === 'number' && isFinite(p)) {
            const parts = p.toString().split('.');
            if (parts.length > 1) {
              maxDigits = Math.max(maxDigits, Math.min(parts[1].length, 6));
            }
          }
        }
      }
      return maxDigits;
    }

    return 2;
  }

  static formatPrice(price: number, digits: number): string {
    if (price === null || price === undefined || !isFinite(price)) return '-';
    return price.toFixed(digits);
  }

  static getThemePalette(themeMode: string = 'Dark'): ThemePalette {
    const isDark = String(themeMode).toLowerCase() !== 'light';

    if (!isDark) {
      return {
        isDark: false,
        hudBg: 'rgba(255, 255, 255, 0.96)',
        hudBorder: 'rgba(100, 116, 139, 0.45)',
        textPrimary: '#0f172a',
        textSecondary: '#475569',
        bullish: '#047857',
        bearish: '#b91c1c',
        neutral: '#b45309',
        accent: '#1d4ed8',
        gridLine: 'rgba(203, 213, 225, 0.8)',
      };
    }

    return {
      isDark: true,
      hudBg: 'rgba(15, 23, 42, 0.94)',
      hudBorder: 'rgba(51, 65, 85, 0.8)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      bullish: '#34d399',
      bearish: '#f87171',
      neutral: '#fbbf24',
      accent: '#38bdf8',
      gridLine: 'rgba(51, 65, 85, 0.6)',
    };
  }

  static drawPillBadge(
    ctx: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    options: {
      bgColor: string;
      textColor: string;
      borderColor?: string;
      fontSize?: number;
      paddingX?: number;
      paddingY?: number;
      borderRadius?: number;
      align?: 'left' | 'center' | 'right';
    }
  ) {
    const fontSize = options.fontSize || 10;
    ctx.font = `bold ${fontSize}px sans-serif`;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';

    const metrics = ctx.measureText(text);
    const padX = options.paddingX || 6;
    const padY = options.paddingY || 3;
    const w = metrics.width + padX * 2;
    const h = fontSize + padY * 2;
    const radius = options.borderRadius || 4;

    let drawX = x;
    if (options.align === 'center') drawX = x - w / 2;
    else if (options.align === 'right') drawX = x - w;
    const drawY = y - h / 2;

    ctx.beginPath();
    if (typeof (ctx as any).roundRect === 'function') {
      (ctx as any).roundRect(drawX, drawY, w, h, radius);
    } else {
      ctx.rect(drawX, drawY, w, h);
    }
    ctx.fillStyle = options.bgColor;
    ctx.fill();

    if (options.borderColor) {
      ctx.strokeStyle = options.borderColor;
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    ctx.fillStyle = options.textColor;
    ctx.fillText(text, drawX + padX, y);
  }
}

/**
 * HUD & Summary Canvas Primitive for Multi-EMA Status
 */
class RibbonHudPrimitive {
  private _indicator: MultiEMATrendRibbon;

  constructor(indicator: MultiEMATrendRibbon) {
    this._indicator = indicator;
  }

  attached(param: any) {}
  detached() {}

  paneViews() {
    return [
      {
        renderer: () => ({
          draw: (target: any) => {
            const drawFn = ({ context, mediaSize }: { context: CanvasRenderingContext2D; mediaSize: { width: number; height: number } }) => {
              this._indicator.drawHud(context, mediaSize);
            };

            if (typeof target.useMediaCoordinateSpace === 'function') {
              target.useMediaCoordinateSpace(drawFn);
            } else if (typeof target.useBitmapCoordinateSpace === 'function') {
              target.useBitmapCoordinateSpace((scope: any) => {
                const ctx = scope.context;
                const mediaSize = {
                  width: scope.bitmapSize.width / (scope.horizontalPixelRatio || 1),
                  height: scope.bitmapSize.height / (scope.verticalPixelRatio || 1),
                };
                drawFn({ context: ctx, mediaSize });
              });
            }
          },
        }),
      },
    ];
  }

  requestUpdate() {
    if (this._indicator.engine?.chart) {
      // triggers chart view refresh
    }
  }
}

export class MultiEMATrendRibbon {
  public id: string;
  public name: string;
  public pane: 'main' | 'sub';
  public isVisible: boolean = true;
  public params: Record<string, any>;
  public paramDefs: Array<{
    key: string;
    label: string;
    type: 'number' | 'color' | 'select' | 'string';
    default: any;
    min?: number;
    max?: number;
    step?: number;
    options?: Array<{ label: string; value: any }>;
  }>;

  public engine: any = null;
  public seriesMap: Map<number, any> = new Map();
  public cachedData: Map<number, Array<{ time: number; value: number }>> = new Map();
  public cachedMarkers: MarkerData[] = [];
  public lastSummary: {
    alignment: 'Strong Bullish' | 'Bullish' | 'Strong Bearish' | 'Bearish' | 'Consolidation / Mixed';
    fastVal: number | null;
    slowVal: number | null;
    spreadPct: number;
    periodValues: Array<{ period: number; value: number; color: string }>;
  } = {
    alignment: 'Consolidation / Mixed',
    fastVal: null,
    slowVal: null,
    spreadPct: 0,
    periodValues: [],
  };

  private _rawBars: BarData[] = [];
  private _symbol: string = '';
  private _primitive: RibbonHudPrimitive | null = null;

  // Preset Ribbon Color Palette across ascending periods
  private _defaultColors = [
    '#00E676', // EMA 1: Bright Green
    '#00B0FF', // EMA 2: Light Blue
    '#2979FF', // EMA 3: Royal Blue
    '#FF9100', // EMA 4: Amber Orange
    '#FF1744', // EMA 5: Vibrant Red
    '#D500F9', // EMA 6: Purple
    '#FFD600', // EMA 7: Yellow
    '#00BFA5', // EMA 8: Teal
  ];

  constructor() {
    this.id = `multi_ema_ribbon_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    this.name = 'Multi-EMA Trend Ribbon';
    this.pane = 'main';
    this.isVisible = true;

    this.params = {
      emaPeriodsStr: '9, 21, 50, 100, 200',
      themeMode: 'Dark',
      priceDigits: -1,
      bannerPosition: 'Top Right',
      dashboardPosition: 'Bottom Right',
      lineWidth: 2,
      lineStyle: 0,
      showSignals: 1,
    };

    this.paramDefs = [
      {
        key: 'themeMode',
        label: 'Theme Mode',
        type: 'select',
        default: 'Dark',
        options: [
          { label: 'Dark Theme', value: 'Dark' },
          { label: 'Light Theme', value: 'Light' },
        ],
      },
      {
        key: 'priceDigits',
        label: 'Price Precision (Digits)',
        type: 'select',
        default: -1,
        options: [
          { label: 'Auto-Detect (-1)', value: -1 },
          { label: '0 Decimals (e.g. US30, JPY Pairs)', value: 0 },
          { label: '1 Decimal', value: 1 },
          { label: '2 Decimals (e.g. Gold XAUUSD, Stocks)', value: 2 },
          { label: '3 Decimals (e.g. USDJPY)', value: 3 },
          { label: '4 Decimals', value: 4 },
          { label: '5 Decimals (e.g. EURUSD, GBPUSD)', value: 5 },
          { label: '6 Decimals', value: 6 },
        ],
      },
      {
        key: 'bannerPosition',
        label: 'Trend Status Banner Position',
        type: 'select',
        default: 'Top Right',
        options: [
          { label: 'Top Right (Default)', value: 'Top Right' },
          { label: 'Top Center', value: 'Top Center' },
          { label: 'Bottom Left', value: 'Bottom Left' },
          { label: 'Bottom Right', value: 'Bottom Right' },
          { label: 'Top Left', value: 'Top Left' },
          { label: 'Hide Banner', value: 'Hide' },
        ],
      },
      {
        key: 'dashboardPosition',
        label: 'Ribbon Dashboard Position',
        type: 'select',
        default: 'Bottom Right',
        options: [
          { label: 'Bottom Right (Default)', value: 'Bottom Right' },
          { label: 'Top Right', value: 'Top Right' },
          { label: 'Bottom Left', value: 'Bottom Left' },
          { label: 'Top Left', value: 'Top Left' },
        ],
      },
      {
        key: 'lineWidth',
        label: 'Line Width',
        type: 'select',
        default: 2,
        options: [
          { label: '1px', value: 1 },
          { label: '2px', value: 2 },
          { label: '3px', value: 3 },
          { label: '4px', value: 4 },
        ],
      },
      {
        key: 'lineStyle',
        label: 'Line Style',
        type: 'select',
        default: 0,
        options: [
          { label: 'Solid', value: 0 },
          { label: 'Dotted', value: 1 },
          { label: 'Dashed', value: 2 },
        ],
      },
      {
        key: 'showSignals',
        label: 'Show Fast Cross Signals',
        type: 'select',
        default: 1,
        options: [
          { label: 'Show', value: 1 },
          { label: 'Hide', value: 0 },
        ],
      },
    ];

    this._primitive = new RibbonHudPrimitive(this);
  }

  public setSymbol(symbol: string) {
    this._symbol = symbol;
  }

  private _parsePeriods(): number[] {
    const raw = String(this.params.emaPeriodsStr || '9, 21, 50, 100, 200');
    const parsed = raw
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n) && n > 0);
    return parsed.length > 0 ? Array.from(new Set(parsed)).sort((a, b) => a - b) : [9, 21, 50, 100, 200];
  }

  private _computeEMA(bars: BarData[], period: number): Array<{ time: number; value: number }> {
    const result: Array<{ time: number; value: number }> = [];
    if (!bars || bars.length < period) return result;

    const k = 2 / (period + 1);
    let sum = 0;
    for (let i = 0; i < period; i++) {
      sum += bars[i].close;
    }
    let prevEMA = sum / period;
    result.push({ time: bars[period - 1].time, value: prevEMA });

    for (let i = period; i < bars.length; i++) {
      const currentClose = bars[i].close;
      prevEMA = currentClose * k + prevEMA * (1 - k);
      result.push({ time: bars[i].time, value: prevEMA });
    }
    return result;
  }

  public calculate(bars: BarData[], symbol?: string): Map<number, Array<{ time: number; value: number }>> {
    this._rawBars = bars || [];
    if (symbol) this._symbol = symbol;

    this.cachedData.clear();
    this.cachedMarkers = [];

    const periods = this._parsePeriods();
    if (this._rawBars.length === 0 || periods.length === 0) {
      return this.cachedData;
    }

    const emaSeriesMap: Record<number, Array<{ time: number; value: number }>> = {};
    for (const period of periods) {
      const series = this._computeEMA(this._rawBars, period);
      this.cachedData.set(period, series);
      emaSeriesMap[period] = series;
    }

    // Detect ribbon cross markers between the fastest 2 EMAs
    if (periods.length >= 2) {
      const fastP = periods[0];
      const slowP = periods[1];
      const fastData = emaSeriesMap[fastP] || [];
      const slowData = emaSeriesMap[slowP] || [];

      // Align series by time lookup
      const slowLookup = new Map<number, number>();
      for (const pt of slowData) {
        slowLookup.set(pt.time, pt.value);
      }

      for (let i = 1; i < fastData.length; i++) {
        const tPrev = fastData[i - 1].time;
        const tCurr = fastData[i].time;
        const sPrev = slowLookup.get(tPrev);
        const sCurr = slowLookup.get(tCurr);

        if (sPrev !== undefined && sCurr !== undefined) {
          const fPrev = fastData[i - 1].value;
          const fCurr = fastData[i].value;

          // Golden cross
          if (fPrev <= sPrev && fCurr > sCurr) {
            this.cachedMarkers.push({
              time: tCurr,
              position: 'belowBar',
              color: '#10b981',
              shape: 'arrowUp',
              text: `EMA ${fastP}/${slowP} Bull Cross`,
            });
          }
          // Death cross
          else if (fPrev >= sPrev && fCurr < sCurr) {
            this.cachedMarkers.push({
              time: tCurr,
              position: 'aboveBar',
              color: '#ef4444',
              shape: 'arrowDown',
              text: `EMA ${fastP}/${slowP} Bear Cross`,
            });
          }
        }
      }
    }

    // Update Ribbon State Summary
    const latestBar = this._rawBars[this._rawBars.length - 1];
    const periodValues: Array<{ period: number; value: number; color: string }> = [];

    periods.forEach((p, idx) => {
      const series = emaSeriesMap[p];
      const lastPoint = series && series.length > 0 ? series[series.length - 1] : null;
      const color = this._defaultColors[idx % this._defaultColors.length];
      if (lastPoint && lastPoint.time === latestBar.time) {
        periodValues.push({ period: p, value: lastPoint.value, color });
      }
    });

    if (periodValues.length >= 2) {
      const fastVal = periodValues[0].value;
      const slowVal = periodValues[periodValues.length - 1].value;
      let isAscending = true;
      let isDescending = true;

      for (let i = 0; i < periodValues.length - 1; i++) {
        if (periodValues[i].value < periodValues[i + 1].value) isAscending = false;
        if (periodValues[i].value > periodValues[i + 1].value) isDescending = false;
      }

      let alignment: 'Strong Bullish' | 'Bullish' | 'Strong Bearish' | 'Bearish' | 'Consolidation / Mixed' =
        'Consolidation / Mixed';
      if (isAscending) alignment = latestBar.close > fastVal ? 'Strong Bullish' : 'Bullish';
      else if (isDescending) alignment = latestBar.close < fastVal ? 'Strong Bearish' : 'Bearish';

      const spreadPct = slowVal !== 0 ? Math.abs((fastVal - slowVal) / slowVal) * 100 : 0;

      this.lastSummary = {
        alignment,
        fastVal,
        slowVal,
        spreadPct,
        periodValues,
      };
    }

    return this.cachedData;
  }

  public render(engine: any, onSettings?: () => void, onClose?: () => void) {
    this.engine = engine;
    if (!this.engine?.chart) return;

    const scalePos = typeof engine.getPriceScalePosition === 'function' ? engine.getPriceScalePosition() : 'right';
    const digits = MathUtils.detectPricePrecision(this.params, this.engine, this._symbol, this._rawBars);
    const periods = this._parsePeriods();

    // Create a LineSeries on the main chart for each EMA in the ribbon
    periods.forEach((period, idx) => {
      const color = this._defaultColors[idx % this._defaultColors.length];
      const series = this.engine.chart.addLineSeries({
        priceScaleId: scalePos,
        color,
        lineWidth: Number(this.params.lineWidth) || 2,
        lineStyle: Number(this.params.lineStyle) || 0,
        visible: this.isVisible,
        title: `EMA ${period}`,
        priceFormat: {
          type: 'price',
          precision: digits,
          minMove: 1 / Math.pow(10, digits),
        },
      });
      this.seriesMap.set(period, series);
    });

    // Attach custom primitive HUD to main series
    const mainSeries = this.engine.getMainSeries?.();
    if (mainSeries && typeof mainSeries.attachPrimitive === 'function' && this._primitive) {
      mainSeries.attachPrimitive(this._primitive);
    }

    this.setData(this.cachedData);
  }

  public setData(dataMap: Map<number, Array<{ time: number; value: number }>>) {
    if (!dataMap) return;

    this.seriesMap.forEach((series, period) => {
      const data = dataMap.get(period) || [];
      series.setData(data);
    });

    this.applyMarkers();
    this._primitive?.requestUpdate();
  }

  public update(bar: BarData) {
    if (!bar) return;
    const lastIdx = this._rawBars.length - 1;
    if (lastIdx >= 0 && this._rawBars[lastIdx].time === bar.time) {
      this._rawBars[lastIdx] = bar;
    } else {
      this._rawBars.push(bar);
    }
    this.calculate(this._rawBars, this._symbol);
    this.setData(this.cachedData);
  }

  public updateParams(newParams: Record<string, any>, engine?: any) {
    if (engine) this.engine = engine;
    const oldPeriodsStr = this.params.emaPeriodsStr;
    this.params = { ...this.params, ...newParams };

    const periodsChanged = oldPeriodsStr !== this.params.emaPeriodsStr;
    const digits = MathUtils.detectPricePrecision(this.params, this.engine, this._symbol, this._rawBars);

    if (periodsChanged && this.engine?.chart) {
      // Rebuild series if periods list altered
      this.seriesMap.forEach((series) => {
        try {
          this.engine.chart.removeSeries(series);
        } catch (_) {}
      });
      this.seriesMap.clear();

      const scalePos = typeof this.engine.getPriceScalePosition === 'function' ? this.engine.getPriceScalePosition() : 'right';
      const periods = this._parsePeriods();
      periods.forEach((period, idx) => {
        const color = this._defaultColors[idx % this._defaultColors.length];
        const series = this.engine.chart.addLineSeries({
          priceScaleId: scalePos,
          color,
          lineWidth: Number(this.params.lineWidth) || 2,
          lineStyle: Number(this.params.lineStyle) || 0,
          visible: this.isVisible,
          title: `EMA ${period}`,
          priceFormat: {
            type: 'price',
            precision: digits,
            minMove: 1 / Math.pow(10, digits),
          },
        });
        this.seriesMap.set(period, series);
      });
    } else {
      // Apply style options across existing series
      this.seriesMap.forEach((series, period) => {
        series.applyOptions({
          lineWidth: Number(this.params.lineWidth) || 2,
          lineStyle: Number(this.params.lineStyle) || 0,
          visible: this.isVisible,
          priceFormat: {
            type: 'price',
            precision: digits,
            minMove: 1 / Math.pow(10, digits),
          },
        });
      });
    }

    const bars = this.engine?.allBars?.length > 0 ? this.engine.allBars : this._rawBars;
    this.calculate(bars, this._symbol);
    this.setData(this.cachedData);
  }

  public setVisible(visible: boolean) {
    this.isVisible = visible !== false;
    this.seriesMap.forEach((series) => {
      series.applyOptions({ visible: this.isVisible });
    });

    if (!this.isVisible) {
      this.clearMarkers();
    } else {
      this.applyMarkers();
    }
    this._primitive?.requestUpdate();
  }

  public applyMarkers() {
    if (!this.engine || !this.isVisible || Number(this.params.showSignals) === 0) {
      this.clearMarkers();
      return;
    }
    if (typeof this.engine.setIndicatorMarkers === 'function') {
      this.engine.setIndicatorMarkers(this.id, this.cachedMarkers || []);
      return;
    }
    const mainSeries = this.engine.getMainSeries?.();
    if (mainSeries && typeof mainSeries.setMarkers === 'function') {
      mainSeries.setMarkers(this.cachedMarkers || []);
    }
  }

  public clearMarkers() {
    if (!this.engine) return;
    if (typeof this.engine.clearIndicatorMarkers === 'function') {
      this.engine.clearIndicatorMarkers(this.id);
      return;
    }
    const mainSeries = this.engine.getMainSeries?.();
    if (mainSeries && typeof mainSeries.setMarkers === 'function') {
      mainSeries.setMarkers([]);
    }
  }

  public destroy(engine?: any) {
    const eng = engine || this.engine;
    this.clearMarkers();

    if (this._primitive && eng?.getMainSeries) {
      const ms = eng.getMainSeries();
      if (ms && typeof ms.detachPrimitive === 'function') {
        ms.detachPrimitive(this._primitive);
      }
    }

    if (eng?.chart) {
      this.seriesMap.forEach((series) => {
        try {
          eng.chart.removeSeries(series);
        } catch (_) {}
      });
    }
    this.seriesMap.clear();
    this.cachedData.clear();
    this.cachedMarkers = [];
  }

  public drawHud(ctx: CanvasRenderingContext2D, mediaSize: { width: number; height: number }) {
    if (!this.isVisible) return;

    const palette = MathUtils.getThemePalette(this.params.themeMode);
    const digits = MathUtils.detectPricePrecision(this.params, this.engine, this._symbol, this._rawBars);
    const bannerPos = String(this.params.bannerPosition || 'Top Right');
    const dashPos = String(this.params.dashboardPosition || 'Bottom Right');

    const bannerHeight = 28;
    const bannerMargin = 12;
    const tableWidth = 220;
    const rowHeight = 18;
    const tableHeight = 36 + Math.max(1, this.lastSummary.periodValues.length) * rowHeight;

    const bannerIsTop = bannerPos.startsWith('Top');
    const dashIsTop = dashPos.startsWith('Top');
    const bannerIsRight = bannerPos.includes('Right');
    const dashIsRight = dashPos.includes('Right');

    // Auto-Stacking collision avoidance
    let autoStackY = 0;
    if (bannerPos !== 'Hide' && bannerIsTop === dashIsTop && bannerIsRight === dashIsRight) {
      autoStackY = bannerHeight + bannerMargin;
    }

    // 1. Draw Status Banner
    if (bannerPos !== 'Hide') {
      const isBull = this.lastSummary.alignment.includes('Bull');
      const isBear = this.lastSummary.alignment.includes('Bear');
      const statusColor = isBull ? palette.bullish : isBear ? palette.bearish : palette.neutral;
      const bannerText = `Ribbon Bias: ${this.lastSummary.alignment} | Spread: ${this.lastSummary.spreadPct.toFixed(2)}%`;

      let bannerX = mediaSize.width - 14;
      let align: 'left' | 'center' | 'right' = 'right';

      if (bannerPos.includes('Left')) {
        bannerX = 14;
        align = 'left';
      } else if (bannerPos.includes('Center')) {
        bannerX = mediaSize.width / 2;
        align = 'center';
      }

      let bannerY = 24;
      if (bannerPos.includes('Bottom')) {
        bannerY = mediaSize.height - 24;
      }

      MathUtils.drawPillBadge(ctx, bannerText, bannerX, bannerY, {
        bgColor: palette.hudBg,
        textColor: statusColor,
        borderColor: palette.hudBorder,
        fontSize: 11,
        paddingX: 10,
        paddingY: 5,
        borderRadius: 6,
        align,
      });
    }

    // 2. Draw Table Dashboard
    let dashX = mediaSize.width - tableWidth - 14;
    if (dashPos.includes('Left')) dashX = 14;

    let dashY = mediaSize.height - tableHeight - 24;
    if (dashPos.includes('Top')) {
      dashY = 14 + autoStackY;
    } else if (dashPos.includes('Bottom') && bannerPos.includes('Bottom') && bannerIsRight === dashIsRight) {
      dashY = mediaSize.height - tableHeight - bannerHeight - 24;
    }

    // Draw Dashboard Frame
    ctx.save();
    ctx.beginPath();
    if (typeof (ctx as any).roundRect === 'function') {
      (ctx as any).roundRect(dashX, dashY, tableWidth, tableHeight, 6);
    } else {
      ctx.rect(dashX, dashY, tableWidth, tableHeight);
    }
    ctx.fillStyle = palette.hudBg;
    ctx.fill();
    ctx.strokeStyle = palette.hudBorder;
    ctx.lineWidth = 1;
    ctx.stroke();

    // Table Header
    ctx.font = 'bold 11px sans-serif';
    ctx.fillStyle = palette.textPrimary;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText('EMA Ribbon Metrics', dashX + 10, dashY + 16);

    ctx.strokeStyle = palette.gridLine;
    ctx.beginPath();
    ctx.moveTo(dashX + 8, dashY + 28);
    ctx.lineTo(dashX + tableWidth - 8, dashY + 28);
    ctx.stroke();

    // Table Rows
    ctx.font = '10px sans-serif';
    let currRowY = dashY + 40;
    for (const item of this.lastSummary.periodValues) {
      // Color dot indicator
      ctx.beginPath();
      ctx.arc(dashX + 14, currRowY, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = item.color;
      ctx.fill();

      // Label
      ctx.fillStyle = palette.textSecondary;
      ctx.textAlign = 'left';
      ctx.fillText(`EMA ${item.period}`, dashX + 24, currRowY);

      // Value
      ctx.fillStyle = palette.textPrimary;
      ctx.textAlign = 'right';
      ctx.fillText(MathUtils.formatPrice(item.value, digits), dashX + tableWidth - 10, currRowY);

      currRowY += rowHeight;
    }
    ctx.restore();
  }
}

export default MultiEMATrendRibbon;