@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title QuantDeck Workstation Launcher

cd /d "%~dp0"

:: ---------------------------------------------------------------
:: 0. Auto-Detect Environment (Dev Workspace vs Release User Package)
::    - If frontend\src\main.ts exists -> Developer Mode (Keep Console Open)
::    - Otherwise -> End-User Release Mode (Hidden Windowless, Logs in user_data\logs)
:: ---------------------------------------------------------------
set "IS_DEV_MODE=0"
if exist "%~dp0frontend\src\main.ts" (
    set "IS_DEV_MODE=1"
)
for %%A in (%*) do (
    if /I "%%~A"=="--dev" set "IS_DEV_MODE=1"
    if /I "%%~A"=="--debug" set "IS_DEV_MODE=1"
    if /I "%%~A"=="--release" set "IS_DEV_MODE=0"
)

:: ---------------------------------------------------------------
:: 1. Free Port 8765 & Kill Full Process Tree (/T)
:: ---------------------------------------------------------------
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8765 ^| findstr LISTENING 2^>nul') do (
    if not "%%a"=="" (
        if not "%%a"=="0" (
            if not "%%a"=="4" (
                taskkill /F /T /PID %%a >nul 2>&1
            )
        )
    )
)

:: ---------------------------------------------------------------
:: 2. Locate or Automatically Install Python 3.12
:: ---------------------------------------------------------------
set "PY_EXE="
set "REQ_PY=3.12"
if exist "%~dp0python_version.txt" (
    set /p REQ_PY=<"%~dp0python_version.txt"
)

if exist "%~dp0runtime\python.exe" (
    set "PY_EXE=%~dp0runtime\python.exe"
    goto :check_deps
)

if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" -c "import fastapi, uvicorn" >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        set "PY_EXE=%~dp0.venv\Scripts\python.exe"
        goto :check_deps
    )
)

if exist "C:\ProgramData\miniconda3\python.exe" (
    "C:\ProgramData\miniconda3\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        set "PY_EXE=C:\ProgramData\miniconda3\python.exe"
        "C:\ProgramData\miniconda3\python.exe" -c "import fastapi, uvicorn, pandas, numpy, yfinance, psutil" >nul 2>&1
        if !ERRORLEVEL! EQU 0 (
            goto :check_deps
        )
        goto :setup_venv
    )
)

if exist "%USERPROFILE%\miniconda3\python.exe" (
    "%USERPROFILE%\miniconda3\python.exe" -c "import sys; sys.exit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        set "PY_EXE=%USERPROFILE%\miniconda3\python.exe"
        goto :setup_venv
    )
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "C:\Program Files\Python312\python.exe"
) do (
    if exist %%P (
        set "PY_EXE=%%~P"
        goto :setup_venv
    )
)

where python >nul 2>&1
if !ERRORLEVEL! EQU 0 (
    for /f "delims=" %%i in ('where python 2^>nul') do (
        if not defined PY_EXE (
            "%%i" -c "import sys; sys.exit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
            if !ERRORLEVEL! EQU 0 (
                set "PY_EXE=%%i"
                goto :setup_venv
            )
        )
    )
)

echo ===============================================================
echo   QuantDeck First-Time Setup: Installing Official Python 3.12
echo ===============================================================

where winget >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "C:\Program Files\Python312\python.exe"
) do (
    if exist %%P (
        set "PY_EXE=%%~P"
        goto :setup_venv
    )
)

echo [*] Downloading official Python 3.12.8 installer from python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile '$env:TEMP\python_qd_setup.exe'"
if exist "%TEMP%\python_qd_setup.exe" (
    echo [*] Installing Python 3.12.8...
    "%TEMP%\python_qd_setup.exe" /passive InstallAllUsers=0 PrependPath=1 Include_test=0 Include_pip=1
    del /q "%TEMP%\python_qd_setup.exe" >nul 2>&1
)

for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "C:\Program Files\Python312\python.exe"
) do (
    if exist %%P (
        set "PY_EXE=%%~P"
        goto :setup_venv
    )
)

echo [!] Automatic Python installation could not complete.
echo     Please install Python 3.12 from https://www.python.org/downloads/ and run this file again.
pause
exit /b 1

:: ---------------------------------------------------------------
:: 3. Create Local .venv if using standalone Python
:: ---------------------------------------------------------------
:setup_venv
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo [*] Creating isolated Python environment .venv...
    "%PY_EXE%" -m venv "%~dp0.venv"
    if exist "%~dp0.venv\Scripts\python.exe" (
        set "PY_EXE=%~dp0.venv\Scripts\python.exe"
    )
)

:: ---------------------------------------------------------------
:: 4. Verify & Auto-Install Required Packages (First Run Only)
:: ---------------------------------------------------------------
:check_deps
if exist "%~dp0python_version.txt" (
    set /p REQ_PY=<"%~dp0python_version.txt"
    "%PY_EXE%" -c "import sys; sys.exit(0 if sys.version_info[:2]==(3,12) else 1)" >nul 2>&1
    if !ERRORLEVEL! NEQ 0 (
        echo [!] This QuantDeck build requires Python 3.12 but found a different version at "%PY_EXE%".
        echo     Recreating .venv with Python 3.12...
        if exist "%~dp0.venv" rmdir /s /q "%~dp0.venv" >nul 2>&1
        pause
        exit /b 1
    )
)

if not exist "%~dp0.deps_installed" (
    "%PY_EXE%" -c "import fastapi, uvicorn, pandas, numpy, yfinance, psutil" >nul 2>&1
    if !ERRORLEVEL! NEQ 0 (
        echo ===============================================================
        echo   First-Time Setup: Installing QuantDeck Libraries...
        echo   ^(This only happens once on the first launch^)
        echo ===============================================================
        "%PY_EXE%" -m pip install --upgrade pip
        "%PY_EXE%" -m pip install -r "%~dp0requirements.txt"
        "%PY_EXE%" -m pip install psutil
    )
    echo 1 > "%~dp0.deps_installed"
)

:: ---------------------------------------------------------------
:: 4b. Ensure Desktop & Start Menu Shortcuts & Windows App Path Exist
:: ---------------------------------------------------------------
if not exist "%USERPROFILE%\Desktop\QuantDeck.lnk" (
    "%PY_EXE%" -m utils.create_shortcuts --silent >nul 2>&1
) else if not exist "%APPDATA%\Microsoft\Windows\Start Menu\Programs\QuantDeck.lnk" (
    "%PY_EXE%" -m utils.create_shortcuts --silent >nul 2>&1
)

:: ---------------------------------------------------------------
:: 5. Launch QuantDeck
::    - Developer Workspace -> Show Live Console Logs
::    - Release Package -> Completely Windowless (pythonw.exe), Logs in user_data\logs\quantdeck.log
:: ---------------------------------------------------------------
if "!IS_DEV_MODE!"=="1" (
    echo ===============================================================
    echo   [DEV WORKSPACE] Running QuantDeck with Live Console Logs...
    echo   Log File: %~dp0user_data\logs\quantdeck.log
    echo   ^(Press Ctrl+C or close the app window to stop^)
    echo ===============================================================
    set "QD_DEV=1"
    set "QD_WINDOWLESS=0"
    "%PY_EXE%" "%~dp0run.py" %*
    exit /b 0
)

set "QD_DEV=0"
set "QD_WINDOWLESS=1"
set "PYW_EXE=!PY_EXE:python.exe=pythonw.exe!"

if exist "!PYW_EXE!" (
    start "" "!PYW_EXE!" "%~dp0run.py"
) else (
    start "" /B "!PY_EXE!" "%~dp0run.py" >nul 2>&1
)

exit /b 0
