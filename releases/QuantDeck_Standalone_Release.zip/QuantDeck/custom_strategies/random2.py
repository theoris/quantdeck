"""
QuantDeck Custom Strategy: Regime Adaptive Dynamic Momentum Strategy
File: custom_strategies/regime_momentum_strategy.py

Methodology:
- Timeframe: 1m - 5m
- Fixed lot size execution mode (custom_sizing = False)
- Indicator: EMA 100 and ATR 14
- Entry Trigger:
    * When no position is active from this strategy:
        - Draw a pseudo-random seed in [0.0, 1.0]
        - If random > 0.50 -> Entry Long
        - If random <= 0.50 -> Entry Short
    * When an active position exists:
        - If the latest active position is in profit (Floating PnL > 0) -> Follow same direction
        - If the latest active position is at a loss (Floating PnL <= 0) -> Reverse direction
- Dynamic Volatility Stops & Targets:
    * If Close > EMA: SL distance = K * ATR, TP distance = SL distance * RiskReward
    * If Close < EMA: SL distance = L * ATR, TP distance = SL distance * RiskReward
- Concurrency & Spacing:
    * Max Positions: default 2
    * Bar spacing: minimum N bars (default 5 bars) between consecutive orders
    * Live execution aware (inspects self.is_live and self.open_positions_count)
"""

from typing import Dict, Any, List
import pandas as pd
import numpy as np
import random

try:
    from backend.strategies.base import BaseStrategy
except ImportError:
    class BaseStrategy:
        custom_sizing = False
        def __init__(self, params=None):
            self.params = self.get_default_params()
            if params:
                self.params.update(params)
            self.context = {}

        def set_context(self, context):
            self.context = context or {}

        @property
        def initial_capital(self):
            return float(self.context.get("initial_capital", 10000.0))

        @property
        def lot_size(self):
            return float(self.context.get("lot_size", 1.0))

        @property
        def risk_pct(self):
            return float(self.context.get("risk_pct", 1.0))

        @property
        def sizing_mode(self):
            return str(self.context.get("sizing_mode", "fixed"))

        @property
        def symbol(self):
            return str(self.context.get("symbol", "XAUUSD"))

        @property
        def is_live(self):
            return bool(self.context.get("is_live", False))

        @property
        def open_positions_count(self):
            return int(self.context.get("open_positions_count", 0))

        @property
        def open_positions(self):
            return list(self.context.get("open_positions", []))

        @property
        def multiplier(self):
            if "multiplier" in self.context and self.context["multiplier"]:
                return float(self.context["multiplier"])
            sym = self.symbol.upper()
            if "XAU" in sym or "GOLD" in sym:
                return 100.0
            if "JPY" in sym:
                return 1000.0
            if any(c in sym for c in ("BTC", "ETH")):
                return 1.0
            return 100000.0

        @classmethod
        def get_param_defs(cls):
            return []

        @classmethod
        def get_default_params(cls):
            return {}

        def generate_signals(self, df):
            raise NotImplementedError


class RegimeMomentumStrategy(BaseStrategy):
    name = "Random2"
    description = (
        "Random and followe the winner"
    )
    version = "1.0.0"
    author = "QuantDeck"
    custom_sizing = False  # Fixed lot size strategy

    @classmethod
    def get_param_defs(cls) -> List[Dict[str, Any]]:
        return [
            {
                "key": "ema_period",
                "label": "EMA Period",
                "type": "int",
                "default": 100,
                "min": 10,
                "max": 500,
                "step": 5,
            },
            {
                "key": "max_positions",
                "label": "Max Open Positions",
                "type": "int",
                "default": 2,
                "min": 1,
                "max": 10,
                "step": 1,
            },
            {
                "key": "risk_reward",
                "label": "Risk Reward Ratio",
                "type": "float",
                "default": 3.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.5,
            },
            {
                "key": "waiting_bars",
                "label": "Waiting Bars to Next Order",
                "type": "int",
                "default": 5,
                "min": 1,
                "max": 50,
                "step": 1,
            },
            {
                "key": "atr_k_above_ema",
                "label": "ATR K Multiplier (Close > EMA)",
                "type": "float",
                "default": 2.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1,
            },
            {
                "key": "atr_l_below_ema",
                "label": "ATR L Multiplier (Close < EMA)",
                "type": "float",
                "default": 1.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1,
            },
            {
                "key": "atr_period",
                "label": "ATR Period",
                "type": "int",
                "default": 14,
                "min": 5,
                "max": 50,
                "step": 1,
            },
            {
                "key": "random_seed",
                "label": "Random Generator Seed",
                "type": "int",
                "default": 42,
                "min": 1,
                "max": 999999,
                "step": 1,
            },
        ]

    @classmethod
    def get_default_params(cls) -> Dict[str, Any]:
        return {d["key"]: d["default"] for d in cls.get_param_defs()}

    def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
        n = len(df)
        signals = pd.Series(0, index=df.index, dtype=int)
        sl_series = pd.Series(0.0, index=df.index, dtype=float)
        tp_series = pd.Series(0.0, index=df.index, dtype=float)
        sizes_series = pd.Series(0.0, index=df.index, dtype=float)

        ema_period = int(self.params.get("ema_period", 100))
        max_positions = int(self.params.get("max_positions", 2))
        rr = float(self.params.get("risk_reward", 3.0))
        waiting_bars = int(self.params.get("waiting_bars", 5))
        k_mult = float(self.params.get("atr_k_above_ema", 2.0))
        l_mult = float(self.params.get("atr_l_below_ema", 1.0))
        atr_period = int(self.params.get("atr_period", 14))
        seed_val = int(self.params.get("random_seed", 42))

        warmup_needed = max(ema_period, atr_period) + 1
        if n < warmup_needed:
            return {
                "signals": signals,
                "sl": sl_series,
                "tp": tp_series,
                "sizes": sizes_series,
                "overlays": {},
            }

        # 1. Technical Indicators Calculation
        close = df["close"]
        high = df["high"]
        low = df["low"]

        ema = close.ewm(span=ema_period, adjust=False).mean()

        prev_close = close.shift(1)
        tr = pd.concat(
            [
                high - low,
                (high - prev_close).abs(),
                (low - prev_close).abs(),
            ],
            axis=1,
        ).max(axis=1)
        atr = tr.ewm(span=atr_period, adjust=False).mean()

        # Seed the deterministic pseudo-random number generator for reproducible backtesting
        rng = random.Random(seed_val)

        # 2. Sequential Trade Simulation & State Tracking
        # Structure for active position tracking:
        # dict: {"type": 1 or -1, "entry_price": float, "sl": float, "tp": float, "open_bar": int}
        active_positions: List[Dict[str, Any]] = []
        last_closed_trade: Dict[str, Any] = {}
        last_order_bar_index = -waiting_bars - 1

        is_live = self.is_live
        broker_open_count = self.open_positions_count
        broker_positions = self.open_positions
        fixed_lot = max(0.01, round(self.lot_size, 2))

        for i in range(warmup_needed, n):
            c = float(close.iloc[i])
            h = float(high.iloc[i])
            l = float(low.iloc[i])
            cur_ema = float(ema.iloc[i])
            cur_atr = float(atr.iloc[i])

            # Update existing positions against current bar range (Stop Loss / Take Profit)
            surviving_positions = []
            for pos in active_positions:
                closed = False
                pos_type = pos["type"]

                if pos_type == 1:  # Long
                    if l <= pos["sl"]:
                        last_closed_trade = {"type": 1, "is_profit": False}
                        closed = True
                    elif h >= pos["tp"]:
                        last_closed_trade = {"type": 1, "is_profit": True}
                        closed = True
                elif pos_type == -1:  # Short
                    if h >= pos["sl"]:
                        last_closed_trade = {"type": -1, "is_profit": False}
                        closed = True
                    elif l <= pos["tp"]:
                        last_closed_trade = {"type": -1, "is_profit": True}
                        closed = True

                if not closed:
                    surviving_positions.append(pos)

            active_positions = surviving_positions

            # Determine position concurrency & bar spacing rules
            bars_since_last_order = i - last_order_bar_index
            spacing_ok = bars_since_last_order > waiting_bars

            if is_live and i >= n - 2:
                # Live Execution Mode: check actual broker positions
                can_take_new_position = (broker_open_count < max_positions) and spacing_ok
                has_active = broker_open_count > 0 or len(active_positions) > 0
            else:
                # Historical Backtest Mode: internal simulation tracker
                can_take_new_position = (len(active_positions) < max_positions) and spacing_ok
                has_active = len(active_positions) > 0

            # Signal Generation Logic
            signal = 0

            if can_take_new_position:
                if not has_active:
                    # No active positions open: determine direction via random generator
                    rand_val = rng.random()
                    signal = 1 if rand_val > 0.50 else -1
                else:
                    # An active position exists: check profit/loss status
                    trade_type = 0
                    is_profit = False

                    if is_live and broker_positions:
                        # Extract the most recent open ticket in live broker
                        latest_broker_pos = broker_positions[-1]
                        trade_type = 1 if latest_broker_pos.get("type") in ("BUY", 1) else -1
                        floating_pnl = float(latest_broker_pos.get("pnl", 0.0))
                        is_profit = floating_pnl > 0.0
                    elif len(active_positions) > 0:
                        # Evaluate latest active position's floating PnL
                        latest_pos = active_positions[-1]
                        trade_type = latest_pos["type"]
                        if trade_type == 1:
                            is_profit = c > latest_pos["entry_price"]
                        else:
                            is_profit = c < latest_pos["entry_price"]
                    elif last_closed_trade:
                        # Fallback to the outcome of the most recently closed position
                        trade_type = last_closed_trade["type"]
                        is_profit = last_closed_trade["is_profit"]

                    # Entry Decision: Profit -> Same direction, Loss -> Opposite direction
                    if trade_type != 0:
                        if is_profit:
                            signal = trade_type
                        else:
                            signal = -trade_type

            # Calculate SL & TP if a valid entry signal was generated
            if signal != 0:
                atr_mult = k_mult if c > cur_ema else l_mult
                sl_distance = cur_atr * atr_mult
                tp_distance = sl_distance * rr

                if signal == 1:  # Long
                    sl = c - sl_distance
                    tp = c + tp_distance
                else:  # Short
                    sl = c + sl_distance
                    tp = c - tp_distance

                signals.iloc[i] = signal
                sl_series.iloc[i] = round(sl, 4)
                tp_series.iloc[i] = round(tp, 4)
                sizes_series.iloc[i] = fixed_lot

                last_order_bar_index = i
                active_positions.append({
                    "type": signal,
                    "entry_price": c,
                    "sl": sl,
                    "tp": tp,
                    "open_bar": i,
                })

        # 3. JSON-Safe Overlays for QuantDeck Chart Platform
        times = df["time"].to_numpy() if "time" in df.columns else np.arange(n)
        overlays = {
            "ema_100": {
                "title": f"EMA ({ema_period})",
                "color": "#2962FF",
                "lineWidth": 2,
                "data": [
                    {"time": int(t), "value": round(float(v), 4)}
                    for t, v in zip(times, ema)
                    if not np.isnan(v)
                ],
            },
        }

        return {
            "signals": signals,
            "sl": sl_series,
            "tp": tp_series,
            "sizes": sizes_series,
            "overlays": overlays,
        }