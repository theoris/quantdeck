"""
QuantDeck Custom Strategy: Random3 and follow the winner.
File: custom_strategies/random3.py
"""

from typing import Dict, Any, List
import pandas as pd
import numpy as np

try:
    from backend.strategies.base import BaseStrategy
except ImportError:
    class BaseStrategy:
        custom_sizing = False

        def __init__(self, params=None):
            self.params = self.get_default_params()
            if params:
                self.params.update(params)
            self.context = {}

        def set_context(self, context):
            self.context = context or {}

        @property
        def initial_capital(self):
            return float(self.context.get("initial_capital", 10000.0))

        @property
        def lot_size(self):
            return float(self.context.get("lot_size", 0.1))

        @property
        def risk_pct(self):
            return float(self.context.get("risk_pct", 1.0))

        @property
        def sizing_mode(self):
            return str(self.context.get("sizing_mode", "fixed"))

        @property
        def symbol(self):
            return str(self.context.get("symbol", "XAUUSD"))

        @property
        def multiplier(self):
            if "multiplier" in self.context and self.context["multiplier"]:
                return float(self.context["multiplier"])
            sym = self.symbol.upper()
            if "XAU" in sym or "GOLD" in sym:
                return 100.0
            if "JPY" in sym:
                return 1000.0
            if any(c in sym for c in ("BTC", "ETH")):
                return 1.0
            return 100000.0

        @classmethod
        def get_param_defs(cls):
            return []

        @classmethod
        def get_default_params(cls):
            return {}

        def generate_signals(self, df):
            raise NotImplementedError


class Random3Strategy(BaseStrategy):
    name = "Random3"
    description = (
        "Random3 and follow the winner. "
    )
    version = "2.0.0"
    author = "QuantDeck Pro"
    custom_sizing = False  # Fixed lot sizing managed directly from Platform Context

    @classmethod
    def get_param_defs(cls) -> List[Dict[str, Any]]:
        return [
            {
                "key": "ema_period",
                "label": "EMA Period",
                "type": "int",
                "default": 100,
                "min": 10,
                "max": 300,
                "step": 5,
            },
            {
                "key": "max_positions",
                "label": "Max Position",
                "type": "int",
                "default": 2,
                "min": 1,
                "max": 10,
                "step": 1,
            },
            {
                "key": "rr_ratio",
                "label": "Risk Rewards",
                "type": "float",
                "default": 3.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1,
            },
            {
                "key": "min_bar_spacing",
                "label": "Waiting Close Bar to Next Order (> n bars)",
                "type": "int",
                "default": 5,
                "min": 1,
                "max": 50,
                "step": 1,
            },
            {
                "key": "atr_k",
                "label": "ATR Multiplier K (Close > EMA)",
                "type": "float",
                "default": 2.0,
                "min": 0.1,
                "max": 10.0,
                "step": 0.1,
            },
            {
                "key": "atr_l",
                "label": "ATR Multiplier L (Close < EMA)",
                "type": "float",
                "default": 1.0,
                "min": 0.1,
                "max": 10.0,
                "step": 0.1,
            },
            {
                "key": "atr_period",
                "label": "ATR Period",
                "type": "int",
                "default": 14,
                "min": 5,
                "max": 50,
                "step": 1,
            },
            {
                "key": "random_seed",
                "label": "Random Seed (0=Dynamic)",
                "type": "int",
                "default": 0,
                "min": 0,
                "max": 999999,
                "step": 1,
            },
        ]

    @classmethod
    def get_default_params(cls) -> Dict[str, Any]:
        return {d["key"]: d["default"] for d in cls.get_param_defs()}

    def _extract_live_position_signal(self, real_positions: list, current_close: float) -> int:
        """
        Inspects the latest real open position from broker context in live mode.
        Returns +1 (Long) or -1 (Short), or 0 if unable to parse.
        """
        if not real_positions:
            return 0
        latest_pos = real_positions[-1]
        if not isinstance(latest_pos, dict):
            return 0

        # Determine trade direction from broker position dict
        raw_type = str(
            latest_pos.get("type", latest_pos.get("side", latest_pos.get("direction", "")))
        ).upper()
        if raw_type in ("1", "BUY", "LONG"):
            direction = 1
        elif raw_type in ("-1", "0", "SELL", "SHORT"):
            direction = -1
        else:
            return 0

        # Determine if currently in profit or loss
        if "profit" in latest_pos or "pnl" in latest_pos or "unrealized_pnl" in latest_pos:
            pnl = float(
                latest_pos.get("profit", latest_pos.get("pnl", latest_pos.get("unrealized_pnl", 0.0)))
            )
            is_profit = pnl > 0.0
        elif "price_open" in latest_pos or "entry_price" in latest_pos or "open_price" in latest_pos:
            entry_p = float(
                latest_pos.get("price_open", latest_pos.get("entry_price", latest_pos.get("open_price", current_close)))
            )
            pnl = (current_close - entry_p) if direction == 1 else (entry_p - current_close)
            is_profit = pnl > 0.0
        else:
            return 0

        # Profit -> Same trade type | Loss -> Opposite trade type
        return direction if is_profit else -direction

    def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
        n = len(df)
        signals = pd.Series(0, index=df.index, dtype=int)
        sl_series = pd.Series(0.0, index=df.index, dtype=float)
        tp_series = pd.Series(0.0, index=df.index, dtype=float)
        sizes_series = pd.Series(0.0, index=df.index, dtype=float)

        ema_period = int(self.params["ema_period"])
        max_positions = int(self.params["max_positions"])
        rr = float(self.params["rr_ratio"])
        min_spacing = int(self.params["min_bar_spacing"])
        atr_k = float(self.params["atr_k"])
        atr_l = float(self.params["atr_l"])
        atr_period = int(self.params["atr_period"])
        seed_val = int(self.params["random_seed"])

        warmup_needed = max(ema_period, atr_period) + 5
        if n < warmup_needed:
            return {
                "signals": signals,
                "sl": sl_series,
                "tp": tp_series,
                "sizes": sizes_series,
                "overlays": {},
            }

        close = df["close"]
        high = df["high"]
        low = df["low"]

        # 1. Technical Indicators
        ema = close.ewm(span=ema_period, adjust=False).mean()

        prev_close = close.shift(1)
        tr = pd.concat(
            [high - low, (high - prev_close).abs(), (low - prev_close).abs()],
            axis=1,
        ).max(axis=1)
        atr = tr.ewm(span=atr_period, adjust=False).mean()

        # 2. Random Number Generator per bar (Using numpy default_rng like working file)
        is_live = bool(self.context.get("is_live", False))
        open_pos_count = int(self.context.get("open_positions_count", 0))
        real_open_positions = list(self.context.get("open_positions", []))

        if is_live or seed_val == 0:
            rng = np.random.default_rng()
        else:
            rng = np.random.default_rng(seed_val)
        random_values = rng.uniform(0.0, 1.0, size=n)

        # 3. Position and Order Execution State Tracker
        # Tracks active positions: [{"direction": 1 or -1, "entry": float, "sl": float, "tp": float}]
        active_positions: List[Dict[str, float]] = []
        last_order_bar = -99999
        fix_lot = max(0.01, round(float(self.lot_size), 2))

        for i in range(warmup_needed, n):
            c_high = float(high.iloc[i])
            c_low = float(low.iloc[i])
            c_close = float(close.iloc[i])
            c_ema = float(ema.iloc[i])
            c_atr = float(atr.iloc[i])

            # Update active positions based on current bar's High/Low
            remaining_positions: List[Dict[str, float]] = []
            for pos in active_positions:
                direction = pos["direction"]
                sl = pos["sl"]
                tp = pos["tp"]

                is_closed = False
                if direction == 1:
                    if c_low <= sl or c_high >= tp:
                        is_closed = True
                elif direction == -1:
                    if c_high >= sl or c_low <= tp:
                        is_closed = True

                if not is_closed:
                    remaining_positions.append(pos)

            active_positions = remaining_positions

            # Condition Check: Bar spacing (> n bars) and Max open positions
            bars_since_last = i - last_order_bar

            # CRITICAL FIX: In live mode, do NOT let simulated bars_since_last lock out live execution
            if is_live and i >= n - 2:
                can_trade = (open_pos_count < max_positions)
            else:
                can_trade = (bars_since_last > min_spacing) and (len(active_positions) < max_positions)

            if can_trade and c_atr > 0.0:
                sig = 0

                # Check if an order is currently open
                if is_live and i >= n - 2:
                    if open_pos_count > 0:
                        sig = self._extract_live_position_signal(real_open_positions, c_close)
                        # Fallback to simulated active_positions if broker dict doesn't expose PnL/entry fields
                        if sig == 0 and len(active_positions) > 0:
                            last_pos = active_positions[-1]
                            last_dir = int(last_pos["direction"])
                            last_entry = float(last_pos["entry"])
                            pnl = (c_close - last_entry) if last_dir == 1 else (last_entry - c_close)
                            sig = last_dir if pnl > 0.0 else -last_dir

                elif len(active_positions) > 0:
                    # Backtest / Historical bars: Check latest open position from our strategy
                    last_pos = active_positions[-1]
                    last_dir = int(last_pos["direction"])
                    last_entry = float(last_pos["entry"])
                    pnl = (c_close - last_entry) if last_dir == 1 else (last_entry - c_close)
                    # Profit -> same trade type | Loss -> opposite trade type
                    sig = last_dir if pnl > 0.0 else -last_dir

                # If no open position (or fallback needed), use Random 0.00 to 1.00
                if sig == 0:
                    rand_val = random_values[i]
                    sig = 1 if rand_val > 0.50 else -1

                # SL rule: Close > EMA -> SL = K * ATR | Close < EMA -> SL = L * ATR
                atr_multiplier = atr_k if c_close > c_ema else atr_l
                sl_distance = c_atr * atr_multiplier
                tp_distance = sl_distance * rr

                if sig == 1:
                    sl = c_close - sl_distance
                    tp = c_close + tp_distance
                else:
                    sl = c_close + sl_distance
                    tp = c_close - tp_distance

                signals.iloc[i] = sig
                sl_series.iloc[i] = round(sl, 4)
                tp_series.iloc[i] = round(tp, 4)
                sizes_series.iloc[i] = fix_lot

                active_positions.append({
                    "direction": sig,
                    "entry": c_close,
                    "sl": sl,
                    "tp": tp,
                })
                last_order_bar = i

        # CRITICAL FIX: Propagate signal from completed bar (n - 2) to latest bar (-1) in live mode
        if is_live and open_pos_count < max_positions:
            eval_idx = n - 2 if n >= 2 else n - 1
            if signals.iloc[eval_idx] != 0:
                signals.iloc[-1] = signals.iloc[eval_idx]
                sl_series.iloc[-1] = sl_series.iloc[eval_idx]
                tp_series.iloc[-1] = tp_series.iloc[eval_idx]
                sizes_series.iloc[-1] = sizes_series.iloc[eval_idx]

        # 4. JSON-Safe Overlays (Clean NaN values)
        times = df["time"].to_numpy() if "time" in df.columns else np.arange(n)
        overlays = {
            "ema_100": {
                "title": f"EMA ({ema_period})",
                "color": "#2962FF",
                "lineWidth": 2,
                "data": [
                    {"time": int(t), "value": round(float(v), 4)}
                    for t, v in zip(times, ema)
                    if not np.isnan(v)
                ],
            }
        }

        return {
            "signals": signals,
            "sl": sl_series,
            "tp": tp_series,
            "sizes": sizes_series,
            "overlays": overlays,
        }