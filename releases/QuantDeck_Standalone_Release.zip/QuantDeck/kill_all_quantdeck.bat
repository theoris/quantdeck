@echo off
chcp 65001 > nul
title Kill All QuantDeck Processes
echo ===============================================================
echo   QuantDeck Universal Process Cleaner
echo   Terminating all QuantDeck backend, bot, and browser instances...
echo ===============================================================

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0utils\kill_processes.ps1" -TargetDir "%~dp0."

echo.
echo [OK] All QuantDeck processes cleanly stopped!
echo You can now delete, update, or overwrite the folder safely.
echo.
pause
