import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import uvicorn

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT_DIR)

# Detect mode:
# - Dev workspace (has frontend/src/main.ts and QD_WINDOWLESS != "1"): live console logs enabled
# - Release / User package (or QD_WINDOWLESS == "1"): silent windowless mode, all logs written to user_data/logs/quantdeck.log
IS_WINDOWLESS = (
    os.environ.get("QD_WINDOWLESS") == "1"
    or sys.stdout is None
    or not os.path.exists(os.path.join(ROOT_DIR, "frontend", "src", "main.ts"))
) and os.environ.get("QD_DEV") != "1"

LOG_DIR = Path(ROOT_DIR) / "user_data" / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "quantdeck.log"

if IS_WINDOWLESS:
    os.environ["QD_WINDOWLESS"] = "1"
    os.environ["QD_DEV"] = "0"
    try:
        _log_stream = open(LOG_FILE, "a", encoding="utf-8", buffering=1, errors="replace")
        sys.stdout = _log_stream
        sys.stderr = _log_stream
    except Exception:
        _devnull = open(os.devnull, "w", encoding="utf-8", errors="ignore")
        sys.stdout = _devnull
        sys.stderr = _devnull
else:
    os.environ["QD_DEV"] = "1"
    os.environ["QD_WINDOWLESS"] = "0"
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from backend.config_loader import (
    load_app_config,
    ensure_standalone_directories,
)

cfg = load_app_config()
server_cfg = cfg.get("server", {})
HOST = str(server_cfg.get("host", "127.0.0.1"))
PORT = int(server_cfg.get("port", 8765))
AUTO_OPEN_BROWSER = bool(server_cfg.get("auto_open_browser", True))

APP_PROFILE_DIR = str(
    Path(os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))) / "QuantDeck" / "AppProfile"
)


def kill_stale_app_browsers() -> None:
    """Terminate any lingering Chrome/Edge/WebView2 processes bound to QuantDeck's isolated AppProfile."""
    try:
        import psutil
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if proc.info["pid"] == os.getpid():
                    continue
                name = (proc.info.get("name") or "").lower()
                if name not in ("chrome.exe", "msedge.exe", "msedgewebview2.exe", "google chrome", "microsoft edge"):
                    continue
                cmd = " ".join(proc.cmdline() or []).lower()
                if "quantdeck\\appprofile" in cmd or "quantdeck/appprofile" in cmd:
                    proc.kill()
            except Exception:
                pass
    except Exception:
        pass
    # Clean up stale Chromium singleton locks to ensure Chrome window opens immediately
    try:
        for sfile in ("SingletonLock", "SingletonCookie", "SingletonSocket"):
            sp = os.path.join(APP_PROFILE_DIR, sfile)
            if os.path.exists(sp):
                try:
                    os.remove(sp)
                except Exception:
                    pass
    except Exception:
        pass


def is_port_in_use(host: str, port: int) -> bool:
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.5)
        in_use = (s.connect_ex((host, port)) == 0)
        s.close()
        return in_use
    except Exception:
        return False


def find_free_port(host: str, start_port: int, max_attempts: int = 50) -> int:
    port = start_port
    while is_port_in_use(host, port) and port < start_port + max_attempts:
        port += 1
    return port


def get_pid_for_port(port: int):
    try:
        import psutil
        for conn in psutil.net_connections(kind="tcp"):
            if conn.status == "LISTEN" and conn.laddr.port == port:
                return conn.pid
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            output = subprocess.check_output(
                f"netstat -ano | findstr :{port}",
                shell=True,
                text=True,
                errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            for line in output.strip().splitlines():
                parts = line.split()
                if len(parts) >= 5 and "LISTENING" in parts:
                    pid = int(parts[-1])
                    if pid > 4:
                        return pid
        except Exception:
            pass
    return None


def is_quantdeck_process(pid: int) -> bool:
    if pid <= 4 or pid == os.getpid():
        return False
    try:
        import psutil
        proc = psutil.Process(pid)
        cmd = " ".join(proc.cmdline()).lower()
        if "backend.main:app" in cmd or "run.py" in cmd or ("uvicorn" in cmd and "chart" in cmd):
            return True
    except Exception:
        pass
    return False


def resolve_server_port(host: str, preferred_port: int) -> int:
    if not is_port_in_use(host, preferred_port):
        return preferred_port

    pid = get_pid_for_port(preferred_port)
    if pid and is_quantdeck_process(pid):
        if sys.platform == "win32":
            subprocess.run(
                f"taskkill /F /T /PID {pid}",
                shell=True,
                capture_output=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        else:
            try:
                import psutil
                proc = psutil.Process(pid)
                proc.terminate()
                proc.wait(timeout=2.0)
            except Exception:
                pass
        time.sleep(0.6)
        if not is_port_in_use(host, preferred_port):
            return preferred_port

    return find_free_port(host, preferred_port + 1)


def start_backend():
    os.environ["QD_PORT"] = str(PORT)
    uvicorn.run(
        "backend.main:app",
        host=HOST,
        port=PORT,
        log_level="info" if not IS_WINDOWLESS else "warning",
        access_log=not IS_WINDOWLESS,
    )


def wait_for_server_ready(host: str, port: int, timeout: float = 25.0) -> bool:
    """Poll until FastAPI/Uvicorn server is bound and serving HTTP 200."""
    import urllib.request
    start = time.time()
    url = f"http://{host}:{port}/api/sources"
    fallback_url = f"http://{host}:{port}/"
    while time.time() - start < timeout:
        for u in (url, fallback_url):
            try:
                req = urllib.request.Request(u, headers={"User-Agent": "QuantDeck-Launcher"})
                with urllib.request.urlopen(req, timeout=0.6) as resp:
                    if resp.status == 200:
                        return True
            except Exception:
                pass
        time.sleep(0.15)
    return False


def open_app_window():
    if not AUTO_OPEN_BROWSER:
        return
    # Wait until Uvicorn has bound to port and is actively responding to eliminate
    # Chrome/Edge "This site can't be reached" (ERR_CONNECTION_REFUSED) error
    wait_for_server_ready(HOST, PORT, timeout=25.0)
    url = f"http://{HOST}:{PORT}/"
    os.makedirs(APP_PROFILE_DIR, exist_ok=True)

    if sys.platform == "win32":
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        ]
        edge_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]

        browser_bin = None
        for p in chrome_paths + edge_paths:
            if os.path.exists(p):
                browser_bin = p
                break

        if browser_bin:
            subprocess.Popen(
                [
                    browser_bin,
                    f"--app={url}",
                    f"--user-data-dir={APP_PROFILE_DIR}",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "--disable-extensions",
                    "--disable-background-mode",
                    "--start-maximized",
                ],
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            return
    elif sys.platform == "darwin":
        mac_chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        if os.path.exists(mac_chrome):
            subprocess.Popen([
                mac_chrome,
                f"--app={url}",
                f"--user-data-dir={APP_PROFILE_DIR}",
            ])
            return

    import webbrowser
    webbrowser.open(url)


if __name__ == "__main__":
    ensure_standalone_directories()
    kill_stale_app_browsers()
    PORT = resolve_server_port(HOST, PORT)
    backend_thread = threading.Thread(target=start_backend, daemon=True)
    backend_thread.start()

    open_app_window()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        kill_stale_app_browsers()
