from typing import Dict, Any, List, Optional
import pandas as pd
import numpy as np
from backend.strategies.base import BaseStrategy


def calculate_ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def calculate_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high = df['high']
    low = df['low']
    close = df['close']
    prev_close = close.shift(1)
    
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(window=period, min_periods=1).mean()


def _parse_time_to_minutes(val: Any, default_min: int) -> int:
    """Parses time input (string 'HH:MM', integer hour, or float) to minutes from midnight."""
    if val is None:
        return default_min
    if isinstance(val, (int, float)):
        h = int(val)
        m = int(round((val - h) * 60))
        return (h * 60 + m) % 1440
    val_str = str(val).strip()
    if not val_str:
        return default_min
    try:
        if ":" in val_str:
            parts = val_str.split(":")
            h = int(parts[0])
            m = int(parts[1]) if len(parts) > 1 else 0
            return (h * 60 + m) % 1440
        else:
            h = int(float(val_str))
            return (h * 60) % 1440
    except Exception:
        return default_min


class EMACrossoverStrategy(BaseStrategy):
    name = "EMA Crossover with ATR TP/SL"
    description = "Trend-following strategy capturing momentum crossovers with dynamic ATR risk targets and session time filter."
    version = "1.1.0"
    author = "QuantDeck"

    @classmethod
    def get_param_defs(cls) -> List[Dict[str, Any]]:
        return [
            {
                "key": "fast_period",
                "label": "Fast EMA Period",
                "type": "number",
                "default": 9,
                "min": 2,
                "max": 100,
                "step": 1
            },
            {
                "key": "slow_period",
                "label": "Slow EMA Period",
                "type": "number",
                "default": 21,
                "min": 5,
                "max": 300,
                "step": 1
            },
            {
                "key": "atr_period",
                "label": "ATR Period",
                "type": "number",
                "default": 14,
                "min": 5,
                "max": 50,
                "step": 1
            },
            {
                "key": "tp_atr_mult",
                "label": "Take Profit (x ATR)",
                "type": "number",
                "default": 2.0,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1
            },
            {
                "key": "sl_atr_mult",
                "label": "Stop Loss (x ATR)",
                "type": "number",
                "default": 1.5,
                "min": 0.5,
                "max": 10.0,
                "step": 0.1
            },
            {
                "key": "use_time_filter",
                "label": "Time Filter (1=On, 0=Off)",
                "type": "number",
                "default": 1,
                "min": 0,
                "max": 1,
                "step": 1
            },
            {
                "key": "start_time",
                "label": "Start Time (London Open)",
                "type": "text",
                "default": "08:00"
            },
            {
                "key": "end_time",
                "label": "End Time (NY Close)",
                "type": "text",
                "default": "21:00"
            }
        ]

    @classmethod
    def get_default_params(cls) -> Dict[str, Any]:
        return {
            "fast_period": 9,
            "slow_period": 21,
            "atr_period": 14,
            "tp_atr_mult": 2.0,
            "sl_atr_mult": 1.5,
            "use_time_filter": 1,
            "start_time": "08:00",
            "end_time": "21:00"
        }

    def _get_time_filter_mask(self, df: pd.DataFrame) -> pd.Series:
        """Returns boolean Series indicating whether each bar falls within [start_time, end_time]."""
        try:
            if "time" in df.columns:
                time_col = df["time"]
                if np.issubdtype(time_col.dtype, np.number):
                    # Handle Unix timestamp (milliseconds vs seconds)
                    unit = "ms" if time_col.iloc[-1] > 1e11 else "s"
                    dt_series = pd.to_datetime(time_col, unit=unit, utc=True)
                else:
                    dt_series = pd.to_datetime(time_col, utc=True)
            elif isinstance(df.index, pd.DatetimeIndex):
                dt_series = pd.Series(df.index, index=df.index)
                if dt_series.dt.tz is None:
                    dt_series = dt_series.dt.tz_localize("UTC")
            else:
                return pd.Series(True, index=df.index)

            bar_minutes = dt_series.dt.hour * 60 + dt_series.dt.minute

            start_min = _parse_time_to_minutes(self.params.get("start_time", "08:00"), 8 * 60)
            end_min = _parse_time_to_minutes(self.params.get("end_time", "21:00"), 21 * 60)

            if start_min <= end_min:
                in_session = (bar_minutes >= start_min) & (bar_minutes <= end_min)
            else:
                # Spans overnight / midnight
                in_session = (bar_minutes >= start_min) | (bar_minutes <= end_min)

            return pd.Series(in_session.to_numpy(), index=df.index)
        except Exception as e:
            print(f"[EMACrossoverStrategy] ⚠️ Time filter evaluation warning: {e}")
            return pd.Series(True, index=df.index)

    def generate_signals(self, df: pd.DataFrame) -> Dict[str, Any]:
        if len(df) < max(self.params["slow_period"], self.params["atr_period"]) + 2:
            return {
                "signals": pd.Series(0, index=df.index),
                "sl": pd.Series(0.0, index=df.index),
                "tp": pd.Series(0.0, index=df.index),
                "overlays": {}
            }

        fast_p = int(self.params.get("fast_period", 9))
        slow_p = int(self.params.get("slow_period", 21))

        # Core Moving Average Integrity: Fast period must be strictly less than Slow period
        if fast_p >= slow_p:
            print(f"[EMACrossoverStrategy] ❌ Invalid Parameters: fast_period ({fast_p}) >= slow_period ({slow_p}). Fast period must be strictly less than Slow period.")
            return {
                "signals": pd.Series(0, index=df.index),
                "sl": pd.Series(0.0, index=df.index),
                "tp": pd.Series(0.0, index=df.index),
                "overlays": {}
            }

        atr_p = int(self.params.get("atr_period", 14))
        tp_mult = float(self.params.get("tp_atr_mult", 2.0))
        sl_mult = float(self.params.get("sl_atr_mult", 1.5))

        # Vectorized calculations
        fast_ema = calculate_ema(df['close'], fast_p)
        slow_ema = calculate_ema(df['close'], slow_p)
        atr = calculate_atr(df, atr_p)

        # Detect crossover: 1 for Buy, -1 for Sell, 0 for None
        # Bullish cross: fast was <= slow on previous bar, now fast > slow
        prev_fast = fast_ema.shift(1)
        prev_slow = slow_ema.shift(1)

        buy_signal = (prev_fast <= prev_slow) & (fast_ema > slow_ema)
        sell_signal = (prev_fast >= prev_slow) & (fast_ema < slow_ema)

        # Apply Session Time Filter (default London to New York window)
        use_tf = bool(int(self.params.get("use_time_filter", 1)))
        if use_tf:
            time_mask = self._get_time_filter_mask(df)
            buy_signal = buy_signal & time_mask
            sell_signal = sell_signal & time_mask

        signals = pd.Series(0, index=df.index, dtype=int)
        signals[buy_signal] = 1
        signals[sell_signal] = -1

        # Calculate TP and SL prices for each bar based on close price and ATR
        sl = pd.Series(0.0, index=df.index)
        tp = pd.Series(0.0, index=df.index)

        # For Buy: SL below close, TP above close
        sl[buy_signal] = df['close'][buy_signal] - (atr[buy_signal] * sl_mult)
        tp[buy_signal] = df['close'][buy_signal] + (atr[buy_signal] * tp_mult)

        # For Sell: SL above close, TP below close
        sl[sell_signal] = df['close'][sell_signal] + (atr[sell_signal] * sl_mult)
        tp[sell_signal] = df['close'][sell_signal] - (atr[sell_signal] * tp_mult)

        # Prepare visual overlays for Lightweight Charts
        times = df['time'].tolist()
        fast_data = [{"time": t, "value": round(float(v), 4)} for t, v in zip(times, fast_ema) if not np.isnan(v)]
        slow_data = [{"time": t, "value": round(float(v), 4)} for t, v in zip(times, slow_ema) if not np.isnan(v)]

        return {
            "signals": signals,
            "sl": sl,
            "tp": tp,
            "overlays": {
                f"Fast EMA ({fast_p})": {
                    "color": "#2962FF",
                    "lineWidth": 2,
                    "pane": "main",
                    "data": fast_data
                },
                f"Slow EMA ({slow_p})": {
                    "color": "#FF6D00",
                    "lineWidth": 2,
                    "pane": "main",
                    "data": slow_data
                }
            }
        }

