param(
    [string]$TargetDir = ""
)

$targetRoot = ""
if ($TargetDir -and (Test-Path $TargetDir)) {
    $targetRoot = (Get-Item $TargetDir).FullName.TrimEnd('\').ToLower()
}

$myPid = $PID
Write-Host ">>> Scanning for active QuantDeck ports and processes..." -ForegroundColor Cyan

# 1. Kill any process listening on Ports 8765, 8766
$ports = @(8765, 8766)
foreach ($port in $ports) {
    try {
        $conns = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
        foreach ($c in $conns) {
            $owningPid = [int]$c.OwningProcess
            if ($owningPid -gt 4 -and $owningPid -ne $myPid) {
                Write-Host "  [!] Killing process on port $port (PID: $owningPid)..." -ForegroundColor Yellow
                Stop-Process -Id $owningPid -Force -ErrorAction SilentlyContinue
            }
        }
    } catch {
        # Fallback via netstat
        $lines = netstat -aon 2>$null | Select-String ":$port\s+.*LISTENING"
        foreach ($line in $lines) {
            $parts = ($line -split '\s+') | Where-Object { $_ }
            if ($parts.Count -ge 5) {
                $owningPid = [int]$parts[-1]
                if ($owningPid -gt 4 -and $owningPid -ne $myPid) {
                    Write-Host "  [!] Killing process on port $port (PID: $owningPid)..." -ForegroundColor Yellow
                    Stop-Process -Id $owningPid -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
}

# 2. Universal CIM Process Scan
try {
    $allProcs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue
    foreach ($proc in $allProcs) {
        $procId = [int]$proc.ProcessId
        if ($procId -le 4 -or $procId -eq $myPid) { continue }

        $name = if ($proc.Name) { $proc.Name.ToLower() } else { "" }
        $cmd = if ($proc.CommandLine) { $proc.CommandLine.ToLower() } else { "" }
        $path = if ($proc.ExecutablePath) { $proc.ExecutablePath.ToLower() } else { "" }

        $shouldKill = $false

        # Python / PythonW processes
        if ($name -match 'python') {
            if ($cmd -match 'quantdeck' -or 
                $cmd -match 'backend\.main' -or 
                $cmd -match 'backend\.web_server' -or 
                $cmd -match 'external_bot_runner' -or 
                $cmd -match 'run\.py') {
                $shouldKill = $true
            }
            if ($path -match 'quantdeck' -or $path -match 'allchart') {
                $shouldKill = $true
            }
            if ($targetRoot -and $path -like ($targetRoot + '*')) {
                $shouldKill = $true
            }
            if ($targetRoot -and $cmd -like ('*' + $targetRoot + '*')) {
                $shouldKill = $true
            }
        }

        # Browser processes tied to QuantDeck AppProfile or WebView2 cache
        if ($name -match 'chrome|msedge|msedgewebview2') {
            if ($cmd -match 'quantdeck' -or $cmd -match 'appprofile' -or $cmd -match 'webview2_cache') {
                $shouldKill = $true
            }
        }

        if ($shouldKill) {
            Write-Host "  [x] Stopping PID $procId ($($proc.Name))..." -ForegroundColor Red
            try {
                Stop-Process -Id $procId -Force -ErrorAction SilentlyContinue
            } catch {}
        }
    }
} catch {
    Write-Host "  [!] Process scan note: $_" -ForegroundColor DarkGray
}

Write-Host "[OK] Clean scan complete." -ForegroundColor Green
